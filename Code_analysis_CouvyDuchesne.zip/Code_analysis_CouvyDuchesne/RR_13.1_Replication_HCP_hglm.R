#####
# Association of all brain phenotypes with Sphere score (for Anxiety/Depression)
# The number of independent brain phenotypes has been calcualted by Sarah
# Bonferroni-Sidak correction is used to correct p-values
# Mixed models on family ID used to take into account relatedness

library(scales)
library(hglm)
library(ggplot2)
library(bigmemory)
library(qqman)
library(splines)
citation("hglm")


unrest<-read.csv("/Users/b.couvy-duchesne/Documents/MyDocuments/22_HumanConnectomeP/unrestricted_baptisteCD_3_13_2016_21_31_29.csv",  header=T)
rest<-read.csv("/Users/b.couvy-duchesne/Documents/MyDocuments//22_HumanConnectomeP/RESTRICTED_baptisteCD_3_13_2016_22_32_13.csv",  header=T)
phenoBrain<-read.table("/Users/b.couvy-duchesne/Documents/MyDocuments/22_HumanConnectomeP/HCP_processed_imaging/rh.area.n2819.fsavg4.txt", sep="\t", header=T)
phenoGlobal<-read.csv("/Users/b.couvy-duchesne/Documents/MyDocuments/22_HumanConnectomeP/HCP_processed_imaging/HCP_Global_Measures.csv", header=T)

phenoBrainOld<-read.table("/Users/b.couvy-duchesne/Documents/MyDocuments/22_HumanConnectomeP/HCP_processed_imaging/rh.area.fsavg4.txt", sep="\t", header=T)


data<-merge(unrest, rest, by = "Subject")
data<-merge(data, phenoBrain, by="Subject")
dat<-merge(data, phenoGlobal, by="Subject")
colnames(data)

cor(dat$TSurfArea, dat$Height, use = "p")
cor(dat$TSurfArea, dat$Age_in_Yrs, use = "p")



cor(dat$AvgThickness, dat$Height, use = "p")
t.test(dat$AvgThickness[which(dat$Gender=="F")], dat$AvgThickness[which(dat$Gender=="M")])
hist(dat$AvgThickness)

# Create SA for cluster12 Right
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
varSAR12<-resultCor$var

data$SurfAreaRight12<-rowSums(data[,varSAR12])
hist(data$SurfAreaRight12)

# List of voxels' brain phenotypes for surface area
# Significant cluster:
allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, signifRes$var)

# Calculate mean SA across the cortex
data$MeanSA<-rowSums(data[,colnames(phenoBrain[,2:2563]) ] )

phenoBrain$MeanSA<-rowSums(phenoBrain[,colnames(phenoBrain[,2:2563]) ] )
phenoBrainOld$MeanSA<-rowSums(phenoBrainOld[,colnames(phenoBrain[,2:2563]) ] )

plot(phenoBrain$MeanSA, phenoBrainOld$MeanSA)
cor(phenoBrain$MeanSA, phenoBrainOld$MeanSA)

iii<-4
cor(phenoBrain[,allVars[iii]], phenoBrainOld[,allVars[iii]])
plot(phenoBrain[,allVars[iii]], phenoBrainOld[,allVars[iii]])


hist(data$MeanSA)
hist(data$RSurfArea)
abline(v=mean(data$RSurfArea)+4*sd(data$RSurfArea))

plot(data$MeanSA, data$RSurfArea)

# Set outliers to missing and standardise variables
for (var in c(allVars,"RSurfArea") ){
lb<-mean(data[,var]) - 4*sd(data[,var])
ub<-mean(data[,var]) + 4*sd(data[,var])

data[which(data[,var]< lb ),var]<-NA
data[which(data[,var]> ub ),var]<-NA

data[,var]<-scale(data[,var])
}

hist(data$SurfAreaRight12)
plot(data$SurfAreaRight12, data$VertexNum_144)

# Exclude participants with missing values because of outliers (N=9)
#table(rowSums(is.na(data[,allVars])))
#data<-data[-which(rowSums(is.na(data[,allVars]))>0 ),]

# Anx dep outlier
#data<-data[-which(data$Subject==180129),]

# Remove missing values in Anx dep questionnaire
data<-data[-which(is.na(data$ASR_Anxd_Raw)),]

# Exclude 599065 from data (not present in kinship matris? sex=U?)
data<-data[-which(data$Subject==599065),]

# Exclude Surf Area 12 outlier
data<-data[-which(data$SurfAreaRight12>3.9),]

# Create anx-dep score
data$DSM_AnxDep_sum<-rowSums(data[,c("DSM_Depr_Raw", "DSM_Anxi_Raw")])
#data$DSM_AnxDep_sum[which(data$DSM_AnxDep_sum> (mean(data$DSM_AnxDep_sum)+4*sd(data$DSM_AnxDep_sum) ))]<-NA
table(data$DSM_AnxDep_sum, exclude = NULL)
# Write final file for hlgm models
# write.table(data, "GeneticClusteringOutputPlots/HRC_SurfArea_n890_voxelAndCluster.txt", sep="\t", col.names=T, row.names=F)

table(is.na(data$ASR_Anxd_Raw), is.na(data$DSM_AnxDep_sum))
#############################################
# reopen
data<-read.table("GeneticClusteringOutputPlots/HRC_SurfArea_n890_voxelAndCluster.txt", sep="\t", header=T)

summary(data$DSM_AnxDep_sum)
quantile(data$DSM_AnxDep_sum, probs = 0.95)
# Description HRC file
prop.table(table(data$Gender))

mean(data$Age_in_Yrs)
sd(data$Age_in_Yrs)
range(data$Age_in_Yrs)

mean(data$ASR_Anxd_Raw)
sd(data$ASR_Anxd_Raw)
range(data$ASR_Anxd_Raw)

mean(data$DSM_AnxDep_sum)
sd(data$DSM_AnxDep_sum)
range(data$DSM_AnxDep_sum)

plot(data$ASR_Anxd_Raw, data$DSM_AnxDep_sum)
cor(data$ASR_Anxd_Raw, data$DSM_AnxDep_sum, use = "p")

mean(data$ASR_Anxd_Raw)+3*sd(data$ASR_Anxd_Raw)
mean(data$DSM_AnxDep_sum, na.rm = T)+3*sd(data$DSM_AnxDep_sum, na.rm = T)

dat<-data[-which(data$ASR_Anxd_Raw>21 | data$DSM_AnxDep_sum > 23 ),]
cor(dat$ASR_Anxd_Raw, dat$DSM_AnxDep_sum, use = "p")
plot(dat$ASR_Anxd_Raw, dat$DSM_AnxDep_sum)

table(data$DSM_AnxDep_sum)
table(data$ASR_Anxd_Raw)

range(data$DSM_AnxDep_sum, na.rm = T)
range(data$ASR_Anxd_Raw, na.rm = T)

hist(data$DSM_AnxDep_sum)

data$ASR_Anxd_Raw[which(is.na(data$DSM_AnxDep_sum))]
data$SurfAreaRight12[which(is.na(data$DSM_AnxDep_sum))]
hist(data$SurfAreaRight12)

cor(data$DSM_AnxDep_sum, data$ASR_Anxd_Raw)
cor(ns(data$DSM_AnxDep_sum, df = 3), ns(data$ASR_Anxd_Raw, df = 3))

#################################################
# GRM matrix
# Open kinship matrix
start.time<-proc.time()
kinshipDM<-read.big.matrix(filename = "/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/HCP_S1200_Kinship/kinship_matrix_2150individuals_HCP_includingParents.txt", sep = "\t", header = T)
end.time<-proc.time()
save.time<-end.time-start.time
paste("Number of minutes running:",  save.time[3]/60)

# Load subset function to create kinship matrices
source("/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/RR_2_ExtractKinshipMatrixFromDM_function.R")

 kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = data$Subject)





###########################
# fit HGLM models that account for relatedness
# 1) Linear association of Anxiety-Depression with structural phenotypes
###########################

plot(data$RSurfArea, data$MeanSA)
cor(data$RSurfArea, data$SurfAreaRight12, use = "pairwise.complete.obs",)
cor(data$MeanSA, data$SurfAreaRight12, use = "pairwise.complete.obs",)

#data<-data[which(data$Race=="White" & data$Ethnicity=="Not Hispanic/Latino"),]
# Remove missing values in Anx dep questionnaire
data<-data[-which(is.na(data$DSM_AnxDep_sum)),]

res<-as.data.frame(matrix(0, nrow = length(allVars), ncol = 9))
rownames(res)<-allVars
colnames(res)<-c("betaS1", "sdS1", "pvalS1","betaS2", "sdS2", "pvalS2","betaS3", "sdS3", "pvalS3")
dat<-NULL
var<-allVars[1]
which(is.na(data$SurfAreaRight12))

for (var in allVars){

  if (length(which(is.na(data[,var] | is.na(data$RSurfArea))))>0){
  dat<-data[-which(is.na(data[,var]) | is.na(data$RSurfArea) ),]
  }else{
    dat<-data
  }
  kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = dat$Subject)*2
  kinMatSACTPD<-nearPD(kinMatSACT)$mat

 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) +  ns(DSM_AnxDep_sum, df=3)"), data = dat),verbose = T, vcovmat = T, Z =t(chol(kinMatSACTPD)) , data=dat, family = gaussian(link = "identity"), maxit = 100)

res[var,]<-c(summary(m1.hglm)$FixCoefMat[18,c(1,2,4)],summary(m1.hglm)$FixCoefMat[19,c(1,2,4)], summary(m1.hglm)$FixCoefMat[20,c(1,2,4)] )
}

data[786,c("Subject", "Gender", "Age_in_Yrs", "RSurfArea", "DSM_AnxDep_sum")]

summary(m1.hglm)$FixCoefMat[18,1]*sd(ns(data$DSM_AnxDep_sum, df=3)[,1], na.rm = T)/sd(data[,var], na.rm = T)
summary(m1.hglm)$FixCoefMat[19,1]*sd(ns(data$DSM_AnxDep_sum, df=3)[,2], na.rm = T)/sd(data[,var], na.rm = T)
summary(m1.hglm)$FixCoefMat[20,1]*sd(ns(data$DSM_AnxDep_sum, df=3)[,3], na.rm = T)/sd(data[,var], na.rm = T)

summary(m1.hglm)$FixCoefMat[18,1]*sd(ns(data$ASR_Anxd_Raw, df=3)[,1], na.rm = T)/sd(data[,var], na.rm = T)
summary(m1.hglm)$FixCoefMat[19,1]*sd(ns(data$ASR_Anxd_Raw, df=3)[,2], na.rm = T)/sd(data[,var], na.rm = T)
summary(m1.hglm)$FixCoefMat[20,1]*sd(ns(data$ASR_Anxd_Raw, df=3)[,3], na.rm = T)/sd(data[,var], na.rm = T)

length(which(res$pvalS1<3.6E-3))
range(res$pvalS1)

# Calculate correlation
res$CorS1<-NA
for (var in allVars){
  res[var,"CorS1"]<-res[var,"betaS1"]*sd(ns(data$DSM_AnxDep_sum, df=3)[,1], na.rm = T)/sd(data[,var], na.rm = T)
}

length(res$CorS1[which(res$pvalS1<3.6E-3 & rownames(res) %in% allVars)])
-log(3.6E-3 , base = 10)
length(res$CorS1[which(res$pvalS1<3.6E-3 )])
16/19

write.table(res, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_HCP_replication_N890_DSM_AnxDep_95Vars.txt", sep="\t", col.names=T, row.names=T)
#
write.table(res, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_HCP_replication_N890_ASR_AnxDep.txt", sep="\t", col.names=T, row.names=T)



#############
# Individuals models

plot(data$SurfAreaRight12, data$MeanSA)
hist(data$DSM_AnxDep_sum, breaks=20)
  var<-"SurfAreaRight12"

data$DSM_AnxDep_sum_log<-log(data$DSM_AnxDep_sum+1)
data$ASR_Anxd_Raw_log<-log(data$ASR_Anxd_Raw+1)

dat<-data
mean(dat$DSM_AnxDep_sum)+4*sd(dat$DSM_AnxDep_sum)
dat$DSM_AnxDep_sum[which(dat$DSM_AnxDep_sum>30)]<-30
#dat<-dat[-which(is.na(dat$DSM_AnxDep_sum)),]

plot(dat$Subject, colnames(kinMatSACT))
dat<-dat[order(dat$Subject),]

kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = dat$Subject)*2
  kinMatSACTPD<-nearPD(kinMatSACT)$mat

 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) + ns(DSM_AnxDep_sum, df=3)"), data = dat),verbose = T, vcovmat = T, Z = t(chol(kinMatSACTPD)) , data=dat, family = gaussian(link = "identity"), calc.like = T)
summary(m1.hglm)

m1.hglm$varRanef/(m1.hglm$varRanef+m1.hglm$varFix)

#Effect size
as.matrix(summary(m1.hglm)$FixCoefMat[c(18),1])*sd(ns(data$DSM_AnxDep_sum, df = 3)[,1])/sd(data$SurfAreaRight12)
as.matrix(summary(m1.hglm)$FixCoefMat[c(19),1])*sd(ns(data$DSM_AnxDep_sum, df = 3)[,2])/sd(data$SurfAreaRight12)
as.matrix(summary(m1.hglm)$FixCoefMat[c(20),1])*sd(ns(data$DSM_AnxDep_sum, df = 3)[,3])/sd(data$SurfAreaRight12)

dat[790,c("Subject", "ASR_Anxd_Raw", "DSM_AnxDep_sum", "Gender", "Age_in_Yrs", "Acquisition","SurfAreaRight12")]
plot(dat$DSM_AnxDep_sum, ns(dat$DSM_AnxDep_sum, df = 3, knots = c(0.1,29.9))[,3] )
plot(dat$DSM_AnxDep_sum, ns(dat$DSM_AnxDep_sum, df = 3)[,1] )

# Plot regression curve of model 3
datM3<-NULL
dat$Sex01<-ifelse(dat$Gender=="F", 0 ,1)
datM3<-cbind(1,  dat$Sex01, ns(dat$Age_in_Yrs, df=3) , dat$RSurfArea, ifelse(dat$Acquisition=="Q02", 1,0), ifelse(dat$Acquisition=="Q03", 1,0), ifelse(dat$Acquisition=="Q04", 1,0) ,  ifelse(dat$Acquisition=="Q05", 1,0),  ifelse(dat$Acquisition=="Q06", 1,0),  ifelse(dat$Acquisition=="Q07", 1,0), ifelse(dat$Acquisition=="Q08", 1,0),  ifelse(dat$Acquisition=="Q10", 1,0),  ifelse(dat$Acquisition=="Q11", 1,0),  ifelse(dat$Acquisition=="Q12", 1,0),   ifelse(dat$Acquisition=="Q9", 1,0) )
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(1:17),1])

BB<-cbind(ns(dat$DSM_AnxDep_sum, df=3)[,1:3])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(18:20),1])

BBsignif<-cbind(ns(dat$DSM_AnxDep_sum, df=3)[,1])
regAnxDepsignif<- BBsignif %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(18),1])


plot( dat$DSM_AnxDep_sum, dat$SurfAreaRight12-regCurve   ,
      xlab="DSM oriented Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],  regAnxDep[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=2, lwd=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],  regAnxDepsignif[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=1, lwd=4)
abline(v=quantile(dat$DSM_AnxDep_sum, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(dat$DSM_AnxDep_sum, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 1.4, labels = c("5%", "25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")

quantile(dat$DSM_AnxDep_sum, probs = c(0.05,0.25,0.5,0.75,0.95))

write.table(cor(ns(dat$DSM_AnxDep_sum, df=3)), "Mat_splines_ns_DSManxDep_HCP.txt", sep="\t")
source("RR_6.0_MatSpdLiteNew.R")
runMatSpdLite(corMatFile = "Mat_splines_ns_DSManxDep_HCP.txt")

tiff("DSM_anxDep_HCP_association_signif_allSplines.tif", width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1), xpd=F)
plot( dat$DSM_AnxDep_sum, dat$SurfAreaRight12-regCurve   ,
      xlab="DSM oriented Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],  regAnxDep[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=2, lwd=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],  regAnxDepsignif[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=1, lwd=4)
abline(v=quantile(dat$DSM_AnxDep_sum, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(dat$DSM_AnxDep_sum, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 1.3, labels = c("5%", "25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")
dev.off()

#####################################
 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) + ns(DSM_AnxDep_sum_log, 3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))
summary(m1.hglm)


dat<-data
mean(dat$ASR_Anxd_Raw)+4*sd(dat$ASR_Anxd_Raw)
hist(dat$ASR_Anxd_Raw)
dat$ASR_Anxd_Raw[which(dat$ASR_Anxd_Raw>26)]<-26
dat<-dat[-which(is.na(dat$ASR_Anxd_Raw)),]
ns(inter )

 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) + ns(ASR_Anxd_Raw, 3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))
summary(m1.hglm)


# Plot regression curve of model 3
datM3<-NULL
dat$Sex01<-ifelse(dat$Gender=="F", 0 ,1)
datM3<-cbind(1,  dat$Sex01, ns(dat$Age_in_Yrs, df=3) , dat$RSurfArea, ifelse(dat$Acquisition=="Q02", 1,0), ifelse(dat$Acquisition=="Q03", 1,0), ifelse(dat$Acquisition=="Q04", 1,0) ,  ifelse(dat$Acquisition=="Q05", 1,0),  ifelse(dat$Acquisition=="Q06", 1,0),  ifelse(dat$Acquisition=="Q07", 1,0), ifelse(dat$Acquisition=="Q08", 1,0),  ifelse(dat$Acquisition=="Q10", 1,0),  ifelse(dat$Acquisition=="Q11", 1,0),  ifelse(dat$Acquisition=="Q12", 1,0),   ifelse(dat$Acquisition=="Q9", 1,0)  )
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(1:17),1])

BB<-cbind(ns(dat$ASR_Anxd_Raw, df=3))
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(18:20),1])

tiff("ASR_anxDep_HCP_association.tif", width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1), xpd=F)
plot( dat$ASR_Anxd_Raw, dat$SurfAreaRight12-regCurve   ,
      xlab="ASR Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$ASR_Anxd_Raw[order(dat$ASR_Anxd_Raw)],
      regAnxDep[order(dat$ASR_Anxd_Raw)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=2, lwd=2)
abline(v=quantile(dat$ASR_Anxd_Raw, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(dat$ASR_Anxd_Raw, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 1.3, labels = c("5%", "25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")
dev.off()






dat[786,c("DSM_AnxDep_sum")]

#
cor(data$ASR_Anxd_Raw, ns(dat$ASR_Anxd_Raw, df=3)[,3] )

pdf("aa.pdf")
par(mar=c(5.1,5.1,2.1,4.1))
plot( dat$DSM_AnxDep_sum, regCurve   ,
      xlab="DSM Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],
      regAnxDep[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T),
      col="darkred",lty=1, lwd=2)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],
      regAnxDep[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T) + uB[order(dat$DSM_AnxDep_sum)] ,
      col="blue",lty=1, lwd=1)
lines(dat$DSM_AnxDep_sum[order(dat$DSM_AnxDep_sum)],
      regAnxDep[order(dat$DSM_AnxDep_sum)] +  mean(regCurve, na.rm=T) - uB[order(dat$DSM_AnxDep_sum)] ,
      col="blue",lty=1, lwd=1)
abline(h=0)
dev.off()

SS<-sum(( dat$DSM_AnxDep_sum-mean(dat$DSM_AnxDep_sum))**2)
uB<-1.96*0.060394*sqrt(1/889 + (dat$DSM_AnxDep_sum-mean(dat$DSM_AnxDep_sum))**2/SS )

range(uB)
abline(h=0, col="blue", lwd=2)

hist(ns(dat$DSM_AnxDep_sum, df = 3)[,1])

# Correlation between spline decomposition (what goes into the model)
dat<-data[-which(data$DSM_AnxDep_sum>20 | data$ASR_Anxd_Raw>25),]

cor(ns(data$DSM_AnxDep_sum, df = 3)[,1], ns(data$ASR_Anxd_Raw, df = 3)[,1])
cor(ns(data$DSM_AnxDep_sum, df = 3)[,2], ns(data$ASR_Anxd_Raw, df = 3)[,2])
cor(ns(data$DSM_AnxDep_sum, df = 3)[,3], ns(data$ASR_Anxd_Raw, df = 3)[,3])

# Model correlation between scores
m1.hglm <-   hglm(y =  dat[,"DSM_AnxDep_sum"],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + factor(Acquisition) + ns(ASR_Anxd_Raw, d=3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))

summary(m1.hglm)

as.matrix(summary(m1.hglm)$FixCoefMat[,1][17])/sd(data$DSM_AnxDep_sum)*sd(ns(dat$ASR_Anxd_Raw, df = 3)[,1])
as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])/sd(data$DSM_AnxDep_sum)*sd(ns(dat$ASR_Anxd_Raw, df = 3)[,2])
as.matrix(summary(m1.hglm)$FixCoefMat[,1][19])/sd(data$DSM_AnxDep_sum)*sd(ns(dat$ASR_Anxd_Raw, df = 3)[,3])

0.375
0.535
0.548

cor(dat$DSM_AnxDep_sum, ns(dat$ASR_Anxd_Raw, df = 3)[,2])
cor(dat$DSM_AnxDep_sum,dat$ASR_Anxd_Raw)

dat$ASR_Anxd_Raw_S1<-ns(dat$ASR_Anxd_Raw, df = 3)[,1]

m1.hglm <-   hglm(y =  dat[,"ASR_Anxd_Raw"],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + factor(Acquisition) + ns(DSM_AnxDep_sum, df=3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))

summary(m1.hglm)
as.matrix(summary(m1.hglm)$FixCoefMat[,1][17])/sd(dat$ASR_Anxd_Raw)*sd(ns(dat$DSM_AnxDep_sum, df =  3)[,1])
as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])/sd(dat$ASR_Anxd_Raw)*sd(ns(dat$DSM_AnxDep_sum, df = 3)[,2])
as.matrix(summary(m1.hglm)$FixCoefMat[,1][19])/sd(dat$ASR_Anxd_Raw)*sd(ns(dat$DSM_AnxDep_sum, df=3])

0.48**2+0.66**2+0.83**2
0.12**2+0.48**2+0.49**2
sqrt(0.484)

m1.glm <-   glm(formula = "ASR_Anxd_Raw ~  factor(Gender) + ns(Age_in_Yrs, df=3) + factor(Acquisition) + ns(DSM_AnxDep_sum, df=3)", data = dat, family = gaussian(link = "identity"))
summary(m1.glm)
worst_age_spl <- predict.glm(m1.glm, newdata=dat,type = "response", conf.int=.95)
worst_age_spl

plot(data$ASR_Anxd_Raw, ns(data$ASR_Anxd_Raw, df = 3)[,1])
??redict.merMod
# Plot regression curve of model 3
datM3<-NULL
dat$Sex01<-ifelse(dat$Gender=="F", 0 ,1)
datM3<-cbind(1,  dat$Sex01, ns(dat$Age_in_Yrs, df=3) ,  ifelse(dat$Acquisition=="Q02", 1,0), ifelse(dat$Acquisition=="Q03", 1,0), ifelse(dat$Acquisition=="Q04", 1,0) ,  ifelse(dat$Acquisition=="Q05", 1,0),  ifelse(dat$Acquisition=="Q06", 1,0),  ifelse(dat$Acquisition=="Q07", 1,0), ifelse(dat$Acquisition=="Q08", 1,0),  ifelse(dat$Acquisition=="Q10", 1,0),  ifelse(dat$Acquisition=="Q11", 1,0),  ifelse(dat$Acquisition=="Q12", 1,0),   ifelse(dat$Acquisition=="Q9", 1,0))
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[c(1:16),1])

BB<-cbind(bs(dat$ASR_Anxd_Raw, degree = 3)[,1])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][17])

BB<-cbind(bs(dat$ASR_Anxd_Raw, degree=3)[,2])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])

BB<-cbind(bs(dat$ASR_Anxd_Raw, degree=3)[,3])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][19])

BB<-cbind(bs(dat$ASR_Anxd_Raw, degree=3)[,1:3])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][17:19])


dat[786,c("DSM_AnxDep_sum")]
#

par(mar=c(5.1,5.1,2.1,4.1))
plot( dat$ASR_Anxd_Raw,  dat$DSM_AnxDep_sum-regCurve   ,
      xlab="DSM Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$ASR_Anxd_Raw[order(dat$ASR_Anxd_Raw)],
      regAnxDep[order(dat$ASR_Anxd_Raw)] ,
      col="darkred",lty=1, lwd=6)

plot(ns(data$DSM_AnxDep_sum, df = 3)[,1], ns(data$ASR_Anxd_Raw, df = 3)[,1])
cor(ns(data$DSM_AnxDep_sum, df = 3)[,1], ns(data$ASR_Anxd_Raw, df = 3)[,1])

plot(ns(data$DSM_AnxDep_sum, df = 3)[,2], ns(data$ASR_Anxd_Raw, df = 3)[,2])
cor(ns(data$DSM_AnxDep_sum, df = 3)[,2], ns(data$ASR_Anxd_Raw, df = 3)[,2])
plot(ns(data$DSM_AnxDep_sum, df = 3)[,3], ns(data$ASR_Anxd_Raw, df = 3)[,3])
cor(ns(data$DSM_AnxDep_sum, df = 3)[,3], ns(data$ASR_Anxd_Raw, df = 3)[,3])


dat<-data[which(data$ASR_Anxd_Raw < 15 & data$DSM_AnxDep_sum < 15),]
dat<-data[which(data$ASR_Anxd_Raw < 15 & data$DSM_AnxDep_sum < 15 & data$ASR_Anxd_Raw >2 & data$DSM_AnxDep_sum > 2),]

cor(dat$DSM_AnxDep_sum, dat$ASR_Anxd_Raw)

plot(data$DSM_Anxi_Raw, data$ASR_Anxd_Raw)

data$
dat$Acquisition
hist(data$DSM_AnxDep_sum)
hist(data$ASR_Anxd_Raw, breaks = 20)
hist(data$ASR_Anxd_Pct)
plot(data$DSM_AnxDep_sum2, data$ASR_Anxd_Raw, type = "p", pch=1)
abline(a = 0, b = 1)
range(data$DSM_AnxDep_sum, na.rm = T)
range(data$ASR_Anxd_Raw, na.rm = T)

cor(data$DSM_AnxDep_sum, data$ASR_Anxd_Raw, use = "p", method = "k")


data$DSM_AnxDep_sum2<-data$DSM_AnxDep_sum + rnorm(1, mean = 0, sd = 0.5)

  var<-"SurfAreaRight12"
dat<-data
#dat<-data[-which(is.na(data$SurfAreaRight12) | is.na(data$ASR_Anxd_Raw)),]
dat$ASR_Anxd_Raw[which(dat$ASR_Anxd_Raw>25)]<-25

mean(dat$ASR_Witd_Raw)+4*sd(dat$ASR_Anxd_Raw)

dat[340,c("Subject", "ASR_Anxd_Raw", "DSM_AnxDep_sum", "Gender", "Age_in_Yrs")]
dat<-dat[-340,]
dat[272,c("Subject", "ASR_Anxd_Raw", "DSM_AnxDep_sum", "Gender", "Age_in_Yrs")]
dat<-dat[-272,]
dat[623,c("Subject", "ASR_Anxd_Raw", "DSM_AnxDep_sum", "Gender", "Age_in_Yrs")]
dat<-dat[-623,]

 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) +   ns(ASR_Anxd_Raw, 3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))
summary(m1.hglm)

par(mar=c(5.1,5.1,2.1,4.1))
plot( dat$ASR_Anxd_Raw,  dat$SurfAreaRight12-regCurve   ,
      xlab="DSM Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(dat$ASR_Anxd_Raw[order(dat$ASR_Anxd_Raw)],
      regAnxDep[order(dat$ASR_Anxd_Raw)] ,
      col="darkred",lty=1, lwd=6)



bs()
################################
# Plotting

plot(data$SurfAreaRight12, data$MeanSA)

  var<-allVars[1]
 if (length(which(is.na(data[,var])))>0){
  dat<-data[-which(is.na(data[,var])),]
  } else {dat<-data}

 m1.hglm <-   hglm(y =  dat[,var],  X = model.matrix(as.formula("~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition) +  ns(DSM_AnxDep_sum, df=3)"), data = dat),verbose = T, vcovmat = T, Z =subsetKinshipMatrix(kinshipMat = kinMatSACT, IDlist = dat$Subject) , data=dat, family = gaussian(link = "identity"))

summary(m1.hglm)

table(is.na(dat$DSM_AnxDep_sum))

# Plot regression curve of model 3
data$Sex01<-ifelse(data$Gender=="F", 0 ,1)
datM3<-cbind(1,  data$Sex01, ns(data$Age_in_Yrs, df=3) , data$RSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$DSM_AnxDep_sum, df=3)[,1])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][7])

data[786,c("DSM_AnxDep_sum")]
#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScoreASR_DSM_HCP_replication_naturalSplines_hglm.tiff",  width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$DSM_AnxDep_sum, data$SurfAreaRight12   ,
      xlab="DSM Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(data$DSM_AnxDep_sum[order(data$DSM_AnxDep_sum)],
      regAnxDep[order(data$DSM_AnxDep_sum)] +  mean(data$SurfAreaRight12, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()


sd (data$SurfAreaRight12)







