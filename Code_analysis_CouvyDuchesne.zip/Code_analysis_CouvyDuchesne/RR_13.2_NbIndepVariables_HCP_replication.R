# Estimate number of independent tests
library(splines)
source("RR_6.0_MatSpdLiteNew.R")

data<-read.table("GeneticClusteringOutputPlots/HRC_SurfArea_n890_voxelAndCluster.txt", sep="\t", header=T)
colnames(data)

allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
#signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, resultCor$var)

for (var in allVars){
  m1<-glm(formula = as.formula(paste0(var, "~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition)")), data = data, na.action=na.exclude,family = gaussian(link = "identity"))
data[,paste0(var, "_reg")]<-residuals(m1)
}

for (var in c("ASR_Anxd_Raw", "DSM_AnxDep_sum", "DSM_Depr_Raw", "DSM_Anxi_Raw")){
  m1<-glm(formula = as.formula(paste0(var, "~  factor(Gender) + ns(Age_in_Yrs, df=3) ")), data = data, na.action=na.exclude,family = gaussian(link = "identity"))
data[,paste0(var, "_reg")]<-residuals(m1)
}

# Correlation matrix uncorrected for covariates
corMat<-cor(data[,paste0(allVars, "_reg")], use="complete.obs")
write.table(corMat, "GeneticClusteringOutputPlots/correlationMatrix_HCP_replication_95Pheno_reg.txt", sep="\t", col.names=T, row.names=F)
#
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_HCP_replication_95Pheno_reg.txt")

################################################
corMat<-cor(data[,paste0(allVars)], use="complete.obs")
write.table(corMat, "GeneticClusteringOutputPlots/correlationMatrix_HCP_replication.txt", sep="\t", col.names=T, row.names=F)
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_HCP_replication.txt")

plot(data$ASR_Anxd_Raw_reg, data$DSM_AnxDep_sum_reg)
plot(data$ASR_Anxd_Raw, data$DSM_AnxDep_sum)

# Nb inde anxdep scores
corMat<-cor(data[,c("ASR_Anxd_Raw_reg", "DSM_AnxDep_sum_reg")], use="complete.obs")
write.table(corMat, "GeneticClusteringOutputPlots/correlationMatrix_HCP_anxDep.txt", sep="\t", col.names=T, row.names=F)
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_HCP_anxDep.txt")

# Write table with regressed vars
write.table(data,"GeneticClusteringOutputPlots/HRC_SurfArea_n890_voxelAndCluster_phenoRegressed.txt", sep="\t", col.names=T, row.names=F)

6+7

5*6
0.05/6
1-(1-0.05)**(1/13)
# 4.3E-4

39.4*52

# Based on 40 indep variables
# 3*40=120 tests
1-(1-0.05)**(1/120)
# Significance threshold of 0.0004273528 = 4.2E-4
