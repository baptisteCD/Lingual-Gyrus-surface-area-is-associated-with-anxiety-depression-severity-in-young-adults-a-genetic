# Transform data into OpenMx format
# Run genetic correlations between anx-dep and the regions identified previously

library(splines)
#library(nlme)

data<-read.table("GeneticClusteringOutputPlots/HRC_SurfArea_n890_voxelAndCluster.txt", sep="\t", header=T, stringsAsFactors = F)

# FAMILY ID
# Create family ID from mother and father ID
# Put in the same family the half-siblings
# Start with the mums and put all their partners in their family
data$famid<-data$Mother_ID
prop.table(table(data$Gender))
mean(data$Age_in_Yrs)
range(data$Age_in_Yrs)

# For each mum, add the partners extra partners to the same family
for (iii in data$Mother_ID){
hubby<-data$Father_ID[which(data$famid==iii)]
data$famid[which(data$Father_ID %in% hubby)]<-iii
}
length(unique(data$famid))
length(which(is.na(data$famid)))


# Regress covariates from voxel and cluster vars
allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, resultCor$var)

for (var in allVars){
  m1<-glm(formula = as.formula(paste0(var, "~  factor(Gender) + ns(Age_in_Yrs, df=3) + RSurfArea + factor(Acquisition)")), data = data, na.action=na.exclude,family = gaussian(link = "identity"))
data[,paste0(var, "_reg")]<-residuals(m1)
}


for (var in c("ASR_Anxd_Raw", "DSM_AnxDep_sum", "DSM_Depr_Raw", "DSM_Anxi_Raw")){
  m1<-glm(formula = as.formula(paste0(var, "~  factor(Gender) + ns(Age_in_Yrs, df=3) ")), data = data, na.action=na.exclude,family = gaussian(link = "identity"))
data[,paste0(var, "_reg")]<-residuals(m1)
}

plot(data$DSM_AnxDep_sum_reg, data$DSM_AnxDep_sum)


#The following objects contain the list of familyIDs according to the family size
familyID<-as.data.frame(table(data$famid))
familyID_pairs<-familyID[which(familyID[,2]==2),][,1]
familyID_single<-familyID[which(familyID[,2]==1),][,1]
familyID_triplets<-familyID[which(familyID[,2]==3),][,1]
familyID_4<-familyID[which(familyID[,2]==4),][,1]
familyID_5<-familyID[which(familyID[,2]==5),][,1]
familyID_6<-familyID[which(familyID[,2]==6),][,1]

#Print the family decomposition
#Family size decomposition (based on TWID)
print(paste("There are", length(familyID_single), "families composed of 1 individual"))
print(paste("There are", length(familyID_pairs), "families composed of 2 individuals"))
print(paste("There are", length(familyID_triplets), "families composed of 3 individuals"))
print(paste("There are", length(familyID_4), "families composed of 4 individuals"))
print(paste("There are", length(familyID_5), "families composed of 5 individuals"))
print(paste("There are", length(familyID_6), "families composed of 6 individuals"))

# Family with 6 members
aa<-data[which(data$famid %in% familyID_6),c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]
aa<-aa[order(aa$famid),]
IDtoExclude6<-c("481951", "185846", "773257")

# Family with 5 members
aa<-data[which(data$famid %in% familyID_5),c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]
aa<-aa[order(aa$famid),]
IDtoExclude5<-c("211316", "713239", "540436", "965367")

# Family with 4 members
aa<-data[which(data$famid %in% familyID_4),c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]
aa<-aa[order(aa$famid, aa$Zygosity),]

IDtoExclude4<-NULL
for (fam in familyID_4){
  aa<-data[which(data$famid ==fam),c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]
  aa<-aa[order(aa$famid, aa$Zygosity),]

  IDtoExclude4<-c(IDtoExclude4, aa$Subject[4])
  print(paste("Exclusion of 1 subject", aa$Zygosity[4], "from family", aa$famid[4]))

}


# The following IDs are excluded (siblings)
ID2exclude<-c(IDtoExclude4, IDtoExclude5, IDtoExclude6)

data<-data[-which(data$Subject %in% ID2exclude),]


#The following objects contain the list of familyIDs according to the family size
familyID<-as.data.frame(table(data$famid))
familyID_pairs<-familyID[which(familyID[,2]==2),][,1]
familyID_single<-familyID[which(familyID[,2]==1),][,1]
familyID_triplets<-familyID[which(familyID[,2]==3),][,1]
familyID_4plus<-familyID[which(familyID[,2]>3),][,1]

#Print the family decomposition
#Family size decomposition (based on TWID)
print(paste("There are", length(familyID_single), "families composed of 1 individual"))
print(paste("There are", length(familyID_pairs), "families composed of 2 individuals"))
print(paste("There are", length(familyID_triplets), "families composed of 3 individuals"))
print(paste("There are", length(familyID_4plus), "families composed of more than 3 individuals"))

# Age and sex % and demographics
mean(data$Age_in_Yrs)
sd(data$Age_in_Yrs)
range(data$Age_in_Yrs)

prop.table(table(data$Gender))

###########################################################
# Create the OpenMx file
library(plyr)

# Sort data by family ID and zygosity
data<-data[order(data$famid, data$Zygosity),]
#data[,c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]

# COMPLETE TRIOS
newdata<-apply(as.data.frame(familyID_triplets), 1,
               function(x) cbind(data[which(data$famid==x ),][1,] ,
                                 data[which(data$famid==x ),][2,],
                                 data[which(data$famid==x ),][3,]  ) )


tripData <- ldply(newdata, data.frame)

colnames(tripData)<-c(paste(colnames(data), "_T1", sep=""),
                      paste(colnames(data), "_T2", sep=""),
                      paste(colnames(data), "_Sib", sep=""))

table(tripData$Zygosity_T1)
table(tripData$Zygosity_T2)
table(tripData$Zygosity_Sib)

tripData[which(tripData$Zygosity_T1=="NotTwin" | tripData$Zygosity_T2=="NotTwin"), c("Zygosity_T1","Zygosity_T2","Zygosity_Sib")]
dim(tripData[which(tripData$Zygosity_T2=="NotTwin"), c("Zygosity_T1","Zygosity_T2","Zygosity_Sib")])
length(which(tripData$Zygosity_T1=="NotTwin" | tripData$Zygosity_T2=="NotTwin"))
# COMPLETE PAIRS
# TWIN-SIB PAIRS
familyID_pairs_sib<-unique(data$famid[which(data$famid %in% familyID_pairs & data$Zygosity=="NotTwin")  ])
newdata<-apply(as.data.frame(familyID_pairs_sib), 1,
               function(x) cbind(data[which(data$famid==x ),][1,] ,
                                 data[which(data$famid==x ),][2,]) )
twinSibData <- ldply(newdata, data.frame)

colnames(twinSibData)<-c(paste(colnames(data), "_T1", sep=""),
                      paste(colnames(data), "_Sib", sep=""))

table(twinSibData$Zygosity_T1)
table(twinSibData$Zygosity_Sib)
dim(twinSibData[which(twinSibData$Zygosity_T1=="NotTwin"), c("Zygosity_T1","Zygosity_Sib")])
length(which(twinSibData$Zygosity_T1=="NotTwin"))

# TWIN PAIRS
familyID_pairs_twins<-unique(familyID_pairs[-which(familyID_pairs %in% familyID_pairs_sib)])
newdata<-apply(as.data.frame(familyID_pairs_twins), 1,
               function(x) cbind(data[which(data$famid==x ),][1,] ,
                                 data[which(data$famid==x ),][2,]) )
twinData <- ldply(newdata, data.frame)
length(twinData[,1])
colnames(twinData)<-c(paste(colnames(data), "_T1", sep=""),
                      paste(colnames(data), "_T2", sep=""))

table(twinData$Zygosity_T1, exclude = NULL)
table(twinData$Zygosity_T2, exclude=NULL)

# binding the pairs and trios
pairData<-rbind.fill(tripData, twinData, twinSibData)


length(which(!is.na(c(pairData$Subject_T1,pairData$Subject_T2,pairData$Subject_Sib) )))

table(pairData$Zygosity_T1, pairData$Zygosity_T2, exclude=NULL)
table(pairData$ZYGOSITY_T1, pairData$ZYGOSITY, exclude=NULL)
# Creating the zygosity variable for each pair
# (pair with siblings become DZ, including pairs of siblings)
pairData$ZYGOSITY<-NA
pairData$ZYGOSITY[which(pairData$Zygosity_T1==pairData$Zygosity_T2 )]<-c(pairData$Zygosity_T1[which(pairData$Zygosity_T1==pairData$Zygosity_T2)])
pairData$ZYGOSITY[which(pairData$ZYGOSITY=="NotTwin")]<-"NotMZ"

pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="MZ" & pairData$Gender_T1=="F" & pairData$Gender_T2=="F")]<-1
pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="MZ" & pairData$Gender_T1=="M" & pairData$Gender_T2=="M")]<-2

pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="NotMZ" & pairData$Gender_T1=="F" & pairData$Gender_T2=="F")]<-3
pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="NotMZ" & pairData$Gender_T1=="M" & pairData$Gender_T2=="M")]<-4
pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="NotMZ" & pairData$Gender_T1=="F" & pairData$Gender_T2=="M")]<-5
pairData$ZYGOSITY[ which(pairData$ZYGOSITY=="NotMZ" & pairData$Gender_T1=="M" & pairData$Gender_T2=="F")]<-6

# Zygosity of sib pairs
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="F" & pairData$Gender_T2=="F")]<-3
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="M" & pairData$Gender_T2=="M")]<-4
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="F" & pairData$Gender_T2=="M")]<-5
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="M" & pairData$Gender_T2=="F")]<-6

# Zygosity of twin-sib pairs
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="F" & pairData$Zygosity_T1=="MZ")]<-1
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="M" & pairData$Zygosity_T1=="MZ")]<-2

pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="F" & pairData$Zygosity_T1=="NotMZ")]<-5
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="M" & pairData$Zygosity_T1=="NotMZ")]<-6

# Sib-sib pairs
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="F" & pairData$Zygosity_T1=="NotTwin")]<-5
pairData$ZYGOSITY[ which(is.na(pairData$ZYGOSITY) & pairData$Gender_T1=="M" & pairData$Zygosity_T1=="NotTwin")]<-6


table(pairData$ZYGOSITY, exclude=NULL)
pairData[which(is.na(pairData$ZYGOSITY)),c("Zygosity_T1","Zygosity_T2","Zygosity_Sib")]


# SINGLETONS
# Singletons T1
familyID_singleT1<-data$famid[which(data$famid %in% familyID_single & data$Zygosity!="NotTwin")]
familyID_singleSib<-data$famid[which(data$famid %in% familyID_single &  data$Zygosity=="NotTwin")]

singleData<-NULL
singleData<-apply(as.data.frame(familyID_singleT1), 1,
                  function(x) data[which(data$famid== x),]  )
singleDataT1 <- ldply(singleData, data.frame)
colnames(singleDataT1)<-paste(colnames(data), "_T1", sep="")

singleDataT1$ZYGOSITY<-NA
singleDataT1$ZYGOSITY[which(singleDataT1$Zygosity_T1=="MZ" & singleDataT1$Gender_T1=="F")]<-1
singleDataT1$ZYGOSITY[which(singleDataT1$Zygosity_T1=="MZ" & singleDataT1$Gender_T1=="M")]<-2
singleDataT1$ZYGOSITY[which(singleDataT1$Zygosity_T1=="NotMZ" & singleDataT1$Gender_T1=="F")]<-3
singleDataT1$ZYGOSITY[which(singleDataT1$Zygosity_T1=="NotMZ" & singleDataT1$Gender_T1=="M")]<-4


# Singleton Sib
singleData<-NULL
singleData<-apply(as.data.frame(familyID_singleSib), 1,
                  function(x) data[which(data$famid== x),]  )
singleDataSib <- ldply(singleData, data.frame)
colnames(singleDataSib)<-paste(colnames(data), "_Sib", sep="")

singleDataSib$ZYGOSITY<-NA
singleDataSib$ZYGOSITY[which( singleDataSib$Gender_Sib=="F")]<-5
singleDataSib$ZYGOSITY[which( singleDataSib$Gender_Sib=="M")]<-6


# Binding
totData<-rbind.fill(pairData, singleDataT1,  singleDataSib)

table(totData$ZYGOSITY, exclude = NULL)

# Writing output
write.table(totData, file="GeneticClusteringOutputPlots/HRC_SurfArea_n853_voxelAndCluster_OpenMxFormat_376Families.txt", sep="\t", row.names=F, col.names=T)

# Checking nb twin pairs
length(which(tripData$Zygosity_T1!="NotTwin" & tripData$Zygosity_T2!="NotTwin" )) # 146 twin pairs + sibling
# 38 sibling trios

length(which(twinSibData$Zygosity_T1!="NotTwin" )) # 38 twin-sib pairs
# 38 sib-sib pairs

length(which(twinData$Zygosity_T1!="NotTwin" )) # 33 twin pairs (no-sib)
# 0 extra sib pairs

146+33
plot(totData$Age_in_Yrs_T1, totData$Age_in_Yrs_T2)
length(which(totData$Zygosity_T1!="NotTwin" & totData$Zygosity_T2!="NotTwin" & is.na(totData$Subject_Sib) & totData$ZYGOSITY<3))
length(which(totData$Zygosity_T1!="NotTwin" & totData$Zygosity_T2!="NotTwin" & is.na(totData$Subject_Sib) & totData$ZYGOSITY>2))

75+71+38
14+19+38+38
76+33
14+19
75+71+14+19
184*3+109*2+83
293*2+83

# Check pairs with Lachlan's ones
lach<-read.csv("HCP_181_pairs.csv")
#data<-read.table("GeneticClusteringOutputPlots/HRC_SurfArea_n853_voxelAndCluster_OpenMxFormat_376Families.txt", sep="\t", header=T)

aa<-merge(lach, data[,c("Subject_T1", "Subject_T2")], by.x=c("Subject_01", "Subject_02"), by.y=c("Subject_T1", "Subject_T2"))
aa2<-merge(lach, data[,c("Subject_T1", "Subject_T2")], by.x=c("Subject_01", "Subject_02"), by.y=c("Subject_T2", "Subject_T1"))
bb<-lach[-which(lach$Subject_01 %in% aa$Subject_01),]

cc<-data[which(data$Subject_T1 %in% c(bb$Subject_01, bb$Subject_02)),c("Subject_T1", "Subject_T2", "Subject_Sib","ZYGOSITY", "Zygosity_T1", "Zygosity_T2", "Age_in_Yrs_T1", "Age_in_Yrs_T2", "Age_in_Yrs_Sib")]

famID<-data$famid[which(data$Subject %in% c(bb$Subject_01, bb$Subject_02))]
cc<-data[which(data$Subject %in% c(bb$Subject_01, bb$Subject_02)),c("Subject", "Zygosity", "Age_in_Yrs")]

dd<-data[which(data$famid %in% famID),c("Subject", "Zygosity", "Age_in_Yrs")]

data$Age_in_Yrs_T1
