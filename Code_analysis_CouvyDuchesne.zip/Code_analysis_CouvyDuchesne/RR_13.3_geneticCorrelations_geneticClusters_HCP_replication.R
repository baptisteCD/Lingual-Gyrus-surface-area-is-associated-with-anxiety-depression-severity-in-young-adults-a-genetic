# genetic correlation between R lingual surfarea
# Check heritabilities first?

source("RR_8.0_Genetic_correlations_function_openMx3_withPvalues_siblings.R")
source("RR_8.0_UnivACE_Continuous_Function_openMx3_extraSibling.R")
#source("RR_8.0_Univ_SaturatedModel_function_OpenMx3.R")


data<-read.table("GeneticClusteringOutputPlots/HRC_SurfArea_n853_voxelAndCluster_OpenMxFormat_376Families.txt", header=T, sep="\t")
colnames(data)

MZpairs<-data[which(!is.na(data$Subject_T1) & !is.na(data$Subject_T2) & data$ZYGOSITY<3),]
DZpairs<-data[which(!is.na(data$Subject_T2) & !is.na(data$Subject_T2) & data$ZYGOSITY>2),]

hist(c(data$DSM_AnxDep_sum_reg_T1, data$DSM_AnxDep_sum_reg_T2, data$DSM_AnxDep_sum_reg_Sib))

data$Gender_T1<-mxFactor(data$Gender_T1, levels=c("M", "F"))
data$Gender_T2<-mxFactor(data$Gender_T2, levels=c("M", "F"))
data$Gender_Sib<-mxFactor(data$Gender_Sib, levels=c("M", "F"))

#data$ageScore_T1[which(is.na(data$ageScore_T1))]<-999999
#data$ageScore_T2[which(is.na(data$ageScore_T2))]<-999999

###################################
# univariate heritability of cortical regions

# Significant cluster:
allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
#signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, resultCor$var)

#
#pheno<-allVars[1]
for (pheno in allVars){
univACE(data=data,
        variable=paste0(pheno,"_reg"),
        output=paste("GeneticClusteringOutputPlots/ACE_model_HCP", pheno,"_reg_geneticClusters_meanSAcorrected.csv",sep = ""),
        covariate=c("Gender"),
        ACEorADE="ACE")
}
univACE(data=data,
        variable=paste0(pheno,"_reg"),
        output=paste("GeneticClusteringOutputPlots/ADE_model_HCP", pheno,"_reg_geneticClusters_meanSAcorrected.csv",sep = ""),
        covariate=c("Gender"),
        ACEorADE="ADE")

data$DSM_Depr_Raw_reg_T1
# Heritability of the sphere score
univACE(data=data,
        variable="DSM_AnxDep_sum_reg",
        output="GeneticClusteringOutputPlots/ACE_model_DSM_AnxDep_sum_reg_HCP.csv",
        covariate=c("Gender"),
        ACEorADE="ACE")
univACE(data=data,
        variable="ASR_Anxd_Raw_reg",
        output="GeneticClusteringOutputPlots/ACE_model_ASR_Anxd_Raw_reg_HCP.csv",
        covariate=c("Gender"),
        ACEorADE="ACE")
univACE(data=data,
        variable="DSM_Anxi_Raw_reg",
        output="GeneticClusteringOutputPlots/ACE_model_DSM_Anxi_Raw_reg_HCP.csv",
        covariate=c("Gender"),
        ACEorADE="ACE")
univACE(data=data,
        variable="DSM_Depr_Raw_reg",
        output="GeneticClusteringOutputPlots/ACE_model_DSM_Depr_Raw_reg_HCP.csv",
        covariate=c("Gender"),
        ACEorADE="ACE")


# Genetic correlations (linear)
calculatePhenoGenoEnviroCor(data=data, variables=c("DSM_Anxi_Raw_reg", "DSM_Depr_Raw_reg"), output=paste("GeneticClusteringOutputPlots/GeneticCor_DSM_Depr_Raw_reg_DSM_Anxi_Raw_reg.csv", sep = ""))

calculatePhenoGenoEnviroCor(data=data, variables=c("ASR_Anxd_Raw_reg", "DSM_AnxDep_sum_reg"), output=paste("GeneticClusteringOutputPlots/GeneticCor_ASR_DSM_scores_reg.csv", sep = ""))

source("RR_8.0_Genetic_correlations_function_openMx3_withPvalues_siblings_H0_1.R")

calculatePhenoGenoEnviroCor(data=data, variables=c("DSM_Anxi_Raw_reg", "DSM_Depr_Raw_reg"), output=paste("GeneticClusteringOutputPlots/GeneticCor_DSM_Depr_Raw_reg_DSM_Anxi_Raw_reg_H0_1.csv", sep = ""))

calculatePhenoGenoEnviroCor(data=data, variables=c("ASR_Anxd_Raw_reg", "DSM_AnxDep_sum_reg"), output=paste("GeneticClusteringOutputPlots/GeneticCor_ASR_DSM_scores_reg_H0_1.csv", sep = ""))


# Get splines to run same model
ns(c(data$SurfAreaRight12_reg_T1, data$SurfAreaRight12_reg_T2, data$SurfAreaRight12_reg_Sib), df = 3)
data$SurfAreaRight12_regS1_T1<-NA
data$SurfAreaRight12_regS1_T2<-NA
data$SurfAreaRight12_regS1_Sib<-NA

data[,c("SurfAreaRight12_regS1_T1","SurfAreaRight12_regS1_T2","SurfAreaRight12_regS1_Sib")]<-ns(c(data$SurfAreaRight12_reg_T1, data$SurfAreaRight12_reg_T2, data$SurfAreaRight12_reg_Sib), df = 3)[,1]

calculatePhenoGenoEnviroCor(data=data, variables=c("SurfAreaRight12_regS1", "DSM_AnxDep_sum_reg"), output=paste("GeneticClusteringOutputPlots/GeneticCor_SurfAreaRight12_regS1_DSM_scores.csv", sep = ""))
data$SurfAreaRight12_T1

var<-allVars[1]
for (var in paste0(allVars, "_reg") ){
calculatePhenoGenoEnviroCor(data=data, variables=c("DSM_AnxDep_sum", var), output=paste("GeneticClusteringOutputPlots/GeneticCor_DSM_AnxDep_sum_reg", var,".csv", sep = ""))
}

# Get all Rg, Re and Rp in one table
res<-as.data.frame(matrix(0, nrow = length(allVars), ncol = 6))
rownames(res)<-allVars
colnames(res)<-c("Rp", "pvalRp", "Rg", "pvalRg","Re", "pvalRe")

for (var in allVars ){
  dat<-read.csv(paste0("GeneticClusteringOutputPlots/GeneticCor_DSM_AnxDep_sum_reg", var,"_reg.csv"), header=T)
  res[var,]<-c(dat["PhenoCor","estimate"],dat["PhenoCor","pvalue"],dat["GeneticCor","estimate"],dat["GeneticCor","pvalue"],dat["EnviroCor","estimate"],dat["EnviroCor","pvalue"])

}

write.csv(res, "GeneticClusteringOutputPlots/Rg_Re_Rp_HRC_replication_DSM_anxDep_voxelWise.csv", row.names=T)

hist(res$Rp)
hist(res$Re)








##############
# Genetic correlations between ICV, mean SA and CT with anxiety Depression
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "ICV"),
                            output="GeneticCor_anxDep_ICV_unReg.csv")
cor(c(data$anxDepScore_T1, data$anxDepScore_T2), c(data$ICV_T1, data$ICV_T2), use = "complete.obs")


calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "RSurfArea"),
                            output="GeneticCor_anxDep_RSurfArea_unReg.csv")
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "LSurfArea"),
                            output="GeneticCor_anxDep_LSurfArea_unReg.csv")

calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "RThickness"),
                            output="GeneticCor_anxDep_RThickness_unReg.csv")
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "LThickness"),
                            output="GeneticCor_anxDep_LThickness_unReg.csv")









# Regressed variables
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScoreReg", "R_lingual_surfavg_reg"),
                    output="GeneticCor_anxDep_RlingSA_Reg.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScore", "R_lingual_surfavg_reg"),
                    outputName="GeneticCor_anxDep_RlingSA_Reg.csv")


# With Splines
geneticCorrelations(data=data, variables=c("anxDepScoreB3", "R_lingual_surfavg_reg"),
                    outputName="GeneticCor_anxDepB3_RlingSA_Reg.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScoreB3", "R_lingual_surfavg_reg"),
                                outputName="GeneticCor_anxDepB3_RlingSA_Reg.csv")

# more regressed
geneticCorrelations(data=data, variables=c("anxDepScoreB3_reg", "R_lingual_surfavg_reg2"),
                    outputName="GeneticCor_anxDepB3_RlingSA_Reg2.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScoreB3_reg", "R_lingual_surfavg_reg2"),
                                outputName="GeneticCor_anxDepB3_RlingSA_Reg2.csv")


############### plot for posters with heritability of AnxDep and Rlingual Gyrus
# get the data for plotting in the right format
dataPlot<-matrix(0, ncol=2, nrow=1)
dataPlot<-as.data.frame(dataPlot)
colnames(dataPlot)<-c("Anxiety-Depression","Right Lingual Surface Area")
dataPlot[,"Anxiety-Depression"]<-c(0.39)
dataPlot[,"Right Lingual Surface Area"]<-c(0.61)


library(Hmisc)
pdf("Heritablity_AnxDep_RLSA.pdf", width = 10, height = 7)
par(oma=c(0,1,0,1), mfrow=c(1,1), xpd=NA)
bp<-barplot(as.matrix(dataPlot), col=c("blue", "darkblue"),space=c(0.5, 0.5) , beside = T,
            names.arg=c("Anxiety-Depression","Right Lingual Surface Area"), cex=1.5, cex.axis=1.5, ylim=c(0,1), ylab="Heritability", cex.lab=1.5)
errbar(bp, c(0.39, 0.61),yminus = c(0.27, 0.51),yplus =  c(0.51, 0.70), add=T, xlab="", cap = 0.2, cex=2, lwd = 2)
# Restore default clipping rect
par(mar=c(5, 4, 4, 2) + 0.1)
dev.off()



