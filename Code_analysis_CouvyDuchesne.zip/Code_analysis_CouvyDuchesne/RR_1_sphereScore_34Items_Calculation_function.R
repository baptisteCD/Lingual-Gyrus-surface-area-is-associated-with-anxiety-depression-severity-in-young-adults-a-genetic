
#This function computes the different Sphere Scores:

# Somatic distress (SOMA-6) - see Hickie 2001 paper -  somdis_sum
# Psychological distress (PSYCH-6) - see Hickie 2001 paper -  psydis_sum 
# Full sphere (SPHERE-34) - see Hansell 2012 paper - sphere_sum 
# Anxiety/depression (PSYCH-14) - see Hansell 2012 paper - anxdep_sum
# 2nd somatic distress measure (SOMA-10) - see Hansell 2012 paper - somdis2_sum 
# Fatigue - fatigue_sum 
# Neurasthenia -  neuras_sum 
# Somatisation - somat_sum 

#The variables are: 
# root: the root name of the sphere variables ("SPHEAR", "HWB" ...) 
# outputName: the name for an output .csv table (if "" the function does not write a .csv file) 
# variableWave : if longitudinal data, variable indicating the waves of the study. 
# (A dummy constant variable must be added to the table if non longitudinal)
# suffixWaves : the suffixes to apply to each sphere scores variables (if longitudinal) 
# ("" suffixe can be used for non longitudinal data) 
# NB: the function does not deal with missing values, they have to be identified when loading the tables

#Assumptions upon the dataset:
#The individual IDs are in a variable named "ID"
#The variables are "uncorrectly" codded:
# 1 = Sometimes/Never; 2 = Often; 3 = Most of the time and are therefore transformed


returnShereScores<-function(root, data, outputName, variableWave, suffixWaves){
  
  nbWaves<-length(table(variableWave))
  totalOutput<- matrix(unique(data$ID), ncol=1, nrow=length(unique(data$ID)))
  colnames(totalOutput)<-"ID"


  for (iii in 1:nbWaves){
    
    #Subset corresponding to wave i
    dataTemp<-subset(data, variableWave==as.numeric(names(table(variableWave))[iii]) ) 
     
    #Shpere variable names
    sphVars<-NULL
    sphVars<-colnames(data)[which(substr(colnames(data), 1, nchar(root))==root)]
    
    #Exclusion of the observations with only missing values (on the 34 items sphere)
    dataTemp<-dataTemp[which(rowSums(is.na(dataTemp[,sphVars]))<34),]   
    
    #Creation and initialisation of the output matrix
    output<-matrix(0, ncol=9, nrow=length(dataTemp[,1]))    
    scoreNames<-apply(as.data.frame(c( "somdis_sum","psydis_sum",  "sphere_sum", "anxdep_sum", "somdis2_sum", "fatigue_sum", "neuras_sum", "somat_sum")), 
                      1, function(x) paste(x, suffixWaves[iii], sep=""))
    colnames(output)<-c("ID", scoreNames)
    output<-as.data.frame(output)
    
     
    #Count of missing values per sphere questionnaire
    output$ID<-dataTemp$ID
    output$nbNAs<-rowSums(is.na(dataTemp[,sphVars]))
    
    #1st recoding (-1)
    dataTemp[, sphVars]<-dataTemp[, sphVars]-1
    
    #Computation of the first 2 scores somdis_sum and psydis_sum
        output[,scoreNames[1]]<-rowSums(dataTemp[, sphVars[c(6,16,17,25,30,31)]], na.rm=T) 
    output[,scoreNames[2]]<-rowSums(dataTemp[, sphVars[c(5,12,20,27,33,34)]], na.rm=T) 
      
        
    #2st recoding (3<-2)x<-sphVars[1]
    for (jjj in sphVars){
    dataTemp[which(dataTemp[,jjj]==2),jjj]<-1
    }
    
    is.na(c(0,1,2,NA))
    #Computation of the 6 other scores
    output[,scoreNames[3]]<-rowSums(dataTemp[, sphVars[c(1:34)]], na.rm=T) 
    output[,scoreNames[4]]<-rowSums(dataTemp[, sphVars[c(2,3,5,8,12,20,23,26,27,28,30,32,33,34)]], na.rm=T) 
    output[,scoreNames[5]]<-rowSums(dataTemp[, sphVars[c(1,7,10,13,14,16,17,24,25,29)]], na.rm=T) 
    output[,scoreNames[6]]<-rowSums(dataTemp[, sphVars[c(1,3,6,16,17,25,30,31,32)]], na.rm=T) 
    output[,scoreNames[7]]<-rowSums(dataTemp[, sphVars[c(2,7,8,9,10,11,14,18,22,23,26,28,29)]], na.rm=T) 
    output[,scoreNames[8]]<-rowSums(dataTemp[, sphVars[c(1,4,10,13,15,19,21,22,24,28)]], na.rm=T) 
    
    if (iii==1){
    totalOutput<-merge(totalOutput, output, by.x="ID", by.y="ID", all.y=T)
    }
    else if (iii>1){
      totalOutput<-merge(totalOutput, output, by.x="ID", by.y="ID", all=T)
    }
    
    }
  if (outputName!=""){
    write.table(totalOutput, file=outputName, row.names=F, col.names=T, sep=",")
  }
  return(totalOutput)
   
}


#################################################################################################
#APPLICATION
#################################################################################################
library(VennDiagram)


### TW ###
twsph<-read.csv("Sphere_IRT/rawData_Sphere_IRT/tw_twsph_BCD.csv", sep=",", header=T, na.strings="9")
TWSphere<-returnShereScores(root="SPHEAR", data=twsph, outputName="TW_SPHERE_2waves.csv",
                            variableWave=twsph$VISIT, suffixWaves=c("12yo", "14yo"))
table(twsph$VISIT)
sum(!is.na(TWSphere$somdis_sum14yo))
sum(!is.na(TWSphere$somdis_sum12yo))
table(twsph$VISIT,exclude=NULL)

#Overlap between the 2 waves
bb<-list(Wave1=twsph$ID0[which(twsph$VISIT==1)], Wave2=twsph$ID0[which(twsph$VISIT==2)])
venn.diagram(bb, filename="TW_wavesOverlap.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green"),
             alpha = 0.50)

### TA ###
forma<-read.csv("Sphere_IRT/rawData_Sphere_IRT/ta_forma_BCD.csv", sep=",", header=T, na.strings=c("99", "97", ""))
forma$dummy<-1
TA_forma_Sphere<-returnShereScores(root="HWB", data=forma, outputName="TAforma_SPHERE.csv",
                                   variableWave=forma$dummy, suffixWaves=c(""))

forma["8885102",]
###
formaw<-read.csv("Sphere_IRT/rawData_Sphere_IRT/ta_formaw_BCD.csv", sep=",", header=T,  na.strings=c("99", "97",""))
formaw$dummy<-1
TA_formaw_Sphere<-returnShereScores(root="HWB", data=formaw, outputName="TAformaw_SPHERE.csv",
                                   variableWave=formaw$dummy, suffixWaves=c(""))


###
formb<-read.csv("Sphere_IRT/rawData_Sphere_IRT/ta_formb_BCD.csv", sep=",", header=T , na.strings=c("99", "", "97"))
formb$dummy<-1
TA_formb_Sphere<-returnShereScores(root="HWB", data=formb, outputName="TAformb_SPHERE.csv",
                                    variableWave=formb$dummy, suffixWaves=c(""))

###
formbw<-read.csv("Sphere_IRT/rawData_Sphere_IRT/ta_formbw_BCD.csv", sep=",", header=T , na.strings=c("99", "", "97"))
formbw$dummy<-1
TA_formbw_Sphere<-returnShereScores(root="HWB", data=formbw, outputName="TAformbw_SPHERE.csv",
                                   variableWave=formbw$dummy, suffixWaves=c(""))


#Overlap between the databases
bb<-list(TAA=TA_forma_Sphere$ID, TAW=TA_formaw_Sphere$ID , TAB=TA_formb_Sphere$ID,
         TABW=TA_formbw_Sphere$ID)
venn.diagram(bb, filename="TA_overlaps.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green", "purple", "yellow"),
             alpha = 0.50)
#Small overlap between the studies (17 and 7), Ntotal=1939

# TA study merging: 
TAa<-read.csv("TAforma_SPHERE.csv", header=T, sep=",")
TAaw<-read.csv("TAformaw_SPHERE.csv", header=T, sep=",")
TAb<-read.csv("TAformb_SPHERE.csv", header=T, sep=",")
TAbw<-read.csv("TAformbw_SPHERE.csv", header=T, sep=",")

#suppress observations with only missing values
TAa<-TAa[which(rowSums( is.na(TAa))<8),]
TAaw<-TAaw[which(rowSums( is.na(TAaw))<8),]
TAb<-TAb[which(rowSums( is.na(TAb))<8),]
TAbw<-TAbw[which(rowSums( is.na(TAbw))<8),]

#Overlap between the databases
bb<-list(TAA=TAa$ID, TAW=TAaw$ID , TAB=TAb$ID, TABW=TAbw$ID)
venn.diagram(bb, filename="TA_overlaps_MissingValuesExcluded.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green", "purple", "yellow"),
             alpha = 0.50)
#No ovelap


#Therefore the databases can be simply rbinded
TAsphere<-rbind(TAa, TAaw, TAb, TAbw)
length(unique(TAsphere$ID))
write.table(TAsphere, file="TA_sphereScores_n1264.csv", col.names=T, row.names=F, sep=",")

### TM ###
###
mformaw<-read.csv("Sphere_IRT/rawData_Sphere_IRT/tm_formaw_BCD.csv", sep=",", header=T)
mformaw$dummy<-1
TM_formaw_Sphere<-returnShereScores(root="HWB", data=mformaw, outputName="TMmformaw_SPHERE.csv",
                                   variableWave=mformaw$dummy, suffixWaves=c(""))


mformbw<-read.csv("Sphere_IRT/rawData_Sphere_IRT/tm_formbw_BCD.csv", sep=",", header=T)
mformbw$dummy<-1
TM_formbw_Sphere<-returnShereScores(root="HWB", data=mformbw, outputName="TMmformbw_SPHERE.csv",
                                   variableWave=mformbw$dummy, suffixWaves=c(""))



mtmsph<-read.csv("Sphere_IRT/rawData_Sphere_IRT/tm_tmsph_BCD.csv", sep=",", header=T)
mtmsph$dummy<-1
TM_mtmsph_Sphere<-returnShereScores(root="SPHEAR", data=mtmsph, outputName="TMmtmsph_SPHERE.csv",
                                    variableWave=mtmsph$dummy, suffixWaves=c(""))




#Overlap between datafiles
bb<-list(TMA=TM_formaw_Sphere$ID, TMB=TM_formbw_Sphere$ID , TMsph=TM_mtmsph_Sphere$ID)
venn.diagram(bb, filename="TM_overlap.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green", "yellow"),
             alpha = 0.50)

# TM study merging: 
TMaw<-read.csv("TMmformaw_SPHERE.csv", header=T, sep=",")
TMbw<-read.csv("TMmformbw_SPHERE.csv", header=T, sep=",")
TMsph<-read.csv("TMmtmsph_SPHERE.csv", header=T, sep=",")

#suppress observations with only missing values
TMaw<-TMaw[which( rowSums(is.na(TMaw))<8),]
TMbw<-TMbw[which( rowSums(is.na(TMbw))<8),]
TMsph<-TMsph[which( rowSums(is.na(TMsph))<8),]


#Overlap between datafiles
bb<-list(TMA=TMaw$ID, TMB=TMbw$ID , TMsph=TMsph$ID)
venn.diagram(bb, filename="TM_overlap_MissingValuesExcluded.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green", "yellow"),
             alpha = 0.50)
#No overlap


#Therefore the databases can be simply rbinded
TMsphere<-rbind(TMaw, TMbw, TMsph)
length(unique(TMsphere$ID))
write.table(TMsphere, file="TM_sphereScores_n1513.csv", col.names=T, row.names=F, sep=",")

#######################################################################################
### Age computation

twinDemo<-read.csv("Sphere_IRT/rawData_Sphere_IRT/twininf_resv_BCD.csv", header=T, na.strings="")
twinDemo$ID<-twinDemo$TWID
twinDemo$DOB<-as.Date(twinDemo$DOB, format="%d-%m-%Y")

### TA ###
TA<-read.table("TA_sphereScores_n1264.csv", header=T, sep=",")
logTA<-read.csv("Sphere_IRT/rawData_Sphere_IRT/TA_maildate.csv", header=T, na.strings="#NULL!")
logTA$MAILDATE<-as.Date(logTA$MAILDATE, format="%d/%m/%Y")

TA<-ageAtQuestionnaire(sphereData=TA, logData=logTA, dateVisitVariable="MAILDATE",
                       DOBdata=twinDemo, DOBvariable="DOB", ageVariableName="ageTa")

sum(is.na(TA$ageTa))
#One individual has a missing age
IDNA<-TA$ID[which(is.na(TA$ageTa))]
#We can delete the ovservation whose ID is 99999999 (dummy ID)
TA<-TA[which(!is.na(TA$ageTa)),]

write.table(TA, file="TA_sphereScores_n1263_age.csv", col.names=T, row.names=F, sep=",")

### TM ###
TM<-read.table("TM_sphereScores_n1513.csv", header=T, sep=",")
logTM<-read.csv("Sphere_IRT/rawData_Sphere_IRT/tmlog_BCD.csv", header=T, na.strings="")
logTM$MAPSVIS1<-as.Date(logTM$MAPSVIS1, format="%d-%m-%Y")

TM<-ageAtQuestionnaire(sphereData=TM, logData=logTM, dateVisitVariable="MAPSVIS1", 
                       DOBdata=twinDemo, DOBvariable="DOB", ageVariableName="ageTm")
#Nb missing values: 
sum(is.na(TM$ageTm))

write.table(TM, file="TM_sphereScores_n1513_age.csv", col.names=T, row.names=F, sep=",")

### TW ###
TW<-read.table("TW_SPHERE_2waves.csv", header=T, sep=",")
logTW<-read.csv("Sphere_IRT/rawData_Sphere_IRT/twlog_BCD.csv", header=T, na.strings="")
logTW$FSTVIS<-as.Date(logTW$FSTVIS, format="%d-%m-%Y")
logTW$SECVIS<-as.Date(logTW$SECVIS, format="%d-%m-%Y")

TW<-ageAtQuestionnaire(sphereData=TW, logData=logTW, dateVisitVariable="FSTVIS", 
                      DOBdata=twinDemo, DOBvariable="DOB", ageVariableName="ageTw1")
TW<-ageAtQuestionnaire(sphereData=TW, logData=logTW, dateVisitVariable="SECVIS", 
                       DOBdata=twinDemo, DOBvariable="DOB", ageVariableName="ageTw2")
colnames(TW)<-c("ID", "somdis_sum_tw1" ,"psydis_sum_tw1","sphere_sum_tw1","anxdep_sum_tw1" ,"somdis2_sum_tw1",
                "fatigue_sum_tw1", "neuras_sum_tw1",  "somat_sum_tw1", "NbNAs_tw1","somdis_sum_tw2",  "psydis_sum_tw2",
                "sphere_sum_tw2",  "anxdep_sum_tw2",  "somdis2_sum_tw2", "fatigue_sum_tw2", "neuras_sum_tw2",
                "somat_sum_tw2", "NbNAs_tw2",  "ageTw1",   "ageTw2" )

wave1<-c("somdis_sum_tw1" ,"psydis_sum_tw1","sphere_sum_tw1","anxdep_sum_tw1" ,"somdis2_sum_tw1",
         "fatigue_sum_tw1", "neuras_sum_tw1",  "somat_sum_tw1")
wave2<-c("somdis_sum_tw2",  "psydis_sum_tw2", "sphere_sum_tw2",  "anxdep_sum_tw2",  "somdis2_sum_tw2",
         "fatigue_sum_tw2", "neuras_sum_tw2",  "somat_sum_tw2")

#Age is set to missing if no SPHERE score
TW$ageTw1[which(is.na(TW$somdis_sum_tw1))]<-NA
TW$ageTw2[which(is.na(TW$somdis_sum_tw2))]<-NA

#Nb missing values
TW[(which(is.na(TW$ageTw1) && is.na(TW$ageTw2))),]
#Always at least one age (for one of the timepoints)

write.table(TW, file="TW_sphereScores_n2020_age.csv", col.names=T, row.names=F, sep=",")

#######################################################################################
### Overlab between TA, TM and TW ###

TA<-read.table("TA_sphereScores_n1263_age.csv", header=T, sep=",")
TA$taLog<-1
TM<-read.table("TM_sphereScores_n1513_age.csv", header=T, sep=",")
TM$tmLog<-1
TW<-read.table("TW_sphereScores_n2020_age.csv", header=T, sep=",")
TW$tw1Log<-0
TW$tw1Log[which(!is.na(TW$ageTw1))]<-1
TW$tw2Log<-0
TW$tw2Log[which(!is.na(TW$ageTw2))]<-1

#Overlap between datafiles
bb<-list(TA=TA$ID, TM=TM$ID , TW=TW$ID)
venn.diagram(bb, filename="TA_TM_TW_overlap_MissingValuesExcluded.tiff",  col = "transparent",
             fill = c("cornflowerblue", "green", "yellow"),
             alpha = 0.50)
length(which(!is.na(TW$sphere_sum_tw1) & !is.na(TW$sphere_sum_tw2)))
length(which(!is.na(TW$ageTw1) & !is.na(TW$ageTw2)))

#Merging the datafiles
TAMW<-merge(TA, TW, by.x="ID", by.y="ID", all=T)
TAMW<-merge(TAMW, TM, by.x="ID", by.y="ID", all=T, suffixes=c("_ta", "_tm"))
TAMW$taLog[which(is.na(TAMW$taLog))]<-0
TAMW$tmLog[which(is.na(TAMW$tmLog))]<-0
TAMW$tw1Log[which(is.na(TAMW$tw1Log))]<-0
TAMW$tw2Log[which(is.na(TAMW$tw2Log))]<-0

table(TAMW$taLog)
table(TAMW$tmLog)
table(TAMW$tw1Log)
table(TAMW$tw2Log)

write.table(TAMW, file="TA-TM-TW_completeData.csv", col.names=T, row.names=F, sep=",")

### Writing the final TAMW database with covariates: zygosity, sex, multib (multiple birth)
### removal of dummy observations: ID=8000001 and ID=99999999
### Zygosity is assessed using genotyping data
TAMW<-read.table("TA-TM-TW_completeData.csv", header=T, sep=",")

#Computing anf fromatting logVariables
TAMW$totLog<-rowSums(TAMW[,c("taLog", "tmLog","tw1Log", "tw2Log")], na.rm=T)
table(TAMW$totLog)

TAMW<-merge(TAMW, twinDemo[,c("ID", "FAMID", "SEX", "ZYGOSITY", "BIRTHORD", "DOB", "MULTIB")], by.x="ID", by.y="ID", all.x=T)

#Zygosity check
mzZyg<-read.table("Sphere_IRT/GWAS_observed_MZpairs_R6.txt", header=F, sep="", na.strings="", fill=T)
dzZyg<-read.table("Sphere_IRT/GWAS_observed_DZpairs_R6.txt", header=F, sep="", na.strings="", fill=T)

TAMW$Zygbin_geno<-0
TAMW$Zygbin_geno[which(TAMW$ID %in% c(mzZyg[,2], mzZyg[,3], mzZyg[,4]))]<-1
TAMW$Zygbin_geno[which(TAMW$ID %in% c(dzZyg[,2], dzZyg[,3], dzZyg[,4]))]<-2

#3 misclassification are corrected
TAMW[which(TAMW$Zygbin_geno==1 & TAMW$ZYGOSITY==3),]
TAMW$ZYGOSITY[which(TAMW$Zygbin_geno==1 & TAMW$ZYGOSITY==3)]<-1
table(TAMW$Zygbin_geno, TAMW$ZYGOSITY, exclude=NULL)
write.table(TAMW, file="TA-TM-TW_completeData_covariate_n3312.csv", col.names=T, row.names=F, sep=",")

#Narelle Ns:
#1 sphere score
42+626+328+285
#2 scores
18+10+383+54+4+54
#3 scores
40+96+390
#4 scores: 129

#Overlap between 4 datafiles (4 sphere scores)
bb<-list(TA=TAMW$ID[which(TAMW$taLog==1)], TM=TAMW$ID[which(TAMW$tmLog==1)] , TW1=TAMW$ID[which(TAMW$tw1Log==1)], 
         TW2=TAMW$ID[which(TAMW$tw2Log==1)])
pdf("./TA_TM_TW_vennDiagram_exclduedMissingValues.pdf")
grid.obj<-venn.diagram(bb, filename=NULL,  col = "transparent",
             fill = c("cornflowerblue", "green", "yellow", "purple"),
             alpha = 0.50, cat.col=c("darkblue", "darkgreen", "orange", "darkorchid4"), 
             cex=1.5, cat.cex=2, label.col = c("orange", "white", "darkorchid4", "white", "white", "white",
                                               "white", "white", "darkblue", "white",
                                               "white", "white", "white", "darkgreen", "white"))
grid.draw(grid.obj)
dev.off()

#Descriptive tables for sphere scores and age
TAMW<-read.csv(file="TA-TM-TW_completeData_covariate_n3312.csv", header=T, sep=",")
### TW1 ###
mean(TAMW$ageTw1, na.rm=T)
sd(TAMW$ageTw1, na.rm=T)
range(TAMW$ageTw1, na.rm=T)
table(TAMW$SEX[which(TAMW$tw1Log==1)], exclude=NULL)/length(TAMW$SEX[which(TAMW$tw1Log==1)])
#
mean(TAMW$sphere_sum_tw1[which(TAMW$tw1Log==1)])
sd(TAMW$sphere_sum_tw1[which(TAMW$tw1Log==1)])
range(TAMW$sphere_sum_tw1[which(TAMW$tw1Log==1)])
length(which(TAMW$NbNAs_tw1>0))/sum(!is.na(TAMW$NbNAs_tw1))*100

### TW2 ###
mean(TAMW$ageTw2, na.rm=T)
sd(TAMW$ageTw2, na.rm=T)
range(TAMW$ageTw2, na.rm=T)
table(TAMW$SEX[which(TAMW$tw2Log==1)], exclude=NULL)/length(TAMW$SEX[which(TAMW$tw2Log==1)])
#
mean(TAMW$sphere_sum_tw2[which(TAMW$tw2Log==1)])
sd(TAMW$sphere_sum_tw2[which(TAMW$tw2Log==1)])
range(TAMW$sphere_sum_tw2[which(TAMW$tw2Log==1)])
length(which(TAMW$NbNAs_tw2>0))/sum(!is.na(TAMW$NbNAs_tw2))*100

### TM ###
mean(TAMW$ageTm, na.rm=T)
sd(TAMW$ageTm, na.rm=T)
range(TAMW$ageTm, na.rm=T)
table(TAMW$SEX[which(TAMW$tmLog==1)], exclude=NULL)/length(TAMW$SEX[which(TAMW$tmLog==1)])
#
mean(TAMW$sphere_sum_tm[which(TAMW$tmLog==1)])
sd(TAMW$sphere_sum_tm[which(TAMW$tmLog==1)])
range(TAMW$sphere_sum_tm[which(TAMW$tmLog==1)])
length(which(TAMW$nbNAs_tm>0))/sum(!is.na(TAMW$nbNAs_tm))*100

### TA ###
mean(TAMW$ageTa, na.rm=T)
sd(TAMW$ageTa, na.rm=T)
range(TAMW$ageTa, na.rm=T)
table(TAMW$SEX[which(TAMW$taLog==1)], exclude=NULL)/length(TAMW$SEX[which(TAMW$taLog==1)])
#
mean(TAMW$sphere_sum_ta[which(TAMW$taLog==1)])
sd(TAMW$sphere_sum_ta[which(TAMW$taLog==1)])
range(TAMW$sphere_sum_ta[which(TAMW$taLog==1)])
length(which(TAMW$nbNAs_ta>0))/sum(!is.na(TAMW$nbNAs_ta))*100


tiff("TA_TM_TW_ageHistograms.tif", height=300, width=900)
par(mfrow=c(1,4))
aa<-1.5
hist(TAMW$ageTw1, xlab="Age TW1",cex.lab=aa, cex.axis=aa, main="", ylim=c(0,1300))
hist(TAMW$ageTw2, xlab="Age TW2",cex.lab=aa,cex.axis=aa,main="", ylim=c(0,1300))
hist(TAMW$ageTm, xlab="Age TM" ,cex.lab=aa,cex.axis=aa,main="", ylim=c(0,1300))
hist(TAMW$ageTa, xlab="Age TA",cex.lab=aa, cex.axis=aa,main="", ylim=c(0,1300))
dev.off()

png("TA_TM_TW_ageHistograms.png", height=300, width=900)
par(mfrow=c(1,4))
aa<-1.5
hist(TAMW$ageTw1, xlab="Age TW1",cex.lab=aa, cex.axis=aa, main="", ylim=c(0,1300))
hist(TAMW$ageTw2, xlab="Age TW2",cex.lab=aa,cex.axis=aa,main="", ylim=c(0,1300))
hist(TAMW$ageTm, xlab="Age TM" ,cex.lab=aa,cex.axis=aa,main="", ylim=c(0,1300))
hist(TAMW$ageTa, xlab="Age TA",cex.lab=aa, cex.axis=aa,main="", ylim=c(0,1300))
dev.off()


#Nb of sphere scores (nb of time points)
table(TAMW$totLog, exclude=NULL)
