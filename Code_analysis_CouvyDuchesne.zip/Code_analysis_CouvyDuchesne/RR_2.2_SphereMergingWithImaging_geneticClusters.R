# Open SPHERE data calculated in all twins from TA, TW, TM
# Open processed subcortival volumes, cortical thickness, surface are
# Merge, N, and preliminary results

library(VennDiagram)

# FINAL SCORES (UPDATE November2015)
sphere<-read.table("../03_ENIGMA2/TA-TM-TW_completeData_covariate_nIRTscores_n3312.txt", header=T, sep="\t")

# Set age missing when participant excluded for incomplete questionnaire
sphere$ageTa[which(is.na(sphere$AnxDepFinal_TA_theta))]<-NA
sphere$ageTm[which(is.na(sphere$AnxDepFinal_TM_theta))]<-NA
sphere$ageTw2[which(is.na(sphere$AnxDepFinal_TW2_theta))]<-NA
sphere$ageTw1[which(is.na(sphere$AnxDepFinal_TW1_theta))]<-NA

# Exclude individuals with all sphere scores missing
sphere<-sphere[-which(rowSums(is.na(sphere[,c("ageTa", "ageTm" ,"ageTw2", "ageTw1")]))==4 ),]

# Some descriptive numbers
table(rowSums(is.na(sphere[,c("ageTa", "ageTm" ,"ageTw2", "ageTw1")])))
dim(sphere[which(rowSums(is.na(sphere[,c("ageTa", "ageTm" ,"ageTw2", "ageTw1")]))<=2 ),])
(126+722+587)/3277

# Structural phenotypes
# After excluding nucleus accumbens
surfAreaLeft<-read.csv("QTIM_data/GeneticClustering_12Final/lhSA_12clusters_1.1_rg_means_n1100.csv", sep=",", header=T)
colnames(surfAreaLeft)<-c("CAI_ID", paste("SurfAreaLeft", 1:12, sep=""))
surfAreaRight<-read.csv("QTIM_data/GeneticClustering_12Final/rhSA_12clusters_1.1_rg_means_n1100.csv", sep=",", header=T)
colnames(surfAreaRight)<-c("CAI_ID", paste("SurfAreaRight", 1:12, sep=""))
surfArea<-merge(surfAreaLeft, surfAreaRight, by="CAI_ID")

# Add vertex-wise data of cluster 12 (right SA)
# 94 vertices
surfAreaVertex<-read.csv("QTIM_data/GeneticClustering_12Final/rhSA_Cluster12_vertices.csv",  header=T)
surfArea<-merge(surfArea, surfAreaVertex, by="CAI_ID")

cortThickLeft<-read.csv("QTIM_data/GeneticClustering_12Final/lhCT_12clusters_1.1_rg_means_n1100.csv", sep=",", header=T)
colnames(cortThickLeft)<-c("CAI_ID", paste("CortThickLeft", 1:12, sep=""))
cortThickRight<-read.csv("QTIM_data/GeneticClustering_12Final/rhCT_12clusters_1.1_rg_means_n1100.csv", sep=",", header=T)
colnames(cortThickRight)<-c("CAI_ID", paste("CortThickRight", 1:12, sep=""))
cortThick<-merge(cortThickLeft, cortThickRight, by="CAI_ID")

# Cortical thickeness and surf Area are available on same individuals
cortSurf<-merge(surfArea, cortThick,  by="CAI_ID")
colnames(cortSurf)

# Get TWID matching CAI_ID for merging with other databases
log<-read.table("QTIM_data/QTIM_Analyses.txt", sep="\t", header=T)
log$X<-NULL
log$X.1<-NULL
log$X.2<-NULL
cortSurf<-merge(cortSurf, log, by="CAI_ID")
cortSurf<-cortSurf[-which(cortSurf$SAMPLE=="Rescan_T2"),]

# save all outputs and plots of this analysis in /GeneticClusteringOutputPlots
# VENN DIAGRAMS
venn.diagram(list(SPHERE=sphere$ID, CORTSURF=cortSurf$QIMR_ID), filename="GeneticClusteringOutputPlots/VennDiagram_sphere_CortSurf.png")
# 834 individuals with SPHERE score and CT/SA

# Final database
data<-merge(sphere, cortSurf, by.x="ID", by.y="QIMR_ID")
colnames(data)
table(data$SAMPLE)



# No QTIM participants from SAMPLE 12, 16_20, Rescan_T2 or T3 are in the sample
# We describe the QTRIM sample limited to SAMPLE 12_16, 16, 18 (age 16-18+)
qtim<-log[which(log$SAMPLE %in% c("12_16", "16", "18")),]
length(unique(qtim$QIMR_ID))
qtim<-qtim[-which(duplicated(qtim$QIMR_ID)),]

table(qtim$Excluded_reason_CTSA)

# Add age at QTIM for description of total QTIM sample
demo<-read.table("QTIM_data/DM.twininf_resv.txt", sep="\t", header=T)
demo<-demo[,c("TWID", "DOB", "SEX")]
qtim<-merge(qtim, demo, by.x="QIMR_ID", by.y="TWID")
qtim$DOB<-as.Date(qtim$DOB, format = "%Y-%m-%d")
qtim$SCANDATE<-as.Date(qtim$SCANDATE, format = "%d/%m/%Y")
qtim$ageScan<-as.numeric(qtim$SCANDATE-qtim$DOB)/365.25
qtim<-qtim[which(qtim$SEX %in% c("F", "M")),]
sd(qtim$ageScan)
summary(qtim$ageScan)
prop.table(table(qtim$SEX))
1161-48-16-57

# Add ICV, mean SA and CT to use as covariates
SA<-read.csv("QTIM_data/CorticalMeasuresENIGMA_SurfAvg_2015_09_21.csv", sep=",", header=T)
CT<-read.csv("QTIM_data/CorticalMeasuresENIGMA_ThickAvg_2015_09_21.csv", sep=",", header=T)
VOL<-read.csv("QTIM_data/FS_5.3_Subcortical_2015_09_21.csv", sep=",", header=T)

SA<-SA[,c("TWID", "Magnet_age", "LSurfArea" , "RSurfArea",	"TSurfArea")]
CT<-CT[,c("TWID", "LThickness",  "RThickness",	"AvgThickness")]
VOL<-VOL[,c("TWID", "ICV",  "BrainSeg")]

data<-merge(data, SA, by.x="ID", by.y="TWID")
data<-merge(data, CT, by.x="ID", by.y="TWID")
data<-merge(data, VOL, by.x="ID", by.y="TWID")
colnames(data)

# Writing final database
write.table(data, "GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834.txt", sep="\t",col.names=T, row.names=F)
