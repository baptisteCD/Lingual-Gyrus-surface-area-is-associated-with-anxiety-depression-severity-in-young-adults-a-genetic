##  Open data base
# Run preliminary analysis

data<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834.txt", sep="\t", header=T)

colnames(data)


# Get SPHERE score closest to scan date
# With age
library(VennDiagram)
venn.diagram(list(Y18=data$ID[which(!is.na(data$AnxDepFinal_TA_theta))],
                  Y16=data$ID[which(!is.na(data$AnxDepFinal_TM_theta))],
                  Y14=data$ID[which(!is.na(data$AnxDepFinal_TW2_theta))],
                  Y12=data$ID[which(!is.na(data$AnxDepFinal_TW1_theta))]),
             "GeneticClusteringOutputPlots/VennDiagram_sphereScoreWaves.png")
colnames(data)
# Add age at scan
data$SCANDATE<-as.Date(data$SCANDATE, format="%d/%m/%Y")
data$DOB<-as.Date(data$DOB, format="%Y-%m-%d")
data$ageScan<-(data$SCANDATE-data$DOB)/365.25
data$ageScan<-as.numeric(data$ageScan)
hist(data$ageScan)

data$anxDepScore<-NULL
data$fatigueScore<-NULL
data$somatisationScore<-NULL
data$somaticDistressScore<-NULL
data$neurastheniaScore<-NULL
data$anxDepScoreSS<-NULL
data$fatigueScoreSS<-NULL
data$somatisationScoreSS<-NULL
data$somaticDistressScoreSS<-NULL
data$neurastheniaScoreSS<-NULL
data$ageScore<-NULL
data$sphereStudy<-NULL


# First the age closest to the sge of scan is stored in ageScore
for (iii in 1:length(data$ID)){
  timeDiff<-abs(data[iii,c("ageTa", "ageTm" ,"ageTw2", "ageTw1")]-data[iii,"ageScan"])
  ageToKeep<-names(which.min(timeDiff))
  data$ageScore[iii]<-data[iii,ageToKeep]
}
hist(data$ageScore)
mean(data$ageScore)

# The corresponding Sphere scores are also collected
for (iii in 1:length(data$ID)){

if ( !((data$ageScore[iii]==data$ageTa[iii]) %in% c(F, NA)) ) {
  data$anxDepScore[iii]<-data$AnxDepFinal_TA_theta[iii]
  data$fatigueScore[iii]<-data$ChronicFatigueFinal_TA_theta[iii]

  data$anxDepScoreSS[iii]<-data$AnxDepFinal_TA_sscore[iii]
  data$fatigueScoreSS[iii]<-data$ChronicFatigueFinal_TA_sscore[iii]
  data$sphereStudy[iii]<-"TA"

} else if (!((data$ageScore[iii]==data$ageTm[iii]) %in% c(F, NA))){
  data$anxDepScore[iii]<-data$AnxDepFinal_TM_theta[iii]
  data$fatigueScore[iii]<-data$ChronicFatigueFinal_TM_theta[iii]

  data$anxDepScoreSS[iii]<-data$AnxDepFinal_TM_sscore[iii]
  data$fatigueScoreSS[iii]<-data$ChronicFatigueFinal_TM_sscore[iii]
  data$sphereStudy[iii]<-"TM"

} else if (!((data$ageScore[iii]==data$ageTw2[iii]) %in% c(F, NA))){
  data$anxDepScore[iii]<-data$AnxDepFinal_TW2_theta[iii]
  data$fatigueScore[iii]<-data$ChronicFatigueFinal_TW2_theta[iii]

  data$anxDepScoreSS[iii]<-data$AnxDepFinal_TW2_sscore[iii]
  data$fatigueScoreSS[iii]<-data$ChronicFatigueFinal_TW2_sscore[iii]
  data$sphereStudy[iii]<-"TW2"

} else if (!((data$ageScore[iii]==data$ageTw1[iii]) %in% c(F, NA))){
  data$anxDepScore[iii]<-data$AnxDepFinal_TW1_theta[iii]
  data$fatigueScore[iii]<-data$ChronicFatigueFinal_TW1_theta[iii]

  data$anxDepScoreSS[iii]<-data$AnxDepFinal_TW1_sscore[iii]
  data$fatigueScoreSS[iii]<-data$ChronicFatigueFinal_TW1_sscore[iii]
  data$sphereStudy[iii]<-"TW1"
}

}

hist(data$ageScore- data$ageScan)

##################
# Add some extra variables
# We might control for time difference between age at score and age at scan
data$ageDiff<-NULL
data$ageDiff<-data$ageScan-data$ageScore # all scans follow scoring

data$SEX01<-0
data$SEX01[which(data$SEX=="M")]<-1
table(is.na(data$ICV), exclude = NULL)

data$Sample16<-ifelse(data$SAMPLE=="16", 1,0)
data$Sample1216<-ifelse(data$SAMPLE=="12_16", 1,0)
data$Sample18<-ifelse(data$SAMPLE=="18", 1,0)
table(data$Sample18, data$SAMPLE)

write.table(data, "GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t", col.names=T, row.names=F)

####################################################
# Sample description
data<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t",stringsAsFactors=F,
                 header=T)

data$famid<-substr(data$ID, 1,5)
length(unique(data$famid))
table(data$FAMID, exclude = NULL)

table(data$SAMPLE)
# Age distributions
data$SurfAreaLeft1
colnames(data)[ grep("SurfArea", colnames(data), fixed = TRUE)]

rowSums(is.na(data[, colnames(data)[ grep("SurfArea", colnames(data), fixed = TRUE)]]))

