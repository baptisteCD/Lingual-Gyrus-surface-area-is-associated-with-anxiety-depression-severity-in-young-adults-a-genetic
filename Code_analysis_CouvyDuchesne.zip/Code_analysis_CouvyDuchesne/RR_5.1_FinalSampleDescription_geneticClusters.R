############
# DEMOGRAPHICS OF FINAL SAMPLE
library(splines)
citation("splines")
data<-read.table("/Users/uqbcouvy/Documents/MyDocuments/09_Sphere_StructuralImaging/GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t", header=T)

prop.table(table(data$SEX, exclude = NULL))

mean(data$ageScan,na.rm = T)
range(data$ageScan,na.rm = T)

sd(data$ageScan,na.rm = T)

mean(data$ageScore)
range(data$ageScore,na.rm = T)
sd(data$ageScore,na.rm = T)

mean(data$ageScan-data$ageScore)
sd(data$ageScan-data$ageScore)
range(data$ageScan-data$ageScore)
show_col( dichromat_pal(name ="SteppedSequential.5")(20)[c(1,6,11,16)])
# Plot scree plot / silhouette plot
library(scales)
sil<-read.table("Manuscript/ScreePlot_data_1.1.txt", sep='\t', header=T)
cols<-( dichromat_pal(name ="SteppedSequential.5")(20)[c(1,6,11,16)])

tiff("GeneticClusteringOutputPlots/SilhouetteCoefficient.tiff",  width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,1.1,1.1))
plot(1:29, sil[,1], xlab="Number of Clusters", ylab="Silhouette Coefficient", ylim=c(0.2,0.5), col="white", cex.lab=2, cex.axis=1.5)
lwdx<-5
lines(1:29, sil[,1],col =  cols[1], lwd = lwdx)
lines(1:29, sil[,2],col =  cols[2], lwd = lwdx)
lines(1:29, sil[,3],col =  cols[3], lwd = lwdx)
lines(1:29, sil[,4],col =  cols[4], lwd = lwdx)
lines(1:29, rowMeans(sil),col =  "black", lwd = lwdx)
abline(v=12, lty=2)

legend(17, 0.30, legend = c("left CT",  "right CT",	"left SA"	,"right SA", "mean"), col = c(cols, "black"), lwd = lwdx, box.col = "transparent", cex = 1.5)
dev.off()
# Plot genetic clusters
# Need correct basefile

data <- read.table("Image_render/lhCT.12abs.1.5.txt", sep = "\t", header = F)  # Cluster map for Freesurfer (values of -2 are non-cortical regions)
Vars <- c("-2", "-1", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12")
table()
data<-data[-which(data$V5==-2),]

# Left ct clustering
clust <- read.csv("QTIM_data/GeneticClustering_12Final/lhCT_12clusters_1.1.csv", header=T)
clust$rowNb<-as.numeric(gsub("[^0-9]", "", clust$X))

# Replace cluster membership value
clust<-clust[order(clust$rowNb,decreasing = F),]
data$V5<-clust$x

# Write into an asc file that we can convert back into a freesurfer format
write.table(data[,1:5], "Image_render/GeneticClustering_12Final/lhCT_12clusters.asc", sep = ' ', row.names = F, col.names = F)
getwd()
# Convert to freesurfer to plot with Freeview
# mris_convert -c ./lhCT_12clusters.asc $SUBJECTS_DIR/fsaverage4/surf/lh.orig ./lhCT_12clusters.mgh
