#####
# Association of all brain phenotypes with Sphere score (for Anxiety/Depression)
# The number of independent brain phenotypes has been calcualted by Sarah
# Bonferroni-Sidak correction is used to correct p-values
# Mixed models on family ID used to take into account relatedness

library(scales)
library(hglm)
library(ggplot2)
library(bigmemory)
library(qqman)
library(splines)
citation("hglm")
dat<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t", header=T)
colnames(data)
# Correlation ICV, surface areas
cor(data$RSurfArea, data$LSurfArea, use = "complete.obs")
cor(data$RSurfArea, data$TSurfArea, use = "complete.obs")
cor(data$LSurfArea, data$TSurfArea, use = "complete.obs")

cor(data$RThickness, data$LThickness, use = "complete.obs")
cor(data$RThickness, data$AvgThickness, use = "complete.obs")
cor(data$LThickness, data$AvgThickness, use = "complete.obs")

range(dat$ageScan-dat$ageScore)

table(data$SAMPLE)
94+4*12
#################################################
# GRM matrix
# Open kinship matrix
start.time<-proc.time()
kinshipDM<-read.big.matrix(filename = "/Users/b.couvy-duchesne/Documents/MyDocuments/12_LinearRegression_familyStructure/kinship_matrix_17902individuals_DMstudy.txt", sep = "\t", header = T)
end.time<-proc.time()
save.time<-end.time-start.time
paste("Number of minutes running:",  save.time[3]/60)

# Load subset function to create kinship matrices
source("/Users/b.couvy-duchesne/Documents/MyDocuments/12_LinearRegression_familyStructure/RR_2_ExtractKinshipMatrixFromDM_function.R")
kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = data$ID)


# List of brain phenotypes for Cortical Thickness and surface area
colnames(data)
CTvars<-colnames(data)[grepl(colnames(data), pattern="CortThick")]
SAvars<-colnames(data)[grepl(colnames(data), pattern="SurfArea")][1:24]
VertexVars<-colnames(data)[grepl(colnames(data), pattern="VertexNum")]

#C3vars<-colnames(data)[grepl(colnames(data), pattern="SurfAreaRightC3")]
#C3C4vars<-colnames(data)[grepl(colnames(data), pattern="SurfAreaRightC3C4")]
#vertexVars<-colnames(data)[grepl(colnames(data), pattern="X",ignore.case = F)][2:48]


###########################
# fit HGLM models that account for relatedness
# 1) Linear association of Anxiety-Depression with structural phenotypes
###########################

# Lists of regressors names for formatting results
regressors<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3", "Sample16", "Sample18",  "ACQUISITION", "tmStudy","tw1Study","tw2Study", "anxDepScore")
regressorsAllSA<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3", "Sample16", "Sample18",  "ACQUISITION", "tmStudy","tw1Study","tw2Study", "TSurfArea", "anxDepScore")
regressorsAllCT<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3", "Sample16", "Sample18",  "ACQUISITION", "tmStudy","tw1Study","tw2Study", "AvgThickness", "anxDepScore")

#Vector of regressor variables to run models (and exclude missing values)
VarRegressors<-c("SEX", "ageScan","ageDiff","Sample16", "Sample18",  "ACQUISITION","sphereStudy", "anxDepScore")
VarRegressorsSA<-c("SEX", "ageScan","ageDiff","Sample16", "Sample18",  "ACQUISITION","sphereStudy", "anxDepScore", "TSurfArea")
VarRegressorsCT<-c("SEX", "ageScan","ageDiff","Sample16", "Sample18",  "ACQUISITION","sphereStudy", "anxDepScore", "AvgThickness")

table(data$sphereStudy,is.na(data$anxDepScore), exclude=NULL)
colSums(is.na(data[,VarRegressors]))
table(rowSums(is.na(data[,VarRegressors])))

##############################
##############################
 # SA

allVars<-c(SAvars)
regressorsAll<-regressorsAllSA

result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

    m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(SAMPLE) + factor(ACQUISITION) +  factor(sphereStudy) + anxDepScore"), data = data),verbose = T, vcovmat = T, Z =kinMatSACT , data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x*sd(data$anxDepScore)/sd(data[,var]),na.rm=T) )

  # Correcting for ICV
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(SAMPLE) + factor(ACQUISITION) +  factor(sphereStudy) + TSurfArea + anxDepScore"), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x*sd(data$anxDepScore)/sd(data[,var]),na.rm=T) )

}
summary(m1.hglm)

result[which(result$pval_anxDepScore<0.05 ),]
resultCor[which(resultCor$pval_anxDepScore<0.0005),]

write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_final.txt", sep="\t", col.names=T, row.names=F)
write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_Corrected_final.txt", sep="\t", col.names=T, row.names=F)



##############################
# CT
#############################
allVars<-c(CTvars)
regressorsAll<-regressorsAllCT

result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(SAMPLE) + factor(ACQUISITION) +  factor(sphereStudy) + anxDepScore"), data = data),verbose = F, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x*sd(data$anxDepScore)/sd(data[,var]),na.rm=T) )

  # Correcting for avg Thickness
  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(SAMPLE) + factor(ACQUISITION) +  factor(sphereStudy) + AvgThickness  + anxDepScore "), data = data),verbose = F, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x*sd(data$anxDepScore)/sd(data[,var]),na.rm=T) )

}


result[which(result$pval_anxDepScore<0.0005 ),]
resultCor[which(resultCor$pval_anxDepScore<0.0005),]

result$effectSize_anxDepScore
resultCor$effectSize_anxDepScore

write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_final.txt", sep="\t", col.names=T, row.names=F)
write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_Corrected_final.txt", sep="\t", col.names=T, row.names=F)


##################################
# QQ plot of all the pvalues for anxiety depression
# linear model
resSA<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_final.txt", sep="\t", header=T)
resCT<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_final.txt", sep="\t", header=T)
resSAC<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_Corrected_final.txt", sep="\t", header=T)
resCTC<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_Corrected_final.txt", sep="\t", header=T)

resSAC$effectSize_anxDepScore

library(qqman)
tiff("GeneticClusteringOutputPlots/QQplot_linearModels_hglm.tiff", width=20, height=20, units="cm",
     res=600, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,2.1))
qq(c( resCT$pval_anxDepScore ,resSA$pval_anxDepScore), cex.lab=2, cex.axis=2)
dev.off()

tiff("GeneticClusteringOutputPlots/QQplot_linearModels_hglm_corrected.tiff", width=20, height=20, units="cm",
     res=600, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,2.1))
qq(c( resCTC$pval_anxDepScore ,resSAC$pval_anxDepScore), cex.lab=2, cex.axis=2)
dev.off()

min(c( resCTC$pval_anxDepScore ,resSAC$pval_anxDepScore))
min(c( resCT$pval_anxDepScore ,resSA$pval_anxDepScore))

range(c( resCTC$effectSize_anxDepScore ,resSAC$effectSize_anxDepScore))
range(c( resCT$effectSize_anxDepScore ,resSA$effectSize_anxDepScore))

######################################################################
# Non linear association using basic cubic splines
######################################################################

regressors<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")
regressorsAllSA<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"TSurfArea", "anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")
regressorsAllCT<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"AvgThickness", "anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")


# winsorise sum scores
mean(data$anxDepScoreSS)+4*sd(data$anxDepScoreSS)
data$anxDepScoreSS[which(data$anxDepScoreSS>20)]<-20
hist(data$anxDepScoreSS)

#################
# SA
#################
allVars<-c(SAvars)
regressorsAll<- regressorsAllSA
result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScoreSS, df=3)"), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

  # Correcting for mean surface area
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + TSurfArea + ns(anxDepScoreSS, df=3) "),data = data),verbose = T, vcovmat = T,Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

}
summary(m1.hglm)
signif<-5.2E-4
result[which(result$pval_anxDepScoreS1< signif |  result$pval_anxDepScoreS2< signif | result$pval_anxDepScoreS3< signif),]
resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),]

#write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_final.txt", sep="\t", col.names=T, row.names=F)
#write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_final.txt", sep="\t", col.names=T, row.names=F)

#write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDepSS_SA_nonLinear_final.txt", sep="\t", col.names=T, row.names=F)
#write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDepSS_SA_nonLinear_Corrected_final.txt", sep="\t", col.names=T, row.names=F)

#################
# SA vertex wise
#################
allVars<-VertexVars
regressorsAll<- regressorsAllSA
result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScoreSS, df=3)"), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

  # Correcting for mean surface area
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + TSurfArea + ns(anxDepScoreSS, df=3) "),data = data),verbose = T, vcovmat = T,Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

}

signif<-0.00042
result[which(result$pval_anxDepScoreS1< signif |  result$pval_anxDepScoreS2< signif | result$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS3")]
resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")]

dim(resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),])

write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDepSS_SA_nonLinear_VertexWise.txt", sep="\t", col.names=T, row.names=F)
write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDepSS_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", col.names=T, row.names=F)

resultCor$corCub<-NA
for (iii in VertexVars){
resultCor$corCub[which(resultCor$var==iii)]<-resultCor$beta_anxDepScoreS3[which(resultCor$var==iii)]*sd(ns(data$anxDepScoreSS, df=3)[,3])/sd(data[,iii])
}
warnings()
result<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_VertexWise.txt", sep="\t", header=T)
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T)

signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< signif),]
range(signifRes$pval_anxDepScoreS3)
range(signifRes$corCub)
signifRes$var

#################
# CT
#################
allVars<-c(CTvars)
regressorsAll<- regressorsAllCT
result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScoreSS, df=3)"), data = data),verbose = T, vcovmat = T,
                    Z = kinMatSACT, data=data,  family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

  # Correcting for ICV
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + AvgThickness + ns(anxDepScoreSS, df=3) "), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

}

signif<-0.00052
result[which(result$pval_anxDepScoreS1< signif |  result$pval_anxDepScoreS2< signif | result$pval_anxDepScoreS3< signif),]
resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),]

min(resultCor$pval_anxDepScoreS1)

write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_nonLinear_final.txt", sep="\t", col.names=T, row.names=F)
write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_nonLinear_Corrected_final.txt", sep="\t", col.names=T, row.names=F)

########################
 # QQ plots
########################
resSA<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_final.txt", sep="\t", header=T)
resCT<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_nonLinear_final.txt", sep="\t", header=T)
resSAC<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDepSS_SA_nonLinear_Corrected_final.txt", sep="\t", header=T, stringsAsFactors = F)
resCTC<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_CT_nonLinear_Corrected_final.txt", sep="\t", header=T)

resSAC[which(resSAC$pval_anxDepScoreS1< signif |  resSAC$pval_anxDepScoreS2< signif | resSAC$pval_anxDepScoreS3< signif),c("beta_anxDepScoreS1","beta_anxDepScoreS2","beta_anxDepScoreS3", "betaSd_anxDepScoreS1","betaSd_anxDepScoreS2","betaSd_anxDepScoreS3","pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")]

resSAC$pval_anxDepScoreS1

resSAC$effectSize_anxDepScoreS3

library(qqman)
tiff("GeneticClusteringOutputPlots/QQplot_nonlinearModels_hglm.tiff", width=20, height=20, units="cm",
     res=600, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,2.1))
qq(c(resCT$pval_anxDepScoreS1 , resCT$pval_anxDepScoreS2 , resCT$pval_anxDepScoreS3,
     resSA$pval_anxDepScoreS1, resSA$pval_anxDepScoreS2, resSA$pval_anxDepScoreS3 ), cex.lab=2, cex.axis=2)
dev.off()

tiff("GeneticClusteringOutputPlots/QQplot_nonlinearModels_hglm_corrected.tiff", width=20, height=20, units="cm",
     res=600, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,2.1))
qq(c(resCTC$pval_anxDepScoreS1 , resCTC$pval_anxDepScoreS2 , resCTC$pval_anxDepScoreS3,
     resSAC$pval_anxDepScoreS1, resSAC$pval_anxDepScoreS2, resSAC$pval_anxDepScoreS3 ), cex.lab=2, cex.axis=2)
dev.off()

#
signif<-0.0005
resSAC[which(resSAC$pval_anxDepScoreS1< signif |  resSAC$pval_anxDepScoreS2< signif | resSAC$pval_anxDepScoreS3< signif),]
resSA[which(resSA$pval_anxDepScoreS1< signif |  resSA$pval_anxDepScoreS2< signif | resSA$pval_anxDepScoreS3< signif),]

resCTC[which(resCTC$pval_anxDepScoreS1< signif |  resCTC$pval_anxDepScoreS2< signif | resCTC$pval_anxDepScoreS3< signif),]
resCT[which(resCT$pval_anxDepScoreS1< signif |  resCT$pval_anxDepScoreS2< signif | resCT$pval_anxDepScoreS3< signif),]

min(c( resCTC$pval_anxDepScoreS1, resCTC$pval_anxDepScoreS2, resCTC$pval_anxDepScoreS3 ,resSAC$pval_anxDepScoreS1, resSAC$pval_anxDepScoreS2, resSAC$pval_anxDepScoreS3))
min(c( resCT$pval_anxDepScoreS1, resCT$pval_anxDepScoreS2, resCT$pval_anxDepScoreS3 ,resSA$pval_anxDepScoreS1, resSA$pval_anxDepScoreS2, resSA$pval_anxDepScoreS3))


0.0014/3
3.7E-4*36*3

###########################################################
# Normalise effect sizes
resSAC<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T)
# Calculate normalised effect sizes (correlation coefficients)
resSAC$rCubic<-NA
for (var in VertexVars){
  resSAC$rCubic[which(resSAC$var==var)]<-resSAC$beta_anxDepScoreS3[which(resSAC$var==var)]*sd(ns(data$anxDepScore, df=3)[,3])/sd(data[,var])
}
range(resSAC$rCubic[which(resSAC$pval_anxDepScoreS3<4.2E-4)])
write.table(resSAC, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise_rCubic.txt", sep="\t", row.names=F, col.names=T)

sd(ns(data$anxDepScore, df=3)[,3])
as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])*sd(ns(data$anxDepScore, df=3)[,3])/sd(data$SurfAreaRight12)
as.matrix(summary(m1.hglm)$FixCoefMat[,1][16])*sd(ns(data$anxDepScore, df=3)[,3])/sd(data$SurfAreaRight12)

resSAC$pval_anxDepScoreS3[which(resSAC$var==var)]


##########################################################
# Re run the models of interest and compare them
# visualise results
data<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t", header=T)

#data[548,c("ID","anxDepScore", "anxDepScoreSS")]
#data<-data[-which(data$ID=="8645601"),]

mean(data$anxDepScoreSS)+4*sd(data$anxDepScoreSS)
data$anxDepScoreSS[which(data$anxDepScoreSS>20)]<-20
hist(data$anxDepScoreSS)
#data<-data[-which(data$anxDepScoreSS>20),]


kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = data$ID)
#kinMatSACT2<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = data$ID)*2

#kinMat2<-as.matrix(nearPD(kinMatSACT2)$mat)
kinMat<-as.matrix(nearPD(kinMatSACT)$mat)

var="SurfAreaRight12"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data[,var],  X = model.matrix(as.formula("~   factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScoreSS, df=3)"),  data = data),verbose = T, vcovmat = T, Z = t(chol(kinMat)), data=data,  family = gaussian(link = "identity"), calc.like = T)
summary(m1.hglm)
shapiro.test(m1.hglm$resid)

m1.hglm$varRanef/(m1.hglm$varFix + m1.hglm$varRanef)
lrt(hglm.obj1 = m1.hglm)

plot(colnames(kinMatSACT), data$ID)


#############################
# Testing HGLM
data$ICV

matPD<-nearPD(as.matrix(kinshipDM))
matPDChol<-chol(matPD)
data$sphereStudy
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data$anxDepScoreSS,  X = model.matrix(as.formula("~   ageScore + factor(SEX) + factor(sphereStudy) "),  data = data),verbose = T,  Z = t(chol(kinMat)), data=data,  family = gaussian(link = "identity"), calc.like = T)
summary(m1.hglm)
shapiro.test(m1.hglm$resid)
m1.hglm$varRanef/(m1.hglm$varFix + m1.hglm$varRanef)
lrt(m1.hglm)

# Correcting for ICV, mean cor thickness or mean surface area
m0.hglm <-   hglm(y =  data$anxDepScoreSS,  X = model.matrix(as.formula("~   ageScore + factor(SEX) + factor(sphereStudy) "),  data = data),verbose = T,  Z = t(chol(kinMat*2)), data=data,  family = gaussian(link = "identity"), calc.like = T)
#summary(m1.hglm)
shapiro.test(m0.hglm$resid)

m1.hglm$varRanef/(m1.hglm$varFix + m1.hglm$varRanef)
m0.hglm$varRanef/(m0.hglm$varFix + m0.hglm$varRanef)
lrt(m0.hglm)


m1.hglm <-   hglm(y =  data$ICV,  X = model.matrix(as.formula("~   ageScan + factor(SEX) + factor(ACQUISITION) "),  data = data),verbose = T,  Z = t(chol(kinMat)), data=data,  family = gaussian(link = "identity"), calc.like = T)
m0.hglm <-   hglm(y =  data$ICV,  X = model.matrix(as.formula("~   ageScan + factor(SEX) + factor(ACQUISITION) "),  data = data),verbose = T,  Z = t(chol(kinMat2)), data=data,  family = gaussian(link = "identity"), calc.like = T)
m1.hglm$varRanef/(m1.hglm$varFix + m1.hglm$varRanef)
m0.hglm$varRanef/(m0.hglm$varFix + m0.hglm$varRanef)

m1.hglm <-   hglm(y =  data$TSurfArea,  X = model.matrix(as.formula("~   ageScan + factor(SEX) + factor(ACQUISITION) "),  data = data),verbose = T,  Z = t(chol(kinMat)), data=data,  family = gaussian(link = "identity"), calc.like = T)
m0.hglm <-   hglm(y =  data$TSurfArea,  X = model.matrix(as.formula("~   ageScan + factor(SEX) + factor(ACQUISITION) "),  data = data),verbose = T,  Z = t(chol(kinMat2)), data=data,  family = gaussian(link = "identity"), calc.like = T)
m1.hglm$varRanef/(m1.hglm$varFix + m1.hglm$varRanef)
m0.hglm$varRanef/(m0.hglm$varFix + m0.hglm$varRanef)

# effect size
summary(m1.hglm)$FixCoefMat[,1][18]*sd(ns(data$anxDepScoreSS, df=3)[,3])/sd(data$SurfAreaRight12)
summary(m1.hglm)$FixCoefMat[,1][17]*sd(ns(data$anxDepScoreSS, df=3)[,2])/sd(data$SurfAreaRight12)
summary(m1.hglm)$FixCoefMat[,1][16]*sd(ns(data$anxDepScoreSS, df=3)[,1])/sd(data$SurfAreaRight12)

data$sphereTM<-ifelse(data$sphereStudy=="TM", 1,0)
data$sphereTW1<-ifelse(data$sphereStudy=="TW1", 1,0)
data$sphereTW2<-ifelse(data$sphereStudy=="TW2", 1,0)

# Plot regression curve of model 3
datM3<-NULL
datM3<-cbind(1, data$SEX01, ns(data$ageScan,df=3) , ns(data$ageDiff, df=3) ,data$Sample16, data$Sample18, data$ACQUISITION, data$sphereTM, data$sphereTW1, data$sphereTW2, data$TSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$anxDepScoreSS, df=3)[,1:3])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][16:18])

BBsignif<-cbind(ns(data$anxDepScoreSS, df=3)[,3])
regAnxDepSignif<- BBsignif %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])

sd(data$SurfAreaRight12-regCurve)

#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScoreSS_rightLigualSA_naturalSplines_hglm_final.tiff",  width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScoreSS, data$SurfAreaRight12-regCurve   ,
      xlab="SPHERE Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(data$anxDepScoreSS[order(data$anxDepScoreSS)],  regAnxDep[order(data$anxDepScoreSS)] ,      col="darkred",lty=2, lwd=2)
lines(data$anxDepScoreSS[order(data$anxDepScoreSS)],  regAnxDepSignif[order(data$anxDepScoreSS)] +mean(data$SurfAreaRight12-regCurve, na.rm=T) ,      col="darkred",lty=1, lwd=4)

abline(v=quantile(data$anxDepScoreSS, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(data$anxDepScoreSS, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 0.13, labels = c("5%   ", "  25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")
dev.off()

 sd (m1.hglm$resid)

mean(data$SurfAreaRight12-regCurve, na.rm=T)

hist(data$SurfAreaRight12)
mean(data$SurfAreaRight12)+4*sd(data$SurfAreaRight12)

median(data$anxDepScoreSS)

#####################################
# Right surf 3


var="SurfAreaRight3"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data[,var],
                  X = model.matrix(as.formula("~   factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + TSurfArea + ns(anxDepScoreSS, df=3)"),  data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data,  family = gaussian(link = "identity"))
summary(m1.hglm)
shapiro.test(m1.hglm$resid)



datM3<-NULL
datM3<-cbind(1, data$SEX01, ns(data$ageScan,df=3) , ns(data$ageDiff, df=3) ,data$Sample16, data$Sample18, data$ACQUISITION, data$sphereTM, data$sphereTW1, data$sphereTW2, data$TSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$anxDepScoreSS, df=3)[,1:3])
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][16:18])

BBsignif<-cbind(ns(data$anxDepScoreSS, df=3)[,3])
regAnxDepSignif<- BBsignif %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][18])





#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScoreSS_rightSurf3_naturalSplines_hglm_final.tiff",  width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$SurfAreaRight3-regCurve   ,
      xlab="SPHERE Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],  regAnxDep[order(data$anxDepScore)] ,      col="darkred",lty=2, lwd=2)
lines(data$anxDepScore[order(data$anxDepScore)],  regAnxDepSignif[order(data$anxDepScore)] +mean(data$SurfAreaRight3-regCurve, na.rm=T) ,      col="darkred",lty=1, lwd=4)

abline(v=quantile(data$anxDepScore, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(data$anxDepScore, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 0.13, labels = c("5%   ", "  25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")
dev.off()


tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScoreSS_rightSurf3_naturalSplines_hglm_final_SS.tiff",  width=20, height=20, units="cm",     res=500, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScoreSS, data$SurfAreaRight3-regCurve   ,
      xlab="SPHERE Depression-Anxiety Score", ylab="Surface Area of Cluster 6R ", cex.axis=2, cex.lab=2)
lines(data$anxDepScoreSS[order(data$anxDepScoreSS)],  regAnxDep[order(data$anxDepScoreSS)] ,      col="darkred",lty=2, lwd=2)
lines(data$anxDepScoreSS[order(data$anxDepScoreSS)],  regAnxDepSignif[order(data$anxDepScoreSS)] +mean(data$SurfAreaRight3-regCurve, na.rm=T) ,      col="darkred",lty=1, lwd=4)

abline(v=quantile(data$anxDepScoreSS, probs = c(0.05,0.25,0.5,0.75,0.95)), lty=4, lwd=2, col = "gray" )
par(xpd=T)
text(x = quantile(data$anxDepScoreSS, probs = c(0.05,0.25,0.5,0.75,0.95)), y = 0.13, labels = c("5%   ", "  25%", "50%", "75%", "95%"), cex = 0.9, col = "gray")
dev.off()











######################################
var="SurfAreaRightC34"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data[,var],
                  X = model.matrix(as.formula("~   factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) + TSurfArea + ns(anxDepScore, df=3) "),
                                   data = data),verbose = T, vcovmat = T,
                  Z = kinMatSACT, data=data,
                  family = gaussian(link = "identity"))
summary(m1.hglm)
shapiro.test(m1.hglm$resid)

# Plot regression curve of model 3
datM3<-cbind(1, data$SEX01, ns(data$ageScan,df=3) , ns(data$ageDiff, df=3) ,data$TSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$anxDepScore, df=3))
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][10:12])

#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScore_SurfAreaRightC34_naturalSplines_hglm.tiff",  width=30, height=20, units="cm",
     res=300, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$SurfAreaRight3   ,
      xlab="Depression-Anxiety Score", ylab="Occipital Surface Area (subcluster C4)", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$SurfAreaRight3, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

######################################
var="SurfAreaRightC3C41"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data[,var],
                  X = model.matrix(as.formula("~   factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) + TSurfArea + ns(anxDepScore, df=3) "),
                                   data = data),verbose = T, vcovmat = T,
                  Z = kinMatSACT, data=data,
                  family = gaussian(link = "identity"))
summary(m1.hglm)
shapiro.test(m1.hglm$resid)

# Plot regression curve of model 3
datM3<-cbind(1, data$SEX01, ns(data$ageScan,df=3) , ns(data$ageDiff, df=3) ,data$TSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$anxDepScore, df=3))
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][10:12])

#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScore_SurfAreaRightC3C41_naturalSplines_hglm.tiff",  width=30, height=20, units="cm",
     res=300, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$SurfAreaRight3   ,
      xlab="Depression-Anxiety Score", ylab="Lingual gyrus (subcluster 1)", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$SurfAreaRight3, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

######################################
var="SurfAreaRightC3C42"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  data[,var],
                  X = model.matrix(as.formula("~   factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) + TSurfArea + ns(anxDepScore, df=3) "),
                                   data = data),verbose = T, vcovmat = T,
                  Z = kinMatSACT, data=data,
                  family = gaussian(link = "identity"))
summary(m1.hglm)
shapiro.test(m1.hglm$resid)

# Plot regression curve of model 3
datM3<-cbind(1, data$SEX01, ns(data$ageScan,df=3) , ns(data$ageDiff, df=3) ,data$TSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(data$anxDepScore, df=3))
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][10:12])

#
tiff("GeneticClusteringOutputPlots/NonLinearRelation_anxDepScore_SurfAreaRightC3C42_naturalSplines_hglm.tiff",  width=30, height=20, units="cm",
     res=300, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$SurfAreaRight3   ,
      xlab="Depression-Anxiety Score", ylab="Lingual gyrus (subcluster 2)", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$SurfAreaRight3, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

#######################################################
# Reopen data to maximise R_ligual_surfavg sample
data<-read.table("Sphere_subCorlVol_cortThick_SurfArea_n899_uniScore.txt", sep="\t", header=T)

# We might control for time difference between age at score and age at scan
data$ageDiff<-NULL
data$ageDiff<-data$ageScan-data$ageScore # all scans follow scoring

data$SEX01<-0
data$SEX01[which(data$SEX=="M")]<-1
table(is.na(data$ICV), exclude = NULL)

data$Sample16<-ifelse(data$Sample=="16", 1,0)
data$Sample18<-ifelse(data$Sample=="18", 1,0)
table(data$Sample18, data$Sample)

VarRegressorsRLSA<-c("SEX", "ageScan","ageDiff","Sample16", "Sample18",  "ACQUISITION", "anxDepScore","ICV" ,"RSurfArea", "LSurfArea")
dataRLSA<-data[-which(rowSums(is.na(data[,c("R_lingual_surfavg", VarRegressorsRLSA)]))>0),]

# Open kinship matrix
start.time<-proc.time()
kinshipDM<-read.big.matrix(filename = "/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/kinship_matrix_17902individuals_DMstudy.txt", sep = "\t", header = T)
end.time<-proc.time()
save.time<-end.time-start.time
paste("Number of minutes running:",  save.time[3]/60) # 2.7446 minutes

# Load subset function to create kinship matrices
source("/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/RR_2_ExtractKinshipMatrixFromDM_function.R")
# Create and write the matrices
kinMatRLSA<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = dataRLSA$ID)
dim(kinMatRLSA)

var="R_lingual_surfavg"
# Correcting for ICV, mean cor thickness or mean surface area
m1.hglm <-   hglm(y =  dataRLSA[,var],
                  X = model.matrix(as.formula("~ factor(SEX)+ ns(ageScan, df=3) + ns(ageDiff, df=3) +  RSurfArea + ns(anxDepScore, df=3) "),
                                   data = dataRLSA),verbose = T, vcovmat = T,
                  Z = kinMatRLSA, data=dataRLSA,
                  family = gaussian(link = "identity"))
summary(m1.hglm)
shapiro.test(m1.hglm$resid)
0.000406912050831876 /3
1.39E-4*3*126

# Plot regression curve of model 3
datM3<-cbind(1,  ns(dataRLSA$ageScan,df=3) , ns(dataRLSA$ageDiff, df=3),dataRLSA$ICV ,dataRLSA$RSurfArea)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m1.hglm)$FixCoefMat[1:length(datM3[1,]),1])

BB<-cbind(ns(dataRLSA$anxDepScore, df=3))
regAnxDep<- BB %*% as.matrix(summary(m1.hglm)$FixCoefMat[,1][10:12])

#
pdf("NonLinearRelation_anxDepScore_rightLigualSA_naturalSplines_final_hglm.pdf")
par(mar=c(4.1,5.5,2.1,1.1))
plot( dataRLSA$anxDepScore, dataRLSA$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab=expression(paste("Right Lingual Surface Area (mm"^"2", ")")) , cex.axis=2, cex.lab=2)
lines(dataRLSA$anxDepScore[order(dataRLSA$anxDepScore)],
      regAnxDep[order(dataRLSA$anxDepScore)] +  mean(dataRLSA$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

################################

pdf("NonLinearRelation_anxDepScore_rightLigualSA_naturalSplines_final_hglm_POSTER.pdf", width = 10, height = 8)
par(mar=c(4.1,5.5,2.1,1.1))
plot( dataRLSA$anxDepScore, dataRLSA$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab=expression(paste("Right Lingual Surface Area (mm"^"2", ")")) , cex.axis=2, cex.lab=2)
lines(dataRLSA$anxDepScore[order(dataRLSA$anxDepScore)],
      regAnxDep[order(dataRLSA$anxDepScore)] +  mean(dataRLSA$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

##########
# Add case control status
KT<-read.table("Nu_QTIM_Sphere_KT_allVariables.txt", header=T, sep="\t")
KT<-KT[-which(is.na(KT$R_lingual_surfavg)),]

KT$Rec<-0
KT$Rec[which(KT$MDD==1 )]<-0
KT$Rec[which(KT$MDD==1 & KT$nbSuppEp>0)]<-2
table(KT$Rec)

dataRLSA<-merge(dataRLSA, KT, by="ID", all=T, suffixes = c("", "KT"))

pdf("NonLinearRelation_anxDepScore_rightLigualSA_naturalSplines_final_hglm_KT.pdf")
par(mar=c(4.1,5.5,2.1,1.1))
plot( dataRLSA$anxDepScore, dataRLSA$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab=expression(paste("Right Lingual Surface Area (mm"^"2", ")")) , cex.axis=2, cex.lab=2)
lines(dataRLSA$anxDepScore[order(dataRLSA$anxDepScore)],
      regAnxDep[order(dataRLSA$anxDepScore)] +  mean(dataRLSA$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
points(dataRLSA$anxDepScore[which(dataRLSA$MDD==0)], dataRLSA$R_lingual_surfavg[which(dataRLSA$MDD==0)], col="darkgreen", pch=20 )
points(dataRLSA$anxDepScore[which(dataRLSA$MDD==1)], dataRLSA$R_lingual_surfavg[which(dataRLSA$MDD==1)], col="darkred", pch=20 )
points(dataRLSA$anxDepScore[which(dataRLSA$Rec==2)], dataRLSA$R_lingual_surfavg[which(dataRLSA$Rec==2)], col="black", pch=20 )
legend(x = -3,y = 4500, legend = c("Controls", "MDD cases", "Recurrent cases"), col = c("darkgreen", "darkred", "black"), pch=20, cex = 1.25, pt.cex=2)
dev.off()



pdf("NonLinearRelation_anxDepScore_rightLigualSA_naturalSplines_final_hglm_KT_POSTER.pdf", width = 10, height = 7)
par(mar=c(4.1,5.5,2.1,1.1))
plot( dataRLSA$anxDepScore, dataRLSA$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab=expression(paste("Right Lingual Surface Area (mm"^"2", ")")) , cex.axis=2, cex.lab=2, cex=1.6)

points(dataRLSA$anxDepScore[which(dataRLSA$MDD==0)], dataRLSA$R_lingual_surfavg[which(dataRLSA$MDD==0)], col="darkgreen", pch=20 , cex=2)
points(dataRLSA$anxDepScore[which(dataRLSA$MDD==1)], dataRLSA$R_lingual_surfavg[which(dataRLSA$MDD==1)], col="darkred", pch=20 , cex=2)
points(dataRLSA$anxDepScore[which(dataRLSA$Rec==2)], dataRLSA$R_lingual_surfavg[which(dataRLSA$Rec==2)], col="black", pch=20 , cex=2)
legend(x = -3,y = 4500, legend = c("Controls", "MDD cases", "Recurrent cases"), col = c("darkgreen", "darkred", "black"), pch=20, cex = 1.25, pt.cex=2)
lines(dataRLSA$anxDepScore[order(dataRLSA$anxDepScore)],
      regAnxDep[order(dataRLSA$anxDepScore)] +  mean(dataRLSA$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=5)
dev.off()









# Plot for presentation BGA
png("NonLinearRelation_anxDepScore_rightLigualSA_basicSplines_final_hglm.png",  width=17.5, height=20, units="cm",
     res=600)
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab="Right Lingual Surface Area", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

pdf("NonLinearRelation_anxDepScore_rightLigualSA_basicSplines_final_hglm.pdf")
par(mar=c(4.1,5.5,2.1,1.1))
plot( data$anxDepScore, data$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab=expression(paste("Right Lingual Surface Area (mm"^"2", ")")) , cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()

# With polynomial anx-dep
BB<-cbind(data$anxDepScore, data$anxDepScoreSq, data$anxDepScoreCb)
regAnxDep<- BB %*% as.matrix(summary(m4.nlme)$tTable[,1][5:7])

#
tiff("NonLinearRelation_anxDepScore_rightLigualSA_basicSplines_polynomous.tiff",  width=20, height=20, units="cm",
     res=300, compression="lzw+p")
par(mar=c(5.1,5.1,2.1,4.1))
plot( data$anxDepScore, data$R_lingual_surfavg   ,
      xlab="Depression-Anxiety Score", ylab="Right Lingual Surface Area", cex.axis=2, cex.lab=2)
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)] +  mean(data$R_lingual_surfavg, na.rm=T),
      col="darkred",lty=1, lwd=2)
dev.off()


# Test retest right lingual surface area
trtSA<-read.csv("QTIM_data/Test_retest_ICC_SA.csv", header=T, sep=",")
trtSA[which(trtSA$X=="R_lingual_surfavg"),]
#######################


var="L_superiorfrontal_surfavg"
# Correcting for ICV, mean cor thickness or mean surface area
formul<-as.formula(paste(var, "~  factor(SEX) + ageScan + ageDiff + bs(anxDepScore, degree=3) "))
m0.nlme = lme(formul ,
              random = ~ 1|factor(mixedEffects),
              data = data, na.action = na.omit)

formul<-as.formula(paste(var, "~  factor(SEX) + bs(ageScan, df=3) + bs(ageDiff, df=3) + ns(anxDepScore, df=3)+ LSurfArea + RSurfArea + LThickness + RThickness"))
m1.nlme = lme(formul ,
              random = ~ 1|factor(FAMID),
              data = data, na.action = na.omit)

formul<-as.formula(paste(var, "~   ageScan + ageDiff + bs(anxDepScore, df=3)[,2:3] +  LSurfArea  "))
m3.nlme = lme(formul ,
              random = ~ 1|factor(mixedEffects),
              data = data, na.action = na.omit)


summary(m0.nlme)
summary(m1.nlme)
summary(m3.nlme)


# Plot regression curve of model 3
datM3<-cbind( data$ageScan, data$ageDiff, data$LSurfArea.x)
regCurve<- as.matrix(datM3) %*% as.matrix(summary(m3.nlme)$tTable[c(2,3,6),1])

BB<-bs(data$anxDepScore, degree=3)
regAnxDep<- BB[,2:3] %*% as.matrix(summary(m3.nlme)$tTable[,1][c(4,5)])

tiff("NonLinearRelation_anxDepScore_leftSuperiorFrontal_basicSplines.tiff",  width=15, height=20, units="cm",
     res=300, compression="lzw+p")
plot( data$anxDepScore, data$L_superiorfrontal_surfavg - regCurve - summary(m3.nlme)$tTable[1,1] ,
      xlab="Depression-Anxiety Score", ylab="Left Superior Frontal Surface Area (Standardised)")
lines(data$anxDepScore[order(data$anxDepScore)],
      regAnxDep[order(data$anxDepScore)],
      col="red",lty=1, lwd=2)
dev.off()

# Note: BS splines seem to improve the fit AIC of the models
# compared to ns splines

# Open pvalue table for further check
SA<-read.table("MixedNLmodels_pvalues_surfaceArea.txt", header=T)
CT<-read.table("MixedNLmodels_pvalues_corticalThick.txt", header=T)

hist( -log( c(SA$pval1, SA$pval2, SA$pval3) , base=10) )
hist( -log( c(SA$pval1Cor, SA$pval2Cor, SA$pval3Cor) , base=10) )


result<-read.table("MixedNLmodels_pvalues_140Vars.txt", header=T)
hist(-log(c(result$pval1Cor, result$pval2Cor, result$pval3Cor) ,base=10) )


