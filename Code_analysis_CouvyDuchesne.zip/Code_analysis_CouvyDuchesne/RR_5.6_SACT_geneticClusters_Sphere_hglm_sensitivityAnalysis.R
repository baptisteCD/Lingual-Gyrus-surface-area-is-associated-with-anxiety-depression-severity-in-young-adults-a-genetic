#####
# Association of all brain phenotypes with Sphere score (for Anxiety/Depression)
# The number of independent brain phenotypes has been calcualted by Sarah
# Bonferroni-Sidak correction is used to correct p-values
# Mixed models on family ID used to take into account relatedness

library(scales)
library(hglm)
library(ggplot2)
library(bigmemory)
library(qqman)
library(splines)

data<-read.table("/Users/b.couvy-duchesne/Documents/MyDocuments/09_Sphere_StructuralImaging/GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n800_uniScore.txt", sep="\t", header=T)
colnames(data)

# Exclude participants with anx-dep score of -3
#data<-data[-which(data$anxDepScore < -2.5),] # 92 observations dropped

#################################################
# GRM matrix
# Open kinship matrix
start.time<-proc.time()
kinshipDM<-read.big.matrix(filename = "/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/kinship_matrix_17902individuals_DMstudy.txt", sep = "\t", header = T)
end.time<-proc.time()
save.time<-end.time-start.time
paste("Number of minutes running:",  save.time[3]/60)

# Load subset function to create kinship matrices
source("/Users/uqbcouvy/Documents/MyDocuments/12_LinearRegression_familyStructure/RR_2_ExtractKinshipMatrixFromDM_function.R")
kinMatSACT<-subsetKinshipMatrix(kinshipMat = kinshipDM, IDlist = data$ID)


# List of brain phenotypes for Cortical Thickness and surface area
colnames(data)
CTvars<-colnames(data)[grepl(colnames(data), pattern="CortThick")]
SAvars<-colnames(data)[grepl(colnames(data), pattern="SurfArea")][1:26]
C3vars<-colnames(data)[grepl(colnames(data), pattern="SurfAreaRightC3")]
C3C4vars<-colnames(data)[grepl(colnames(data), pattern="SurfAreaRightC3C4")]
vertexVars<-colnames(data)[grepl(colnames(data), pattern="X",ignore.case = F)][2:48]


######################################################################
# Non linear association using basic cubic splines
######################################################################

regressors<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")
regressorsAllSA<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"TSurfArea", "anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")
regressorsAllCT<-c("SEX", "ageScanS1", "ageScanS2","ageScanS3","ageDiffS1", "ageDiffS2","ageDiffS3","Sample16", "Sample18",  "ACQUISITION", "sphereStudyTM", "sphereStudyTW1", "sphereStudyTW2" ,"AvgThickness", "anxDepScoreS1", "anxDepScoreS2", "anxDepScoreS3")


#################
# SA, sub clusters of cluster 3 of the right hemisphere
#################
allVars<-c(C3vars)
regressorsAll<- regressorsAllSA
result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScore, df=3)"), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

  # Correcting for mean surface area
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + TSurfArea + ns(anxDepScore, df=3) "),data = data),verbose = T, vcovmat = T,Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

}

signif<-0.00005
result[which(result$pval_anxDepScoreS1< signif |  result$pval_anxDepScoreS2< signif | result$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS3")]
resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS2","pval_anxDepScoreS3")]

write.table(result, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_C3subclusters.txt", sep="\t", col.names=T, row.names=F)
write.table(resultCor, "GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_C3subclusters.txt", sep="\t", col.names=T, row.names=F)


#################
# SA, vertex wise
#################
allVars<-c(vertexVars)
regressorsAll<- regressorsAllSA
result<-NULL
result$var<-allVars
result<-as.data.frame(result)
result[,paste("beta_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("betaSd_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("pval_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))
result[,paste("effectSize_", regressors, sep="")]<-matrix(NA, nrow=length(regressors), ncol=length(allVars))

resultCor<-NULL
resultCor$var<-allVars
resultCor<-as.data.frame(result)
resultCor[,paste("beta_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("betaSd_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("pval_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))
resultCor[,paste("effectSize_", regressorsAll, sep="")]<-matrix(NA, nrow=length(regressorsAll), ncol=length(allVars))

for (var in allVars){

  m1.hglm <-   hglm(y =  data[,var], X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + ns(anxDepScore, df=3)"), data = data),verbose = T, vcovmat = T, Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  result[which(result$var==var),paste("beta_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  result[which(result$var==var),paste("betaSd_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  result[which(result$var==var),paste("pval_", regressors, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  result[which(result$var==var),paste("effectSize_", regressors, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

  # Correcting for mean surface area
  m1.hglm <-   hglm(y =  data[,var],
                    X = model.matrix(as.formula("~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) +  factor(Sample16) + factor(Sample18) + factor(ACQUISITION) + factor(sphereStudy) + TSurfArea + ns(anxDepScore, df=3) "),data = data),verbose = T, vcovmat = T,Z = kinMatSACT, data=data, family = gaussian(link = "identity"))

  resultCor[which(result$var==var),paste("beta_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,1]
  resultCor[which(result$var==var),paste("betaSd_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,2]
  resultCor[which(result$var==var),paste("pval_", regressorsAll, sep="")]<-summary(m1.hglm)$FixCoefMat[-1,4]
  resultCor[which(result$var==var),paste("effectSize_", regressorsAll, sep="")]<-apply(as.data.frame(summary(m1.hglm)$FixCoefMat[-1,1]), 1, function(x) mean( x/data[,var]*100,na.rm=T) )

}

signif<-4.3e-4
result[which(result$pval_anxDepScoreS1< signif |  result$pval_anxDepScoreS2< signif | result$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS3")]
resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")]

write.table(result, "/Users/uqbcouvy/Documents/MyDocuments/09_Sphere_StructuralImaging/GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_vertexWise_minus3Excluded.txt", sep="\t", col.names=T, row.names=F)

write.table(resultCor, "/Users/uqbcouvy/Documents/MyDocuments/09_Sphere_StructuralImaging/GeneticClusteringOutputPlots/GLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_vertexWise_minus3Excluded.txt", sep="\t", col.names=T, row.names=F)

resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_C3subclusters.txt", sep="\t", header=T)
dim(resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")])

dim(resultCor[which(resultCor$pval_anxDepScoreS1< signif |  resultCor$pval_anxDepScoreS2< signif | resultCor$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")])


# Reopen and check for significant associations;
ct<-read.table("HGLM_summary_SignificanceAnxDep_CT_nonLinear_Corrected.txt", header=T)
sa<-read.table("HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected.txt", header=T)

signif<-4.7e-4
ct[which(ct$pval_anxDepScoreS1< signif |  ct$pval_anxDepScoreS2< signif | ct$pval_anxDepScoreS3< signif),c("pval_anxDepScoreS1","pval_anxDepScoreS2","pval_anxDepScoreS3")]

sa[which(sa$pval_anxDepScoreS1< signif |  sa$pval_anxDepScoreS2< signif | sa$pval_anxDepScoreS3< signif),]

sqrt((-330.7201)**2/var(data$R_lingual_surfavg, na.rm=T)*var(ns(data$anxDepScoreSS, df = 3)[,3]))

83.98336
