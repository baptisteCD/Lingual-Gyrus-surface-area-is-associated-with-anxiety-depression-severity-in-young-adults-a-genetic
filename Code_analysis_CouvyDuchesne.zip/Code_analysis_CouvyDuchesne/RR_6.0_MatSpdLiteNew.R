## To analyse your correlation matrix, execute this R script in the sample directory as your "correlationORcovariance.matrix" file, using:
## R CMD BATCH matSpDliteNewMatrix.R
## or from within R:
## source("matSpDliteNewMatrix.R")
##
## Results are written to "matSpDliteNewMatrix.out"
##
## Please cite
## Nyholt DR (2004) A simple correction for multiple testing for SNPs in linkage disequilibrium with each other. Am J Hum Genet 74(4):765-769.
## and
## http://neurogenetics.qimrberghofer.edu.au/matSpDlite/
##
## NB: we recommend using a matrix of correlation values

runMatSpdLite<-function(corMatFile){

## Read in the corrleation matrix:
Matrix<-read.table(corMatFile, header=T)

## Remove Duplicate Columns:
Matrix.RemoveDupCol <- Matrix[!duplicated((Matrix))]

## Remove Duplicate Rows:
Matrix.RemoveDupRow <- unique((Matrix.RemoveDupCol))

## Remove Redundant VAR Names and prepare labels for later:
VARnames.NonRedundant<-as.matrix(dimnames(Matrix.RemoveDupCol)[[2]])
colnames(VARnames.NonRedundant)<-"VAR"

## Perform Spectral Decomposition of the input correlation matrix 'Matrix':
Evals<-eigen(t(Matrix.RemoveDupRow),symmetric=T)$values

## Prepare Evals for output:
V<-length(Evals)
LabelEvals<-array(dim=V)
for(col in 1:V) { LabelEvals[col]<-c(col) }

## Replace negative Evals with zero, and prepare for output:
NonNegEvals<-Evals
for(i in 1:V) {
  if(NonNegEvals[i] < 0) {
    NonNegEvals[i] <- 0
  }
}

## Use nearPD to force the input correlation matrix to be positive-definite.
## Perform Spectral Decomposition of the nearest symmetric positive semidefinite matrix with unit diagonal:
## Higham, Nick (2002) Computing the nearest correlation matrix - a problem from finance; IMA Journal of Numerical Analysis 22, 329-343.
library(Matrix)
nearPD_result<-nearPD(t(Matrix.RemoveDupRow), corr=FALSE)

## Extract eigenvalues from 'nearPD_result':
nearPD_Evals<-nearPD_result$eigenvalues


## Compile eigenvalues for output:
LabelledEvals<-cbind(LabelEvals, Evals, NonNegEvals, nearPD_Evals)
colnames(LabelledEvals)<-c("Factor","Eigenvalue", "NonNeg_Eigenvalue", "nearPD_Eigenvalue")


##############################################################################################################################################


## Implement improved approach of Li J and Ji L (2005) Adjusting multiple testing in multilocus analyses using the eigenvalues of a correlation matrix. Heredity 95:221-227.

IntNonNegEvals<-NonNegEvals

for(i in 1:V) {
  if(IntNonNegEvals[i] >= 1 ) {
    IntNonNegEvals[i] <- 1
  }
  if(IntNonNegEvals[i] < 1 ) {
    IntNonNegEvals[i] <- 0
  }
}

NonIntNonNegEvals <- NonNegEvals-floor(NonNegEvals)

VeffLiJi <- sum(NonIntNonNegEvals+IntNonNegEvals)

NewResultLiJitemp1<-c('The effective number of independent variables [VeffLiJi] estimate proposed by Li and Ji (2005),',
                      'using non-negative eigenvalues:')
NewResultLiJitemp2<-round(VeffLiJi,dig=4)
NewResultLiJi1<-matrix(NewResultLiJitemp1)
NewResultLiJi2<-matrix(NewResultLiJitemp2)
NewBonferroniLiJitemp<-c('Experiment-wide Significance Threshold Required to Keep Type I Error Rate at 5%:',
                         ' ', 1-(0.95^(1/VeffLiJi)))
NewBonferroniLiJi<-matrix(NewBonferroniLiJitemp)

Separatortemp<-c(' ',
                 '---------------------------------------------------------------------------------------------------',
                 ' ')
Separator<-matrix(Separatortemp)


##############################################################################################################################################


## Implement improved approach of Li J and Ji L (2005) Adjusting multiple testing in multilocus analyses using the eigenvalues of a correlation matrix. Heredity 95:221-227.
## Using forced (nearest) positive-definite correlation matrix

IntnearPD_Evals<-nearPD_Evals

for(i in 1:V) {
  if(IntnearPD_Evals[i] >= 1 ) {
    IntnearPD_Evals[i] <- 1
  }
  if(IntnearPD_Evals[i] < 1 ) {
    IntnearPD_Evals[i] <- 0
  }
}

NonIntnearPD_Evals <- nearPD_Evals-floor(nearPD_Evals)

nearPD_VeffLiJi <- sum(NonIntnearPD_Evals+IntnearPD_Evals)

nearPD_NewResultLiJitemp1<-c('The effective number of independent variables [VeffLiJi-PD] estimate proposed by Li and Ji (2005),',
                             'using eigenvalues calculated from a forced positive-definite (PD) correlation matrix:')
nearPD_NewResultLiJitemp2<-round(nearPD_VeffLiJi,dig=4)
nearPD_NewResultLiJi1<-matrix(nearPD_NewResultLiJitemp1)
nearPD_NewResultLiJi2<-matrix(nearPD_NewResultLiJitemp2)
nearPD_NewBonferroniLiJitemp<-c('Experiment-wide Significance Threshold Required to Keep Type I Error Rate at 5%:',
                                ' ', 1-(0.95^(1/nearPD_VeffLiJi)))
nearPD_NewBonferroniLiJi<-matrix(nearPD_NewBonferroniLiJitemp)


##############################################################################################################################################


Messagetemp<-c(' ',
               'NB: a conservative approach of taking the LARGEST of VeffLiJi and VeffLiJi-PD is recommended. ')
Message<-matrix(Messagetemp)


Vraw<-length(Matrix[,1])

OriginalRawtemp<-c('Original (total) number of variables (V) BEFORE removing redundant (collinear) variables:',
                ' ', Vraw)

Originaltemp<-c('Original (total) number of variables (V) AFTER removing redundant (collinear) variables:',
                ' ', V)

Eigenvalues1temp<-c(' ',
                       'For factor 1 to V, eigenvalues associated with the correlation matrix:',
                       ' ')
Eigenvalues2temp<-signif(LabelledEvals,dig=5)


OriginalRaw<-matrix(OriginalRawtemp)
Original<-matrix(Originaltemp)

Eigenvalues1<-matrix(Eigenvalues1temp)
Eigenvalues2<-Eigenvalues2temp


no.dimnames <- function(a) {
  ## Remove all dimension names from an array for compact printing.
  d <- list()
  l <- 0
  for(i in dim(a)) {
    d[[l <- l + 1]] <- rep("", i)
  }
  dimnames(a) <- d
  a
}

  sink(paste(corMatFile, "_matSpdOutput.txt", sep = ""))
  print(no.dimnames(OriginalRaw), quote=F)
  print(no.dimnames(Original), quote=F)
  print(no.dimnames(Eigenvalues1), quote=F)
  print(as.data.frame(Eigenvalues2), row.names = F, quote=F)

  print(no.dimnames(Separator), quote=F)

  print(no.dimnames(NewResultLiJi1), quote=F)
  print(no.dimnames(NewResultLiJi2), quote=F)
  print(no.dimnames(NewBonferroniLiJi), quote=F)

  print(no.dimnames(Separator), quote=F)

  print(no.dimnames(nearPD_NewResultLiJi1), quote=F)
  print(no.dimnames(nearPD_NewResultLiJi2), quote=F)
  print(no.dimnames(nearPD_NewBonferroniLiJi), quote=F)

  print(no.dimnames(Message), quote=F)

  sink()

}

