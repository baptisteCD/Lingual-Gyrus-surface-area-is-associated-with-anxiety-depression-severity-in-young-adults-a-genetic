# Estimate number of independent tests
library(splines)
source("RR_6.0_MatSpdLiteNew.R")

data<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore.txt", sep="\t", header=T)
colnames(data)

data$

# List of brain phenotypes for Cortical Thickness
CTvars<-colnames(data)[grepl(colnames(data), pattern="CortThick")]
SAvars<-colnames(data)[grepl(colnames(data), pattern="SurfArea")][1:24]
C3vars<-colnames(data)[grepl(colnames(data), pattern="SurfAreaRightC3")]
VertexVars<-colnames(data)[grepl(colnames(data), pattern="VertexNum")]

varAll<-c(CTvarsBrain, SAvarsBrain) # 48 vars

# Correlation matrix uncorrected for covariates
corMat<-cor(data[,varAll], use="complete.obs")
write.table(corMat, "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_geneticClusters48.txt", sep="\t", col.names=T, row.names=F)
#
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_geneticClusters48.txt")

################################################
# After regressing out all covariates?
# loop to run all the GLM models (effect size estimates should be unbiased)

###########
# SA
###########
resultSA<-NULL
resultSA<-as.data.frame(matrix(0,ncol=length(SAvars), nrow=length(data[,1])))
colnames(resultSA)<-SAvars


for (var in  c(SAvars,VertexVars) ){
  formul<-as.formula(paste(var, "~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) + factor(Sample16) + factor(Sample18) +  factor(ACQUISITION) + factor(sphereStudy) + TSurfArea "))
  m1 = glm(formul , na.action=na.exclude,family = gaussian(link = "identity"), data = data)
  resultSA[,var]<-residuals(m1)
}


###########
# CT
###########
resultCT<-NULL
resultCT<-as.data.frame(matrix(0,ncol=length(CTvars), nrow=length(data[,1])))
colnames(resultCT)<-CTvars


for (var in CTvars){
  formul<-as.formula(paste(var, "~  factor(SEX) + ns(ageScan, df=3) + ns(ageDiff, df=3) + factor(Sample16) + factor(Sample18) +  factor(ACQUISITION) + factor(sphereStudy) + AvgThickness "))
  m1 = glm(formul , na.action=na.exclude,family = gaussian(link = "identity"), data = data)
  resultCT[,var]<-residuals(m1)
}


# Cbind the regressed data and export correlation matrix
residuals<-cbind( resultSA, resultCT)
corRegMat<-cor(residuals, use="complete.obs")

# Add residuals to current data (for openMx models, where it is easier to regress covariates first)
colnames(residuals)<-paste(colnames(residuals), "_reg",sep = "")
data<-cbind(data, residuals)
# write table that stores regressed variabels
write.table(data, "GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore_phenoRegressed.txt", col.names=T, row.names=F, sep="\t")

#write.table(corRegMat, "correlationMatrix_RegressedVars_n136.txt", sep="\t", col.names=F, row.names=F)
write.table(corRegMat, "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_regressed_142PhenoWithVertex.txt", sep="\t", col.names=T, row.names=F)
48+94
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_regressed_142PhenoWithVertex.txt")


####################
# For discovery analysis
corRegMat<-cor(residuals[,paste0(c(CTvars, SAvars), "_reg")], use="complete.obs")
write.table(corRegMat, "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_geneticClusters48_regressed.txt", sep="\t", col.names=T, row.names=F)
#
runMatSpdLite(corMatFile = "GeneticClusteringOutputPlots/correlationMatrix_CT_SA_phenotypes_geneticClusters48_regressed.txt")

colnames(resultSA)




# 34 independent traits (for variables of brain clusters)
0.00150748890089614/3
5.0E-4

# 33 when not including nucleus accumbens
33*3

1-(1-0.05)**(1/99)
# 5.2E-4 without nucleus accumbens

39.4*52

# Based on 40 indep variables
# 3*40=120 tests
1-(1-0.05)**(1/120)
# Significance threshold of 0.0004273528 = 4.2E-4
