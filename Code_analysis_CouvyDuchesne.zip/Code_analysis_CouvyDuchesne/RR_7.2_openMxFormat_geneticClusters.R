# Transform data into OpenMx format
# Run genetic correlations between anx-dep and the regions identified previously

library(splines)
library(plyr)
library(Hmisc)
#library(nlme)

data<-read.table("GeneticClusteringOutputPlots/Sphere_subCortVols_cortThick_SurfArea_n834_uniScore_phenoRegressed.txt", sep="\t", header=T)

length(which(is.na(data$ZYGOSITY)))
# geting the 3 df splines for anxDep in the database
data$anxDepScoreS1<-ns(data$anxDepScore, df=3)[,1]
data$anxDepScoreS2<-ns(data$anxDepScore, df=3)[,2]
data$anxDepScoreS3<-ns(data$anxDepScore, df=3)[,3]
data$ageScanS1<-ns(data$ageScan, df=3)[,1]
data$ageScanS2<-ns(data$ageScan, df=3)[,2]
data$ageScanS3<-ns(data$ageScan, df=3)[,3]
data$ageDiffS1<-ns(data$ageDiff, df=3)[,1]
data$ageDiffS2<-ns(data$ageDiff, df=3)[,2]
data$ageDiffS3<-ns(data$ageDiff, df=3)[,3]

data$ZYGBIN<-ifelse(data$ZYGOSITY<3, "MZ", "DZ")
data$ZYGBIN[which(is.na(data$ZYGBIN))]<-"DZ"
table(data$ZYGBIN, exclude=NULL)

data$famid<-substr(data$ID, 1,5)
data$
m1<-glm(formula = "anxDepScoreSS ~ ageScore + factor(SEX) + factor(study)", data = data)
summary(m1)
data$anxDepSS_reg<-residuals(m1)

data$anxDepScoreSSS1<-ns(data$anxDepScoreSS, df=3)[,1]
data$anxDepScoreSSS2<-ns(data$anxDepScoreSS, df=3)[,2]
data$anxDepScoreSSS3<-ns(data$anxDepScoreSS, df=3)[,3]

data$anxDepScoreSS_reg_S1<-ns(data$anxDepSS_reg, df=3)[,1]
data$anxDepScoreSS_reg_S2<-ns(data$anxDepSS_reg, df=3)[,2]
data$anxDepScoreSS_reg_S3<-ns(data$anxDepSS_reg, df=3)[,3]


#The following objects contain the list of familyIDs according to the family size
familyID<-as.data.frame(table(data$famid))
familyID_pairs<-familyID[which(familyID[,2]==2),][,1]
familyID_single<-familyID[which(familyID[,2]==1),][,1]
familyID_triplets<-familyID[which(familyID[,2]==3),][,1]
familyID_4plus<-familyID[which(familyID[,2]>3),][,1]

#Print the family decomposition
#Family size decomposition (based on TWID)
print(paste("There are", length(familyID_single), "families composed of 1 individual"))
print(paste("There are", length(familyID_pairs), "families composed of 2 individuals"))
print(paste("There are", length(familyID_triplets), "families composed of 3 individuals"))
print(paste("There are", length(familyID_4plus), "families composed of more than 3 individuals"))

# Family with 4 members
data[which(data$famid==familyID_4plus),c("ID", "ageScan")]
# 8586350 and  8586351 are siblings, thus we exclude them
ID2exclude<-c( "8586350")

# Families with 3 members
data[which(data$famid %in% familyID_triplets),c("ID", "ZYGOSITY", "totLog")]
# The triplets are DZ so all good


data<-data[-which(data$ID %in% ID2exclude),]
#The following objects contain the list of familyIDs according to the family size
familyID<-as.data.frame(table(data$famid))
familyID_pairs<-familyID[which(familyID[,2]==2),][,1]
familyID_single<-familyID[which(familyID[,2]==1),][,1]
familyID_triplets<-familyID[which(familyID[,2]==3),][,1]
familyID_4plus<-familyID[which(familyID[,2]>3),][,1]

#Print the family decomposition
#Family size decomposition (based on TWID)
print(paste("There are", length(familyID_single), "families composed of 1 individual"))
print(paste("There are", length(familyID_pairs), "families composed of 2 individuals"))
print(paste("There are", length(familyID_triplets), "families composed of 3 individuals"))
print(paste("There are", length(familyID_4plus), "families composed of more than 3 individuals"))

# Age and sex % and demographics
mean(data$ageScan)
sd(data$ageScan)
range(data$ageScan)

mean(data$ageScore)
sd(data$ageScore)
range(data$ageScore)

prop.table(table(data$SEX))
142+32+14
# Create the OpenMx file
library(plyr)

# Sort data by family ID and zygosity
data<-data[order(data$famid, data$ZYGOSITY),]
#data[,c("Subject", "Zygosity","Age_in_Yrs", "Gender", "famid")]

# COMPLETE TRIOS
newdata<-apply(as.data.frame(familyID_triplets), 1,
               function(x) cbind(data[which(data$famid==x ),][1,] ,
                                 data[which(data$famid==x ),][2,],
                                 data[which(data$famid==x ),][3,]  ) )


tripData <- ldply(newdata, data.frame)

colnames(tripData)<-c(paste(colnames(data), "_T1", sep=""),
                      paste(colnames(data), "_T2", sep=""),
                      paste(colnames(data), "_Sib", sep=""))

table(tripData$ZYGOSITY_T1)
table(tripData$ZYGOSITY_T2)
table(tripData$ZYGOSITY_Sib)

# PAIRS
newdata<-apply(as.data.frame(familyID_pairs), 1,
               function(x) cbind(data[which(data$famid==x ),][1,] ,
                                 data[which(data$famid==x ),][2,] ) )
pairData <- ldply(newdata, data.frame)
length(pairData[,1])
colnames(pairData)<-c(paste(colnames(data), "_T1", sep=""), paste(colnames(data), "_T2", sep=""))

singleData<-NULL
singleData<-data[which(data$famid %in% familyID_single),]
colnames(singleData)<-paste(colnames(data), "_T1", sep="")

# Check zygosity and create general zygosity variable:
table(tripData$ZYGOSITY_T1, tripData$ZYGOSITY_T2, exclude=NULL)
table(tripData$ZYGOSITY_T1, tripData$ZYGOSITY_Sib, exclude=NULL)
table(tripData$ZYGOSITY, exclude = NULL)
tripData[which(is.na(tripData$ZYGOSITY)),c("SEX_T1", "SEX_T2")]

tripData$ZYGOSITY<-tripData$ZYGOSITY_T2
tripData$ZYGOSITY[which(is.na(tripData$ZYGOSITY))]<-3

#
table(pairData$ZYGOSITY_T1, pairData$ZYGOSITY_T2,exclude=NULL)
table(pairData$ZYGOSITY, pairData$ZYGOSITY_T2,exclude=NULL)

pairData$ZYGOSITY[which(pairData$ZYGOSITY_T1==pairData$ZYGOSITY_T2)]<-pairData$ZYGOSITY_T1[which(pairData$ZYGOSITY_T1==pairData$ZYGOSITY_T2)]
pairData$ZYGOSITY[which(is.na(pairData$ZYGOSITY) & pairData$SEX_T1=="F" & pairData$SEX_T2=="F")]<-3
pairData$ZYGOSITY[which(is.na(pairData$ZYGOSITY) & pairData$SEX_T1=="M" & pairData$SEX_T2=="M")]<-4
pairData$ZYGOSITY[which(is.na(pairData$ZYGOSITY) & pairData$SEX_T1=="F" & pairData$SEX_T2=="M")]<-5
pairData$ZYGOSITY[which(is.na(pairData$ZYGOSITY) & pairData$SEX_T1=="M" & pairData$SEX_T2=="F")]<-6

singleData$ZYGOSITY<-singleData$ZYGOSITY_T1
singleData$ZYGOSITY[which(is.na(singleData$ZYGOSITY) & singleData$SEX_T1=="F")]<-5
singleData$ZYGOSITY[which(is.na(singleData$ZYGOSITY) & singleData$SEX_T1=="M")]<-6

# Binding
totData<-rbind.fill(tripData, pairData, singleData)
??rbind.fill

# Zygosity check and correction
table(totData$ZYGOSITY, exclude=NULL)

table(totData$ZYGOSITY_T1, totData$SEX_T1)
table(totData$ZYGOSITY_T2, totData$SEX_T2)
table(totData$ZYGOSITY_T1, totData$ZYGOSITY_T2, exclude=NULL)

totData$ZYGOSITY<-totData$ZYGOSITY_T1
totData$ZYGOSITY[which(data$ZYGOSITY_T1!= data$ZYGOSITY_T2)]<-c(5,5,6,6)
totData$ZYGOSITY[which(is.na(totData$ZYGOSITY_T1 & !is.na(totData$ZYGOSITY_T2)))]<-totData$ZYGOSITY_T2[which(is.na(totData$ZYGOSITY_T1 & !is.na(totData$ZYGOSITY_T2)))]

table(totData$ZYGOSITY, totData$ZYGOSITY_T2, exclude=NULL)
table(totData$ZYGOSITY, exclude=NULL)

# Set zygosity of sibling pairs to DZ
totData[which(is.na(totData$ZYGOSITY)), c("SEX_T1", "SEX_T2", "ZYGOSITY")]
totData$ZYGOSITY[which(is.na(totData$ZYGOSITY) & totData$SEX_T1=="F" & totData$SEX_T2=="M")]<-5
totData$ZYGOSITY[which(is.na(totData$ZYGOSITY) & totData$SEX_T1=="F" & is.na(totData$SEX_T2))]<-3
totData$ZYGOSITY[which(is.na(totData$ZYGOSITY) & totData$SEX_T1=="M" & is.na(totData$SEX_T2))]<-4

# break down
table(tripData$ZYGOSITY_T1, exclude=NULL)
table(tripData$ZYGOSITY_T1, tripData$ZYGOSITY_T2,exclude=NULL)

table(pairData$ZYGOSITY_T1, pairData$ZYGOSITY_T2, exclude=NULL)
table(pairData$ZYGOSITY_T1, exclude=NULL)

table(singleData$ZYGOSITY_T1, exclude=NULL)

214-33
  28+27+26+26+34+40

# Writing output
#write.table(totData, file="GeneticClusteringOutputPlots/StructuralPhenotypes_Sphere_OpenMx_data_280Pairs.txt", sep="\t", row.names=F, col.names=T)
write.table(totData, file="GeneticClusteringOutputPlots/StructuralPhenotypes_Sphere_OpenMx_data_297Pairs_phenoRegressed.txt", sep="\t", row.names=F, col.names=T)
# 297+215=512 families
297*2+215
# Description of the data (nb pairs)
data<-read.table("GeneticClusteringOutputPlots/StructuralPhenotypes_Sphere_OpenMx_data_297Pairs_phenoRegressed.txt", header=T)
colnames(data)
MZpairs<-data[which(!is.na(data$ID_T1) & !is.na(data$ID_T2) & data$ZYGOSITY<3),]
DZpairs<-data[which(!is.na(data$ID_T1) & !is.na(data$ID_T2) & data$ZYGOSITY>2),]
