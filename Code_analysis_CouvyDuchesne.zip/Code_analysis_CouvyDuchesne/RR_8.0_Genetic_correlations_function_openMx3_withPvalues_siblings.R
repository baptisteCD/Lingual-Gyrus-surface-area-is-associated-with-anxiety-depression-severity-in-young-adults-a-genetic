# ------------------------------------------------------------------------------
# Program: twinMulAceCon.R
#  Author: Hermine Maes
#    Date: 03 04 2014
#
# Multivariate Twin Analysis model to estimate causes of variation
# Matrix style model - Raw data - Continuous data
# -------|---------|---------|---------|---------|---------|---------|


# Load Library
library(OpenMx)
#source("myFunctions.R")
source("RR_GenEpiHelperFunctions.R")

# --------------------------------------------------------------------
# PREPARE DATA


calculatePhenoGenoEnviroCor<-function(data, variables, output){


nv <- length(variables)
selvariables <- c(paste(variables, "_T1", sep=""),  paste(variables, "_T2", sep=""), paste(variables, "_Sib", sep=""))
ntv <- nv*3



# Select Data for Analysis
mzData    <- subset(data, ZYGOSITY<3, selvariables)
dzData    <- subset(data, ZYGOSITY>2, selvariables)


# ------------------------------------------------------------------------------
# Cholesky Decomposition ACE Model
# ------------------------------------------------------------------------------
# Set Starting Values
svMe      <- rep(0.1, ntv)                # start value for means
svPa      <- rep(0.1, nv*(nv+1)/2)

labA<-paste("a", 1:(nv*(nv+1)/2), sep="")
labC<-paste("c", 1:(nv*(nv+1)/2), sep="")
labE<-paste("e", 1:(nv*(nv+1)/2), sep="")

# Matrices declared to store a, c, and e Path Coefficients
pathA     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE,
                       values=svPa, labels=labA, name="a" )
pathC     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE,
                       values=svPa, labels=labC,  name="c" )
pathE     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE,
                       values=svPa, labels=labE,  name="e" )

# Matrices generated to hold A, C, and E computed Variance Components
covA      <- mxAlgebra( expression=a %*% t(a), name="A" )
covC      <- mxAlgebra( expression=c %*% t(c), name="C" )
covE      <- mxAlgebra( expression=e %*% t(e), name="E" )

# Algebra to compute total variances and standard deviations (diagonal only)
covP      <- mxAlgebra( expression=A+C+E, name="V" )
matI      <- mxMatrix( type="Iden", nrow=nv, ncol=nv, name="I")
invSD     <- mxAlgebra( expression=solve(sqrt(I*V)), name="iSD")

StPathA     <- mxAlgebra(iSD %*% a, name="sta")
StPathC     <- mxAlgebra(iSD %*% c, name="stc")
StPathE     <- mxAlgebra(iSD %*% e, name="ste")

# Algebra for expected Mean and Variance/Covariance Matrices in MZ & DZ twins
meanG     <- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE,
                       values=svMe, labels=c("family","happy"), name="expMean" )
covMZ     <-  mxAlgebra(  rbind( cbind(V, A+C, 0.5%x%A+ C),
  						   cbind(A+C, V, 0.5%x%A+ C),
							   cbind(0.5%x%A+ C,  0.5%x%A+ C, V)), name="expCovMZ" )

covDZ     <- mxAlgebra(  rbind( cbind(V, 0.5%x%A+ C, 0.5%x%A+ C),
  						   cbind(0.5%x%A+ C , V ,0.5%x%A+ C),
							   cbind(0.5%x%A+ C ,0.5%x%A+ C, V)), name="expCovDZ" )

# Data objects for Multiple Groups
dataMZ    <- mxData( observed=mzData, type="raw" )
dataDZ    <- mxData( observed=dzData, type="raw" )


# Standardised results
StVA     <- mxAlgebra(sta**2, name="StVA")
StVC     <- mxAlgebra(stc**2, name="StVC")
StVE     <- mxAlgebra(ste**2, name="StVE")
CorA     <- mxAlgebra(solve(sqrt(I*A)) %&% A, name="CorA")
CorC     <- mxAlgebra(solve(sqrt(I*C)) %&% C, name="CorC")
CorE     <- mxAlgebra(solve(sqrt(I*E)) %&% E, name="CorE")
CorPheno<-mxAlgebra(sqrt(StVA[1,1])*sqrt(StVA[2,2]+StVA[2,1])*CorA[2,1] + sqrt(StVE[1,1])*sqrt(StVE[2,2]+StVE[2,1])*CorE[2,1] , name="CorPheno")
StandObj<-c(StVA, StVC, StVE , CorA ,CorC, CorE , CorPheno)

# Objective objects for Multiple Groups
objMZ     <- mxExpectationNormal( covariance="expCovMZ", means="expMean", dimnames=selvariables )
objDZ     <- mxExpectationNormal( covariance="expCovDZ", means="expMean", dimnames=selvariables )

# Combine Groups
fitFunction <- mxFitFunctionML()
pars      <- list( pathA, pathC, pathE, covA, covC, covE, covP, matI,
                   invSD, meanG,StPathA,StPathC,StPathE, StandObj)
modelMZ   <- mxModel( pars, covMZ, dataMZ, objMZ, name="MZ", fitFunction )
modelDZ   <- mxModel( pars, covDZ, dataDZ, objDZ, name="DZ" , fitFunction)

modelFit      <- mxFitFunctionMultigroup( c("MZ", "DZ") )

ConfInt<-mxCI(c( "CorA", "CorE", "CorPheno", "StVA", "StVC","StVE"))
CholAceModel  <- mxModel( "CholACE", pars, modelMZ, modelDZ, ConfInt,modelFit )

# ------------------------------------------------------------------------------
# RUN GENETIC MODEL

# Run Cholesky Decomposition ACE model
CholAceFit    <- mxTryHard(model = CholAceModel, extraTries = 10, greenOK = T, intervals = F)
CholAceFit    <- mxRun(CholAceFit, intervals=T)
CholAceSum    <- summary(CholAceFit)
#CholAceSum

# ------------------------------------------------------------------------------
# Cholesky Decomposition AE Model
# ------------------------------------------------------------------------------
CholAeModel   <- mxModel( CholAceFit, name="CholAE" )
CholAeModel   <- omxSetParameters( CholAeModel, labels=paste("c", 1:(nv*(nv+1)/2), sep=""), free=FALSE, values=0 )
CholAeFit     <- mxTryHard(CholAeModel, extraTries = 10, greenOK = T, intervals = F)
CholAeFit     <- mxRun(CholAeFit, intervals=T)
CholAeSumm<-summary(CholAeFit, verbose=F)
#CholAeSumm
mxCompare(CholAceFit, CholAeFit)

################
# Pvalue for rG, rE and rP
CholAModel   <- mxModel( CholAeFit, name="CholA" )
CholAModel   <- omxSetParameters( CholAModel, labels="e2", free=FALSE, values=0 )
CholAFit     <- mxRun(CholAModel, intervals=T)
CholASumm<-summary(CholAFit, verbose=F)
#CholAeSumm
mxCompare(CholAeFit, CholAFit)

CholEModel   <- mxModel( CholAeFit, name="CholE" )
CholEModel   <- omxSetParameters( CholEModel, labels="a2", free=FALSE, values=0 )
CholEFit     <- mxRun(CholEModel, intervals=T)
CholESumm<-summary(CholEFit, verbose=F)

CholModel   <- mxModel( CholAeFit, name="Chol" )
CholModel   <- omxSetParameters( CholModel, labels=c("a2", "e2"), free=FALSE, values=0 )
CholFit     <- mxRun(CholModel, intervals=T)
CholSumm<-summary(CholFit, verbose=F)
#CholAeSumm

testTable<-mxCompare(CholAeFit, c( CholFit,  CholEFit ,CholAFit))

#Extracting the phenotypic correlation
result<-as.data.frame(matrix(0,ncol=4, nrow=3))
rownames(result)<-c("PhenoCor", "GeneticCor", "EnviroCor")
colnames(result)<-c("estimate", "lbound", "ubound", "pvalue")
result["PhenoCor", ]<-c(CholAeSumm$CI["CholAE.CorPheno[1,1]",c("estimate","lbound", "ubound") ] , testTable$p[2])
result["GeneticCor", ]<-c(CholAeSumm$CI["CholAE.CorA[2,1]",c("estimate","lbound", "ubound") ], testTable$p[3])
result["EnviroCor", ]<-c(CholAeSumm$CI["CholAE.CorE[2,1]",c("estimate","lbound", "ubound") ], testTable$p[4])


if (output!=""){
  write.table(result, output, row.names=T, col.names=T , sep=",")
}

return(result)
}
