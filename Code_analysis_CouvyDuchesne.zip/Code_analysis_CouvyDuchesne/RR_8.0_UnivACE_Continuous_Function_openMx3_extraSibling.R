# ------------------------------------------------------------------------------
# Program: twins.R
#  Author: Hermine Maes    Date: 03 03 2014
#  Edits:  Sarah Medland   Date: 13 04 2014
#
# Univariate Twin Analysis model to estimate causes of variation _ ADE model
# Matrix style model - Raw data - Continuous data
# -------|---------|---------|---------|---------|---------|---------|---------|
#Works for continuous variables

# Set the missing values in the covariates to 999999 ('cause OpenMx is too dumb to realise that
# the covariate is missing only when the variable of interest is also missing)

univACE<-function(data, variable, covariate, output, ACEorADE){

# Load Libraries
require(OpenMx)

nv        <- 1                         # number of variables
ntv       <- nv*3                      # number of total variables
selVars   <- c(paste(variable, "_T1", sep=""),  paste(variable, "_T2", sep=""), paste(variable, "_Sib", sep=""))

# Select Covariates for Analysis

covVars<-c(paste(covariate, "_T1", sep=""),  paste(covariate, "_T2", sep=""),  paste(covariate, "_Sib", sep=""))

# Select Data for Analysis
mzData    <- subset(data, ZYGOSITY<3, c(selVars, covVars))
dzData    <- subset(data, ZYGOSITY>2, c(selVars, covVars))

#table(twinData$sex2)
# ------------------------------------------------------------------------------
# PREPARE ACE /ADE MODEL

# Set Starting Values
svMe      <- 1                   # start value for means
svPa      <- 0.1                    # start value for path coefficients (sqrt(variance/#ofpaths))

# ACE Model
# Matrices declared to store a, d, and e Path Coefficients
pathA     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE, values=svPa,
                       label="a11", name="a" )
pathC     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE, values=svPa,
                       label="c11", name="c" )
pathE     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE, values=svPa,
                       label="e11", name="e" )

# Matrices generated to hold A, D, and E computed Variance Components
covA      <- mxAlgebra( a %*% t(a), name="A" )
covC      <- mxAlgebra( c %*% t(c), name="C" )
covE      <- mxAlgebra( e %*% t(e), name="E" )

# Regression effects
beta1        <- mxMatrix( type="Full", nrow=1, ncol=length(covariate), free=TRUE,
                          values=1, labels=paste("beta_", covariate, sep=""), name="beta1" )
# Independent variables
obsAge       <- mxMatrix( type="Full", nrow=length(covariate), ncol=ntv, free=FALSE,
                          labels=c(paste("data.", covariate, "_T1", sep=""),paste("data.", covariate, "_T2", sep=""),
                                   paste("data.", covariate, "_Sib", sep="")),
                          name="Covars")

# Algebra for expected Mean Matrices in MZ & DZ twins
meanG     <- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=svMe,
                       labels=selVars, name="mean" )
expMean   <- mxAlgebra(  mean + beta1 %*% Covars, name="expMean" )

# Algebra for expected Variance/Covariance Matrices in MZ & DZ twins
covP      <- mxAlgebra(  A+C+E, name="V" )

expCovMZ <- mxAlgebra(  rbind( cbind(V, A+C, 0.5%x%A+ C),
							   cbind(A+C, V, 0.5%x%A+ C),
							   cbind(0.5%x%A+ C,  0.5%x%A+ C, V)), name="expCovMZ" )
if (ACEorADE=="ACE"){
expCovDZ <- mxAlgebra(  rbind( cbind(V, 0.5%x%A+ C, 0.5%x%A+ C),
							   cbind(0.5%x%A+ C , V ,0.5%x%A+ C),
							   cbind(0.5%x%A+ C ,0.5%x%A+ C, V)), name="expCovDZ" )

} else if (ACEorADE=="ADE"){expCovDZ <- mxAlgebra(  rbind( cbind(V, 0.5%x%A+ 0.25%x%C, 0.5%x%A+ 0.25%x%C),
                                    cbind(0.5%x%A+ 0.25%x%C , V, 0.5%x%A+ 0.25%x%C),
                                    cbind(0.5%x%A+ 0.25%x%C ,  0.5%x%A+ 0.25%x%C, V)
                                    ), name="expCovDZ" )
}

# Matrices generated to hold A, D, and E standardised estimates
StA      <- mxAlgebra( A/V, name="stA" )
StC      <- mxAlgebra( C/V, name="stC" )
StE      <- mxAlgebra( E/V, name="stE" )

# Data objects for Multiple Groups
dataMZ    <- mxData( observed=mzData, type="raw" )
dataDZ    <- mxData( observed=dzData, type="raw" )

CIs<-mxCI(c("A", "C", "E", "stA", "stC", "stE", "beta1"))

# Objective objects for Multiple Groups
objMZ     <- mxExpectationNormal( covariance="expCovMZ", means="expMean", dimnames=selVars )
objDZ     <- mxExpectationNormal( covariance="expCovDZ", means="expMean", dimnames=selVars )

# Combine Groups
fitFunction <- mxFitFunctionML()
pars      <- list( pathA, pathC, pathE, covA, covC, covE, covP, beta1, StA, StC, StE)
modelMZ   <- mxModel( pars, obsAge, meanG, expMean, expCovMZ, dataMZ, objMZ, CIs,fitFunction,
			name="MZ" )
modelDZ   <- mxModel( pars, obsAge, meanG, expMean, expCovDZ, dataDZ, objDZ,fitFunction,
			name="DZ" )
modelFit      <- mxFitFunctionMultigroup( c("MZ", "DZ") )
ACEModel  <- mxModel( "ACE", pars, modelMZ, modelDZ, modelFit )
ACEModel    <- omxAssignFirstParameters(ACEModel)

# ------------------------------------------------------------------------------

# Run ACE model
ACEFit    <- mxTryHard(ACEModel, extraTries = 15, greenOK = T)
ACEFit    <- mxRun(ACEFit, intervals=T)
ACESumm   <- summary(ACEFit)

ACESumm$parameters$Estimate
# ------------------------------------------------------------------------------
# FIT SUBMODELS

# Run AE model
AeModel   <- mxModel( ACEFit, name="AE" )
AeModel   <- omxSetParameters( AeModel, labels="c11", free=FALSE, values=0 )
AeFit     <- mxTryHard(AeModel, extraTries = 15, greenOK = T)
AeFit    <- mxRun(AeFit, intervals=T)
AeSumm<-summary(AeFit)

# Run CE model
CeModel   <- mxModel( ACEFit, name="CE" )
CeModel   <- omxSetParameters( CeModel, labels="a11", free=FALSE, values=0 )
CeFit     <- mxTryHard(CeModel, extraTries = 15, greenOK = T)
CeFit    <- mxRun(CeFit, intervals=T)
CeSumm<-summary(CeFit )

# Run E model
eModel    <- mxModel( AeFit, name="E")
eModel    <- omxSetParameters( eModel, labels="a11", free=FALSE, values=0 )
eFit      <- mxRun(eModel, intervals=T )
eSumm <- summary(eFit)

# Print Comparative Fit Statistics
ACENested <- list(AeFit,CeFit,eFit)
Results<-mxCompare(ACEFit,ACENested)

Results$A<-NA
Results$Alb<-NA
Results$Aub<-NA

Results$C<-NA
Results$Clb<-NA
Results$Cub<-NA

Results$E<-NA
Results$Elb<-NA
Results$Eub<-NA
Results$status<-NA

ACEcolnames<-c("Alb", "A", "Aub", "Clb", "C", "Cub", "Elb", "E", "Eub", "status")

Results[1, ACEcolnames]<-c(ACESumm$CI["MZ.stA[1,1]",][1:3],
             ACESumm$CI["MZ.stC[1,1]",][1:3] ,
             ACESumm$CI["MZ.stE[1,1]",][1:3], ACEFit$output$status$code)

Results[2, ACEcolnames]<-c(AeSumm$CI["MZ.stA[1,1]",][1:3],
                           AeSumm$CI["MZ.stC[1,1]",][1:3] ,
                           AeSumm$CI["MZ.stE[1,1]",][1:3],
                           AeFit$output$status$code)

Results[3, ACEcolnames]<-c(CeSumm$CI["MZ.stA[1,1]",][1:3],
                           CeSumm$CI["MZ.stC[1,1]",][1:3] ,
                           CeSumm$CI["MZ.stE[1,1]",][1:3],
                           CeFit$output$status$code)

Results[4, ACEcolnames]<-c(eSumm$CI["MZ.stA[1,1]",][1:3],
                           eSumm$CI["MZ.stC[1,1]",][1:3] ,
                           eSumm$CI["MZ.stE[1,1]",][1:3],
                           eFit$output$status$code)

if (ACEorADE=="ADE"){
  colnames(Results)[13:15]<-c("D", "Dlb", "Dub")
}

if (output!=""){
  write.table(Results, output, sep=",", col.names=T, row.names=F)
  }
return(Results)

}
