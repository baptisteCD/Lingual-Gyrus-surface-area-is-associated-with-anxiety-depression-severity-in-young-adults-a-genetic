# ------------------------------------------------------------------------------
# Program: continuousAsumptions.R  
#  Author: Sarah Medland
#    Date: 10 04 2012 
#
# Twin Covariances
# -------|---------|---------|---------|---------|---------|---------|---------|


# Load Libraries
require(OpenMx)


##FUNCTION
# Function that returns (and write) a table with difference log likelihood and p-values
# For he assumption testing of a uniavariate variable, with age (or one continuous variable)
# as a covariate
############################
## LIMITATIONS
# Set the missing values in the covariates to 999999 ('cause OpenMx is too dumb to realise that 
# the covariate is missing only when the variable of interest is also missing)
# If a covariate is discrete, declare it first using data$discreteVar<-mxFactor(data$discreteVar)

testingSaturatedUnivModel<-function(data, variable, covariate){

pvalue_results<-as.data.frame(matrix(0, nrow=12+length(covariate), ncol=1), 
                              row.names=c("H1m", "H2m", "H3m", "H4m", "H1v", "H2v", 
                                          "H3v", "H4v", "H1c", "H2c", "H3c", "H4c", covariate))
colnames(pvalue_results)<-variable


# Select Variables for Analysis
nv        <- 1       # number of variables
ntv       <- nv*2    # number of total variables

Vars   <- variable
selVars <- c(paste(Vars,"_T1",sep=""),paste(Vars,"_T2",sep=""))
defVars<- c(paste(covariate,"_T1",sep=""),paste(covariate,"_T2",sep=""))
useVars   <- c(selVars, defVars)
# ------------------------------------------------------------------
# PREPARE MODEL

# Saturated Model
# Set Starting Values
StMean  <- 20      # start value for means
StSd    <-  1# start value for standard deviation
StMZ    <- .8# start value for MZ correlation
StDZ    <- .4# start value for DZ correlation


# Age corrections
# Regression effects
beta1        <- mxMatrix( type="Full", nrow=1, ncol=length(covariate), free=TRUE, 
		values=1, labels=paste("beta_", covariate, sep=""), name="beta1" )

# Independent variables
obsAge       <- mxMatrix( type="Full", nrow=length(covariate), ncol=ntv, free=FALSE, 
		labels=c(paste("data.", covariate, "_T1", sep=""),paste("data.", covariate, "_T2", sep="")),
    name="Covars")

inclusions   <- list (beta1,obsAge)
# Select Data for Analysis & specify the model
# Algebra for expected Mean Matrices 
# Building the model 
# Algebra for expected Variance/Covariance Matrices in MZ & DZ twins
# Build Objectives for each group
fitFunction <- mxFitFunctionML(rowDiagnostics=TRUE)

mzfdata    	<- subset(data, ZYGOSITY==1, useVars)
mzfData     <- mxData( observed=mzfdata, type="raw" )
meanfMZ     <- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean1","mean1a"), name="intercept_fMZ" )
expMeanfMZ  <- mxAlgebra( intercept_fMZ + beta1  %*% Covars, name="regressfMZ")
sdFMZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd1","sd1a"), name="sd_fMZ")
corfMZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StMZ,  labels="cor1",name="corfMZ" )
expCovfMZ   <- mxAlgebra( sd_fMZ %&% corfMZ , name="expCovfMZ")
objfMZ    	<- mxExpectationNormal( covariance="expCovfMZ", means="regressfMZ", dimnames=selVars )
modelfMZ    <- mxModel( "fMZ", inclusions, expMeanfMZ, meanfMZ, sdFMZ, corfMZ, expCovfMZ, mzfData, objfMZ,fitFunction )

mzmdata    	<- subset(data, ZYGOSITY==2, useVars)
mzmData      	<- mxData( observed=mzmdata, type="raw" )
meanmMZ    	<- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean2","mean2a"), name="intercept_mMZ" )
expMeanmMZ      <- mxAlgebra(intercept_mMZ + beta1  %*% Covars, name="regressmMZ")
sdMMZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd2","sd2a"), name="sd_mMZ")
cormMZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StMZ,  labels="cor2",name="cormMZ" )
expCovmMZ   <- mxAlgebra( sd_mMZ %&% cormMZ , name="expCovmMZ")
objmMZ    	<- mxExpectationNormal( covariance="expCovmMZ", means="regressmMZ", dimnames=selVars )
modelmMZ    <- mxModel( "mMZ", inclusions, expMeanmMZ, meanmMZ, sdMMZ, cormMZ, expCovmMZ, mzmData, objmMZ,fitFunction )

dzfdata    	<- subset(data, ZYGOSITY==3, useVars)
dzfData      	<- mxData( observed=dzfdata, type="raw" )
meanfDZ    	<- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean3","mean3a"), name="intercept_fDZ" )
expMeanfDZ      <- mxAlgebra(intercept_fDZ + beta1  %*% Covars, name="regressfDZ")
sdFDZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd3","sd3a"), name="sd_fDZ")
corfDZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StDZ,  labels="cor3",name="corfDZ" )
expCovfDZ   <- mxAlgebra( sd_fDZ %&% corfDZ , name="expCovfDZ")
objfDZ    	<- mxExpectationNormal( covariance="expCovfDZ", means="regressfDZ", dimnames=selVars )
modelfDZ    <- mxModel( "fDZ", inclusions, expMeanfDZ, meanfDZ, sdFDZ, corfDZ, expCovfDZ, dzfData, objfDZ,fitFunction )

dzmdata    	<- subset(data, ZYGOSITY==4, useVars)
dzmData      	<- mxData( observed=dzmdata, type="raw" )
meanmDZ    	<- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean4","mean4a"), name="intercept_mDZ" )
expMeanmDZ      <- mxAlgebra(intercept_mDZ + beta1  %*% Covars, name="regressmDZ")
sdMDZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd4","sd4a"), name="sd_mDZ")
cormDZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StDZ,  labels="cor4",name="cormDZ" )
expCovmDZ   <- mxAlgebra( sd_mDZ %&% cormDZ , name="expCovmDZ")
objmDZ    	<- mxExpectationNormal( covariance="expCovmDZ", means="regressmDZ", dimnames=selVars )
modelmDZ    <- mxModel( "mDZ", inclusions, expMeanmDZ, meanmDZ, sdMDZ, cormDZ, expCovmDZ, dzmData, objmDZ ,fitFunction)

dzfmdata   	<- subset(data, ZYGOSITY==5, useVars)
dzfmData      	<- mxData( observed=dzfmdata, type="raw" )
meanfmDZ   	<- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean5","mean6"), 
                         name="intercept_fmDZ" )
expMeanfmDZ     <- mxAlgebra(intercept_fmDZ + beta1  %*% Covars, name="regressfmDZ")
sdFMDZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd5","sd6"), name="sd_fmDZ")
corfmDZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StDZ,  labels="cor5",name="corfmDZ" )
expCovfmDZ   <- mxAlgebra( sd_fmDZ %&% corfmDZ , name="expCovfmDZ")
objfmDZ    	<- mxExpectationNormal( covariance="expCovfmDZ", means="regressfmDZ", dimnames=selVars )
modelfmDZ    <- mxModel( "fmDZ", inclusions, expMeanfmDZ, meanfmDZ, sdFMDZ, corfmDZ, expCovfmDZ, dzfmData, objfmDZ,fitFunction )

dzmfdata     <- subset(data, ZYGOSITY==6, useVars)
dzmfData      	<- mxData( observed=dzmfdata, type="raw" )
meanmfDZ   	<- mxMatrix( type="Full", nrow=1, ncol=ntv, free=TRUE, values=StMean, labels=c("mean6","mean5"), name="intercept_mfDZ" )
expMeanmfDZ     <- mxAlgebra(intercept_mfDZ + beta1  %*% Covars, name="regressmfDZ")
sdMFDZ       <- mxMatrix( type = "Diag", nrow=ntv, ncol=ntv, free=TRUE, values=StSd, labels=c("sd6","sd5"), name="sd_mfDZ")
cormfDZ     	<- mxMatrix( type="Stand", nrow=ntv, ncol=ntv, free=TRUE, values=StDZ,  labels="cor5",name="cormfDZ" )
expCovmfDZ   <- mxAlgebra( sd_mfDZ %&% cormfDZ , name="expCovmfDZ")
objmfDZ    	<- mxExpectationNormal( covariance="expCovmfDZ", means="regressmfDZ", dimnames=selVars )
modelmfDZ    <- mxModel( "mfDZ", inclusions, expMeanmfDZ, meanmfDZ, sdMFDZ, cormfDZ, expCovmfDZ, dzmfData, objmfDZ,fitFunction )


# Sum the likelihoods
#minus2ll  <- mxAlgebra( fMZ.objective+mMZ.objective+fDZ.objective+mDZ.objective+fmDZ.objective+mfDZ.objective , 
#name="minus2sumloglikelihood" )
modelFit      <- mxFitFunctionMultigroup( c("fMZ", "mMZ", "fDZ", "mDZ", "fmDZ", "mfDZ") )

# The object "ciCov" is produced to hold 
# 95% confidence intervals using the mxCI() function. 
# CIs are not really needed for saturated models
#ciMean     <- mxCI( c('fMZ.expMeanfMZ','mMZ.expMeanmMZ','fDZ.expMeanfDZ','mDZ.expMeanmDZ','fmDZ.expMeanfmDZ' , 'mfDZ.expMeanmfDZ'))
#ciCov     <- mxCI( c('fMZ.expCovfMZ','mMZ.expCovmMZ','fDZ.expCovfDZ','mDZ.expCovmDZ','fmDZ.expCovfmDZ' ,'mfDZ.expCovmfDZ'))

#Putting it all together
baseModel   <- mxModel( "base", modelfMZ, modelmMZ, modelfDZ, modelmDZ, modelfmDZ, modelmfDZ,  
                        modelFit )
#ciCov, ciMean
# ------------------------------------------------------------------------------
# RUN MODEL

baseFit     <- mxRun( baseModel, intervals=FALSE )

baseSumm    <- summary( baseFit )
baseSumm



#################################################################################################
# SUBMODELS
#################################################################################################


# Constrain expected Means to be equal across twin order
meanmodel1    <- baseFit
meanmodel1    <- omxSetParameters( meanmodel1, label="mean1a",  newlabels='mean1' )
meanmodel1    <- omxSetParameters( meanmodel1, label="mean2a",  newlabels='mean2' )
meanmodel1    <- omxSetParameters( meanmodel1, label="mean3a",  newlabels='mean3' )
meanmodel1    <- omxSetParameters( meanmodel1, label="mean4a",  newlabels='mean4' )
meanmodel1    <- omxAssignFirstParameters(meanmodel1)
meanmodel1Fit      	<- mxRun( meanmodel1, intervals=F )
meanmodel1Summ     	<- summary( meanmodel1Fit )
pvalue_results[1,1]<-pchisq(meanmodel1Summ$Minus2LogLikelihood-baseSumm$Minus2LogLikelihood ,
       meanmodel1Summ$degreesOfFreedom - baseSumm$degreesOfFreedom ,lower.tail=F)


# Constrain expected Means to be equal  in same-sex pairs
meanmodel2    <- meanmodel1
meanmodel2    <- omxSetParameters( meanmodel2, label="mean1",  newlabels='mean3' )
meanmodel2    <- omxSetParameters( meanmodel2, label="mean2",  newlabels='mean4' )
meanmodel2    <- omxAssignFirstParameters(meanmodel2)
meanmodel2Fit        <- mxRun( meanmodel2, intervals=F )
meanmodel2Summ     	<- summary( meanmodel2Fit )
#tableFitStatistics(meanmodel1Fit, meanmodel2Fit) 
pvalue_results[2,1]<-pchisq(meanmodel2Summ$Minus2LogLikelihood-meanmodel1Summ$Minus2LogLikelihood ,
                             meanmodel2Summ$degreesOfFreedom- meanmodel1Summ$degreesOfFreedom ,lower.tail=F)


# Constrain expected Means to be equal between same sex and opposite sex pairs
meanmodel3    <- meanmodel2
meanmodel3    <- omxSetParameters( meanmodel3, label="mean5",  newlabels='mean3' )
meanmodel3    <- omxSetParameters( meanmodel3, label="mean6",  newlabels='mean4' )
meanmodel3    <- omxAssignFirstParameters(meanmodel3)
meanmodel3Fit        <- mxRun( meanmodel3, intervals=F )
meanmodel3Summ       <- summary( meanmodel3Fit )
#tableFitStatistics(meanmodel2Fit, meanmodel3Fit) 
pvalue_results[3,1]<-pchisq(meanmodel3Summ$Minus2LogLikelihood-meanmodel2Summ$Minus2LogLikelihood ,
                            meanmodel3Summ$degreesOfFreedom- meanmodel2Summ$degreesOfFreedom ,lower.tail=F)



# Constrain expected Means to be equal across sex and zygosity pair
meanmodel4    <- meanmodel3
meanmodel4    <- omxSetParameters( meanmodel4, label="mean3",  newlabels='mean4' )
meanmodel4    <- omxAssignFirstParameters(meanmodel4)
meanmodel4Fit        <- mxRun( meanmodel4, intervals=F )
meanmodel4Summ       <- summary( meanmodel4Fit )
#tableFitStatistics(meanmodel3Fit, meanmodel4Fit)
pvalue_results[4,1]<-pchisq(meanmodel4Summ$Minus2LogLikelihood-meanmodel3Summ$Minus2LogLikelihood ,
                            meanmodel4Summ$degreesOfFreedom- meanmodel3Summ$degreesOfFreedom ,lower.tail=F)



############################################
# Constrain expected var to be equal across twin order
covModel1    <- meanmodel4
covModel1    <- omxSetParameters( covModel1, label="sd1a",  newlabels='sd1' )
covModel1    <- omxSetParameters( covModel1, label="sd2a",  newlabels='sd2' )
covModel1    <- omxSetParameters( covModel1, label="sd3a",  newlabels='sd3' )
covModel1    <- omxSetParameters( covModel1, label="sd4a",  newlabels='sd4' )
covModel1    <- omxAssignFirstParameters(covModel1)
covModel1Fit        <- mxRun( covModel1, intervals=F )
covModel1Summ     	<- summary( covModel1Fit )
#tableFitStatistics(meanmodel4Fit, covModel1Fit)
pvalue_results[5,1]<-pchisq(covModel1Summ$Minus2LogLikelihood-meanmodel4Summ$Minus2LogLikelihood ,
                            covModel1Summ$degreesOfFreedom- meanmodel4Summ$degreesOfFreedom ,lower.tail=F)


# Constrain expected var to be equal across zygosity (for same sex)
covModel2    <- covModel1Fit
covModel2    <- omxSetParameters( covModel2, label="sd3",  newlabels='sd1' )
covModel2    <- omxSetParameters( covModel2, label="sd4",  newlabels='sd2' )
covModel2    <- omxAssignFirstParameters(covModel2)
covModel2Fit        <- mxRun( covModel2, intervals=F )
covModel2Summ       <- summary( covModel2Fit )
#tableFitStatistics(covModel1Fit, covModel2Fit)
pvalue_results[6,1]<-pchisq(covModel2Summ$Minus2LogLikelihood-covModel1Summ$Minus2LogLikelihood ,
                            covModel2Summ$degreesOfFreedom- covModel1Summ$degreesOfFreedom ,lower.tail=F)



# Constrain expected var to be equal btw same sex and opposite sex pairs
covModel3    <- covModel2Fit
covModel3    <- omxSetParameters( covModel3, label="sd5",  newlabels='sd1' )
covModel3    <- omxSetParameters( covModel3, label="sd6",  newlabels='sd2' )
covModel3    <- omxAssignFirstParameters(covModel3)
covModel3Fit        <- mxRun( covModel3, intervals=F )
covModel3Summ       <- summary( covModel3Fit )
#tableFitStatistics(covModel2Fit, covModel3Fit)
pvalue_results[7,1]<-pchisq(covModel3Summ$Minus2LogLikelihood-covModel2Summ$Minus2LogLikelihood ,
                            covModel3Summ$degreesOfFreedom- covModel2Summ$degreesOfFreedom ,lower.tail=F)

# Constrain expected var to be equal for all pairs
covModel4    <- covModel3Fit
covModel4    <- omxSetParameters( covModel4, label="sd2",  newlabels='sd1' )
covModel4    <- omxAssignFirstParameters(covModel4)
covModel4Fit        <- mxRun( covModel4, intervals=F )
covModel4Summ       <- summary( covModel4Fit )
#tableFitStatistics(covModel3Fit, covModel4Fit)
pvalue_results[8,1]<-pchisq(covModel4Summ$Minus2LogLikelihood-covModel3Summ$Minus2LogLikelihood ,
                            covModel4Summ$degreesOfFreedom- covModel3Summ$degreesOfFreedom ,lower.tail=F)

############################################
# Constrain expected covar/correlation to be equal across same sex MZ-DZ pairs
varModel1    <- covModel4
varModel1    <- omxSetParameters( varModel1, label="cor2",  newlabels='cor1' )
varModel1    <- omxSetParameters( varModel1, label="cor4",  newlabels='cor3' )
varModel1    <- omxAssignFirstParameters(varModel1)
varModel1Fit        <- mxRun( varModel1, intervals=F )
varModel1Summ       <- summary( varModel1Fit )
#tableFitStatistics(covModel4Fit, varModel1Fit)
pvalue_results[9,1]<-pchisq(varModel1Summ$Minus2LogLikelihood-covModel4Summ$Minus2LogLikelihood ,
                            varModel1Summ$degreesOfFreedom- covModel4Summ$degreesOfFreedom ,lower.tail=F)


# Constrain expected covar/correlation to be equal across same sex/ diff sex pairs
varModel2    <- varModel1
varModel2    <- omxSetParameters( varModel2, label="cor5",  newlabels='cor3' )
varModel2    <- omxAssignFirstParameters(varModel2)
varModel2Fit        <- mxRun( varModel2, intervals=F )
varModel2Summ       <- summary( varModel2Fit )
#tableFitStatistics(varModel1Fit, varModel2Fit)
pvalue_results[10,1]<-pchisq(varModel2Summ$Minus2LogLikelihood-varModel1Summ$Minus2LogLikelihood ,
                            varModel2Summ$degreesOfFreedom- varModel1Summ$degreesOfFreedom ,lower.tail=F)


# Constrain expected covar/correlation to be equal across same sex/ diff sex pairs
varModel3    <- varModel2
varModel3    <- omxSetParameters( varModel3, label="cor3",  newlabels='cor1' )
varModel3    <- omxAssignFirstParameters(varModel3)
varModel3Fit        <- mxRun( varModel3, intervals=F )
varModel3Summ       <- summary( varModel3Fit )
#tableFitStatistics(varModel2Fit, varModel3Fit)
pvalue_results[11,1]<-pchisq(varModel3Summ$Minus2LogLikelihood-varModel2Summ$Minus2LogLikelihood ,
                             varModel3Summ$degreesOfFreedom- varModel2Summ$degreesOfFreedom ,lower.tail=F)

# Constrain all covariances to zero (famillial aggregation)
varModel4   <- varModel3
varModel4    <- omxSetParameters( varModel4, label="cor1", free=F, value=0 )
varModel4    <- omxAssignFirstParameters(varModel4)
varModel4Fit        <- mxRun( varModel4, intervals=F )
varModel4Summ       <- summary( varModel4Fit )
#tableFitStatistics(varModel3Fit, varModel4Fit)
pvalue_results[12,1]<-pchisq(varModel4Summ$Minus2LogLikelihood-varModel3Summ$Minus2LogLikelihood ,
                             varModel4Summ$degreesOfFreedom- varModel3Summ$degreesOfFreedom ,lower.tail=F)

# Significance of covariates
############################################
JJ<-1
for (covcov in covariate){
ageModel    <-  baseFit
ageModel    <- omxSetParameters( ageModel, label=paste("beta_", covcov, sep=""),  free=F, value=0)
ageModel    <- omxAssignFirstParameters(ageModel)
ageModelFit        <- mxRun(ageModel, intervals=F )
ageModelSumm       <- summary( ageModelFit )
#tableFitStatistics(baseFit, ageModelFit)
pvalue_results[12+JJ,1]<-pchisq(ageModelSumm$Minus2LogLikelihood-baseSumm$Minus2LogLikelihood ,
                             ageModelSumm$degreesOfFreedom- baseSumm$degreesOfFreedom ,lower.tail=F)
JJ<-JJ+1
}
return(pvalue_results)
}