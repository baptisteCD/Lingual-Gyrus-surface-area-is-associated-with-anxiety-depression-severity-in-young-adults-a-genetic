# genetic correlation between R lingual surfarea
# Check heritabilities first?

source("RR_8.0_Genetic_correlations_function_openMx3_withPvalues.R")
source("RR_8.0_UnivACE_Continuous_Function_openMx3.R")
source("RR_8.0_Univ_SaturatedModel_function_OpenMx3.R")


data<-read.table("GeneticClusteringOutputPlots/StructuralPhenotypes_Sphere_OpenMx_data_297Pairs_phenoRegressed.txt", header=T, sep="\t")
colnames(data)

MZpairs<-data[which(!is.na(data$ID_T1) & !is.na(data$ID_T2) & data$ZYGOSITY<3),]
DZpairs<-data[which(!is.na(data$ID_T1) & !is.na(data$ID_T2) & data$ZYGOSITY>2),]

hist(c(data$anxDepScore_T1, data$anxDepScore_T2))

data$SEX01_T1<-mxFactor(data$SEX01_T1, levels=c(0,1))
data$SEX01_T2<-mxFactor(data$SEX01_T2, levels=c(0,1))

data$ageScore_T1[which(is.na(data$ageScore_T1))]<-999999
data$ageScore_T2[which(is.na(data$ageScore_T2))]<-999999

# Regress out age and sex from anx-dep score
  m1 = glm("c(anxDepScore_T1, anxDepScore_T2) ~ factor(c(SEX_T1, SEX_T2)) + c(ageScore_T1, ageScore_T2)" , na.action=na.exclude,family = gaussian(link = "identity"), data = data)
summary(m1)
  length(residuals(m1))/2
data$anxDepScore_reg_T1<-residuals(m1)[1:512]
data$anxDepScore_reg_T2<-residuals(m1)[513:1024]
###################################
# univariate heritability of cortical regions

# Significant cluster:
allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, signifRes$var)

# pheno<-allVars[1]
for (pheno in allVars){
univACE(data=data,
        variable=paste0(pheno,"_reg"),
        output=paste("GeneticClusteringOutputPlots/ACE_model_", pheno,"_reg_geneticClusters_meanSAcorrected.csv",sep = ""),
        covariate=c("SEX01"),
        ACEorADE="ACE")
}
univACE(data=data,
        variable=paste0(pheno,"_reg"),
        output=paste("GeneticClusteringOutputPlots/ADE_model_", pheno,"_reg_geneticClusters_meanSAcorrected.csv",sep = ""),
        covariate=c("SEX01"),
        ACEorADE="ADE")

# Heritability of the sphere score
univACE(data=data,
        variable="anxDepScore",
        output="GeneticClusteringOutputPlots/ACE_model_anxDepScore.csv",
        covariate=c("SEX01", "ageScore"),
        ACEorADE="ACE")
univACE(data=data,
        variable="anxDepScore_reg",
        output="GeneticClusteringOutputPlots/ACE_model_anxDepScore_reg.csv",
        covariate=c("SEX01"),
        ACEorADE="ACE")
univACE(data=data,
        variable="anxDepScore",
        output="GeneticClusteringOutputPlots/ADE_model_anxDepScore.csv",
        covariate=c("SEX01", "ageScore"),
        ACEorADE="ADE")


# Genetic correlations (linear)
for (var in paste0(allVars, "_reg") ){
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore_reg", var), output=paste("GeneticClusteringOutputPlots/GeneticCor_anxDepScore_reg", var,"_reg.csv", sep = ""))
}














##############
# Genetic correlations between ICV, mean SA and CT with anxiety Depression
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "ICV"),
                            output="GeneticCor_anxDep_ICV_unReg.csv")
cor(c(data$anxDepScore_T1, data$anxDepScore_T2), c(data$ICV_T1, data$ICV_T2), use = "complete.obs")


calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "RSurfArea"),
                            output="GeneticCor_anxDep_RSurfArea_unReg.csv")
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "LSurfArea"),
                            output="GeneticCor_anxDep_LSurfArea_unReg.csv")

calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "RThickness"),
                            output="GeneticCor_anxDep_RThickness_unReg.csv")
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScore", "LThickness"),
                            output="GeneticCor_anxDep_LThickness_unReg.csv")









# Regressed variables
calculatePhenoGenoEnviroCor(data=data, variables=c("anxDepScoreReg", "R_lingual_surfavg_reg"),
                    output="GeneticCor_anxDep_RlingSA_Reg.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScore", "R_lingual_surfavg_reg"),
                    outputName="GeneticCor_anxDep_RlingSA_Reg.csv")


# With Splines
geneticCorrelations(data=data, variables=c("anxDepScoreB3", "R_lingual_surfavg_reg"),
                    outputName="GeneticCor_anxDepB3_RlingSA_Reg.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScoreB3", "R_lingual_surfavg_reg"),
                                outputName="GeneticCor_anxDepB3_RlingSA_Reg.csv")

# more regressed
geneticCorrelations(data=data, variables=c("anxDepScoreB3_reg", "R_lingual_surfavg_reg2"),
                    outputName="GeneticCor_anxDepB3_RlingSA_Reg2.csv")

geneticCorrelations_noEnviroCor(data=data, variables=c("anxDepScoreB3_reg", "R_lingual_surfavg_reg2"),
                                outputName="GeneticCor_anxDepB3_RlingSA_Reg2.csv")


############### plot for posters with heritability of AnxDep and Rlingual Gyrus
# get the data for plotting in the right format
dataPlot<-matrix(0, ncol=2, nrow=1)
dataPlot<-as.data.frame(dataPlot)
colnames(dataPlot)<-c("Anxiety-Depression","Right Lingual Surface Area")
dataPlot[,"Anxiety-Depression"]<-c(0.39)
dataPlot[,"Right Lingual Surface Area"]<-c(0.61)


library(Hmisc)
pdf("Heritablity_AnxDep_RLSA.pdf", width = 10, height = 7)
par(oma=c(0,1,0,1), mfrow=c(1,1), xpd=NA)
bp<-barplot(as.matrix(dataPlot), col=c("blue", "darkblue"),space=c(0.5, 0.5) , beside = T,
            names.arg=c("Anxiety-Depression","Right Lingual Surface Area"), cex=1.5, cex.axis=1.5, ylim=c(0,1), ylab="Heritability", cex.lab=1.5)
errbar(bp, c(0.39, 0.61),yminus = c(0.27, 0.51),yplus =  c(0.51, 0.70), add=T, xlab="", cap = 0.2, cex=2, lwd = 2)
# Restore default clipping rect
par(mar=c(5, 4, 4, 2) + 0.1)
dev.off()



