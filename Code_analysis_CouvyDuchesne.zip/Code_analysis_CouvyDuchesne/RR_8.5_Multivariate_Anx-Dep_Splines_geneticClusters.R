# Decompose the Splines variance
# And explain it in terms of Anx-dep score
##################################################
require(OpenMx)
source("RR_GenEpiHelperFunctions.R")

source("RR_8.0_Genetic_correlations_function_openMx3_withPvalues.R")
source("RR_8.0_UnivACE_Continuous_Function_openMx3.R")
source("RR_8.0_Univ_SaturatedModel_function_OpenMx3.R")

data<-read.table("GeneticClusteringOutputPlots/StructuralPhenotypes_Sphere_OpenMx_data_297Pairs_phenoRegressed.txt", header=T, sep="\t")

# Significant cluster:
allVars<-c("SurfAreaRight12")
# Significant vertices
resultCor<-read.table("GeneticClusteringOutputPlots/HGLM_summary_SignificanceAnxDep_SA_nonLinear_Corrected_VertexWise.txt", sep="\t", header=T, stringsAsFactors = F)
#signifRes<-resultCor[which(resultCor$pval_anxDepScoreS3< 4.2E-4),]
allVars<-c(allVars, resultCor$var)



# multiply phenotypes by 100 to facilitate convergence of the optimizer
#data[,paste(SAvars, "_T1", sep="")]<-data[,paste(SAvars, "_T1", sep="")]*100
#data[,paste(SAvars, "_T2", sep="")]<-data[,paste(SAvars, "_T2", sep="")]*100

res<-as.data.frame(matrix(0, nrow = length(allVars), ncol = 8))
rownames(res)<-paste0(allVars, "_reg")
colnames(res)<-c("lbound_rg"  ,"rG","ubound_rg","pval_rg","lbound_re"  ,"rE","ubound_re", "pval_re")

resLinear<-as.data.frame(matrix(0, nrow = length(allVars), ncol = 8))
rownames(resLinear)<-paste0(allVars, "_reg")
colnames(resLinear)<-c("lbound_rg"  ,"rG","ubound_rg","pval_rg","lbound_re"  ,"rE","ubound_re", "pval_re")
#var<-paste0(allVars, "_reg")[1]

var<-"SurfAreaRight12_reg"

for (var in paste0(allVars, "_reg") ){


  # Select Variables for Analysis
Vars   <-  c(  "anxDepScoreSS_reg_S1",
                "anxDepScoreSS_reg_S2",
                "anxDepScoreSS_reg_S3",
               var)
nv        <- 4       # number of variables
ntv       <- nv*2    # number of total variables
selVars   <-  c(paste(Vars,"_T1",sep=""),paste(Vars,"_T2",sep=""))

# Select Data for Analysis
mzData    <- subset(data, ZYGOSITY<3, selVars)
dzData    <- subset(data, ZYGOSITY>2, selVars)

# Set Starting Values
paVal     <- 10
paVals    <- diag(paVal,nv,nv)
meVals    <- 0.1
meanLabs  <- paste(Vars,"mean",sep="")

# Create Labels for Lower Triangular Matrices
aLabs <- paste("a", do.call(c, sapply(seq(1, nv), function(x){ paste(x:nv, x,sep="") })), sep="")
cLabs <- paste("c", do.call(c, sapply(seq(1, nv), function(x){ paste(x:nv, x,sep="") })), sep="")
eLabs <- paste("e", do.call(c, sapply(seq(1, nv), function(x){ paste(x:nv, x,sep="") })), sep="")

# ------------------------------------------------------------------------------
# PREPARE MODEL

# Cholesky Decomposition ACE Model
# Matrices declared to store a, c, and e Path Coefficients
pathA     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE, values=paVals, labels=aLabs, name="a" )
pathC     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=F, values=0, labels=cLabs, name="c" )
pathE     <- mxMatrix( type="Lower", nrow=nv, ncol=nv, free=TRUE, values=paVals, labels=eLabs, name="e" )

# Matrices generated to hold A, C, and E computed Variance Components
covA      <- mxAlgebra( expression=a %*% t(a), name="A" )
covC      <- mxAlgebra( expression=c %*% t(c), name="C" )
covE      <- mxAlgebra( expression=e %*% t(e), name="E" )

CorA     <- mxAlgebra(solve(sqrt(I*A)) %&% A, name="CorA")
CorC     <- mxAlgebra(solve(sqrt(I*C)) %&% C, name="CorC")
CorE     <- mxAlgebra(solve(sqrt(I*E)) %&% E, name="CorE")

# Algebra to compute total variances and standard deviations (diagonal only)
covP      <- mxAlgebra( expression=A+C+E, name="V" )
matI      <- mxMatrix( type="Iden", nrow=nv, ncol=nv, name="I")
invSD     <- mxAlgebra( expression=solve(sqrt(I*V)), name="iSD")

# Algebras generated to hold Parameter Estimates and Derived Variance Components
rowVars   <- rep('vars',nv)
colVars   <- rep(c('A','C','E','SA','SC','SE'),each=nv)
estVars   <- mxAlgebra( expression=cbind(A,C,E,A/V,C/V,E/V), name="Vars", dimnames=list(rowVars,colVars))
her        <-mxAlgebra( expression=A/V, name="h2")
cer        <-mxAlgebra( expression=C/V, name="c2")
eer        <-mxAlgebra( expression=E/V, name="e2")

# Algebra for expected Mean and Variance/Covariance Matrices in MZ & DZ twins
meanG     <- mxMatrix( type="Full", nrow=1, ncol=nv, free=TRUE, values=meVals, labels=meanLabs, name="Mean" )
meanT     <- mxAlgebra( expression= cbind(Mean,Mean), name="expMean" )
covMZ     <- mxAlgebra( expression= rbind( cbind(A+C+E , A+C),
                                           cbind(A+C   , A+C+E)), name="expCovMZ" )
covDZ     <- mxAlgebra( expression= rbind( cbind(A+C+E     , 0.5%x%A+C),
                                           cbind(0.5%x%A+C , A+C+E)), name="expCovDZ" )

# Data objects for Multiple Groups
dataMZ    <- mxData( observed=mzData, type="raw" )
dataDZ    <- mxData( observed=dzData, type="raw" )

# Objective objects for Multiple Groups
objMZ     <- mxExpectationNormal( covariance="expCovMZ", means="expMean", dimnames=selVars )
objDZ     <- mxExpectationNormal( covariance="expCovDZ", means="expMean", dimnames=selVars )

# Combine Groups
fitFunction <- mxFitFunctionML()
pars      <- list( pathA, pathC, pathE, covA, covC, covE, covP, matI, invSD, estVars, meanG, meanT, her, cer, eer, CorA,CorE )
modelMZ   <- mxModel( pars, covMZ, dataMZ, objMZ, name="MZ", fitFunction )
modelDZ   <- mxModel( pars, covDZ, dataDZ, objDZ, name="DZ",  fitFunction )


modelFit      <- mxFitFunctionMultigroup( c("MZ", "DZ") )

CII<-mxCI(c("CorA", "CorE"))
CholAceModel  <- mxModel( "CholACE", pars, modelMZ, modelDZ, CII, modelFit)

# ------------------------------------------------------------------------------
# RUN MODEL

# Run Cholesky Decomposition ACE model
CholAeFit    <- mxTryHard(CholAceModel, extraTries = 50, greenOK = T)
#CholAceFit<-mxRun(CholAceFit, intervals = T)
#summary(CholAeFit)
# ------------------------------------------------------------------------------

CholAeSumm<-summary(CholAeFit)
#mxEval(expression = CholACE.CorA, model = CholAeFit)[3,4]

# Pvalue rg re
CholAeModelR   <- mxModel( CholAeFit, name="CholAER" )
CholAeModelR   <- omxSetParameters( CholAeModelR, labels='a43', free=FALSE, values=0 )
CholAeFitR     <- mxTryHard(CholAeModelR, extraTries = 50, greenOK = T)
#CholAeFitR <- mxRun(CholAeFitR, intervals = T)
summary(CholAeFitR)
pRGCub<-mxCompare(base = CholAeFit, comparison = CholAeFitR)$p[2]


CholAeModelE   <- mxModel( CholAeFit, name="CholAEE" )
CholAeModelE   <- omxSetParameters( CholAeModelE, labels='a41', free=FALSE, values=0 )
CholAeFitE   <- mxTryHard(CholAeModelE, extraTries = 50, greenOK = T)
#CholAeFitE <- mxRun(CholAeFitE, intervals = T)

#mxEval(expression = CholAEE.CorA, model = CholAeFitE)
pRGLin<-mxCompare(base = CholAeFit, comparison = CholAeFitE)$p[2]

# RE
CholAeModelR   <- mxModel( CholAeFit, name="CholAER" )
CholAeModelR   <- omxSetParameters( CholAeModelR, labels='e43', free=FALSE, values=0 )
CholAeFitR     <- mxTryHard(CholAeModelR, extraTries = 50, greenOK = T)
#CholAeFitR <- mxRun(CholAeFitR, intervals = T)

#mxEval(expression = CholAER.CorE, model = CholAeFitR)
pRECub<-mxCompare(base = CholAeFit, comparison = CholAeFitR)$p[2]


CholAeModelE   <- mxModel( CholAeFit, name="CholAEE" )
CholAeModelE   <- omxSetParameters( CholAeModelE, labels='e41', free=FALSE, values=0 )
CholAeFitE   <- mxTryHard(CholAeModelE, extraTries = 50, greenOK = T)
#CholAeFitE <- mxRun(CholAeFitE, intervals = T)

#mxEval(expression = CholAE.CorE, model = CholAeFit)
#mxEval(expression = CholAEE.CorE, model = CholAeFitE)
pRELin<-mxCompare(base = CholAeFit, comparison = CholAeFitE)$p[2]

res[var,]<-c(NA, mxEval(expression = CholACE.CorA, model = CholAeFit)[3,4], NA, pRGCub,  NA, mxEval(expression = CholACE.CorE, model = CholAeFit)[3,4],NA,  pRECub)

resLinear[var,]<-c(NA, mxEval(expression = CholACE.CorA, model = CholAeFit)[1,4], NA, pRGLin,NA , mxEval(expression = CholACE.CorE, model = CholAeFit)[1,4],NA ,pRELin)

write.table(res, "GeneticClusteringOutputPlots/GeneticCorr_cubic_multivCholesky_phenoReg_rGrE_SS.txt", sep="\t", col.names=T, row.names=T)
write.table(resLinear, "GeneticClusteringOutputPlots/GeneticCorr_Linear_multivCholesky_phenoReg_rGrE_SS.txt", sep="\t", col.names=T, row.names=T)



}

# Open results to check
res<-read.table("GeneticClusteringOutputPlots/GeneticCorr_cubic_multivCholesky_phenoReg_rGrE.txt", header=T,sep="\t")
resLinear<-read.table("GeneticClusteringOutputPlots/GeneticCorr_Linear_multivCholesky_phenoReg_rGrE.txt", header=T,sep="\t")

# Check significance of LRT vs. student test
tstat<-0.0035348457/0.004124282
1-pt(q = 2*abs(tstat),df = 834)
tstat<--0.0041434980/0.003287111
2*pt(q=abs(tstat),df=800, lower.tail=F)

plot(res$rG, resLinear$rG)
abline(b= -1, a = 0)
abline(b= 1, a = 0)

cor(data$anxDepScoreSSS3_Sib, data$SurfAreaRight12_reg_Sib, use = "p")
range(res$rG, na.rm = T)
range(res$rE, na.rm = T)
range(res$pval_re, na.rm = T)

hist(res$rG)

range(resLinear$rE, na.rm = T)


